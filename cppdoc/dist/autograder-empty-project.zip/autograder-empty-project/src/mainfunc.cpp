/*
 * Test file for verifying the Stanford C++ lib functionality.
 */

//#include "gobjects.h"
#include <iostream>
//#include "console.h"

int main() {
//    extern int mainQt2dGraphics();
//    return mainQt2dGraphics();
//    extern int mainQtLayout();
//    return mainQtLayout();
    extern int mainQtWidgets();
    return mainQtWidgets();

//    extern int mainQtConsole();
//    return mainQtConsole();
//    return 0;
}
