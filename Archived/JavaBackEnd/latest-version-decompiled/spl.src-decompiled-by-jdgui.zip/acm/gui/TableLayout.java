package acm.gui;

import acm.util.ErrorException;
import acm.util.OptionTable;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;
import java.awt.Scrollbar;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.swing.JScrollBar;
import javax.swing.JSlider;

public class TableLayout
  implements LayoutManager2, Serializable
{
  public static final int NONE = 0;
  public static final int HORIZONTAL = 2;
  public static final int VERTICAL = 3;
  public static final int BOTH = 1;
  public static final int CENTER = 10;
  public static final int LEFT = 11;
  public static final int RIGHT = 12;
  public static final int TOP = 13;
  public static final int BOTTOM = 14;
  public static final int FILL = 1;
  private static final int LAYOUT_CONTAINER_MODE = 0;
  private static final int MINIMUM_LAYOUT_SIZE_MODE = 1;
  private static final int PREFERRED_LAYOUT_SIZE_MODE = 2;
  private static final int MINIMUM_SCROLLBAR_SIZE = 100;
  private transient Container targetContainer;
  private HashMap<Component, GridBagConstraints> constraintTable;
  private HashMap<Component, TableConstraints> layoutTable;
  private HashMap<String, Object> propertyTable;
  private boolean useStrictGridBagModel;
  private int nRows;
  private int nColumns;
  private int horizontalAlignment;
  private int verticalAlignment;
  private int defaultFill;
  private int hGap;
  private int vGap;
  static final long serialVersionUID = 1L;
  
  public TableLayout()
  {
    this(0, 0);
  }
  
  public TableLayout(int paramInt1, int paramInt2)
  {
    this(paramInt1, paramInt2, 0, 0);
  }
  
  public TableLayout(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.nRows = paramInt1;
    this.nColumns = paramInt2;
    this.hGap = paramInt3;
    this.vGap = paramInt4;
    this.horizontalAlignment = 10;
    this.verticalAlignment = 10;
    this.defaultFill = 1;
    this.constraintTable = new HashMap();
    this.propertyTable = new HashMap();
    this.layoutTable = null;
  }
  
  public void setColumnCount(int paramInt)
  {
    this.nColumns = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getColumnCount()
  {
    return this.nColumns;
  }
  
  public void setRowCount(int paramInt)
  {
    this.nRows = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getRowCount()
  {
    return this.nRows;
  }
  
  public void setHorizontalAlignment(int paramInt)
  {
    this.horizontalAlignment = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getHorizontalAlignment()
  {
    return this.horizontalAlignment;
  }
  
  public void setVerticalAlignment(int paramInt)
  {
    this.verticalAlignment = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getVerticalAlignment()
  {
    return this.verticalAlignment;
  }
  
  public void setDefaultFill(int paramInt)
  {
    this.defaultFill = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getDefaultFill()
  {
    return this.defaultFill;
  }
  
  public void setHgap(int paramInt)
  {
    this.hGap = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getHgap()
  {
    return this.hGap;
  }
  
  public void setVgap(int paramInt)
  {
    this.vGap = paramInt;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public int getVgap()
  {
    return this.vGap;
  }
  
  public void setStrictGridBagModel(boolean paramBoolean)
  {
    this.useStrictGridBagModel = paramBoolean;
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public boolean isStrictGridBagModel()
  {
    return this.useStrictGridBagModel;
  }
  
  public void setConstraints(Component paramComponent, GridBagConstraints paramGridBagConstraints)
  {
    this.constraintTable.put(paramComponent, (GridBagConstraints)paramGridBagConstraints.clone());
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public void setConstraints(Component paramComponent, String paramString)
  {
    setConstraints(paramComponent, new TableConstraints(paramString));
  }
  
  public TableConstraints getConstraints(Component paramComponent)
  {
    GridBagConstraints localGridBagConstraints = lookupConstraints(paramComponent);
    return localGridBagConstraints == null ? null : new TableConstraints(localGridBagConstraints);
  }
  
  public void addLayoutComponent(String paramString, Component paramComponent)
  {
    addLayoutComponent(paramComponent, paramString);
  }
  
  public void removeLayoutComponent(Component paramComponent)
  {
    this.constraintTable.remove(paramComponent);
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public Dimension preferredLayoutSize(Container paramContainer)
  {
    if (paramContainer.getComponentCount() == 0) {
      return new Dimension(0, 0);
    }
    return processLayout(paramContainer, 2);
  }
  
  public Dimension minimumLayoutSize(Container paramContainer)
  {
    if (paramContainer.getComponentCount() == 0) {
      return new Dimension(0, 0);
    }
    return processLayout(paramContainer, 1);
  }
  
  public void layoutContainer(Container paramContainer)
  {
    this.targetContainer = paramContainer;
    processLayout(paramContainer, 0);
  }
  
  public void addLayoutComponent(Component paramComponent, Object paramObject)
  {
    if (paramObject == null)
    {
      paramObject = new TableConstraints("");
      ((TableConstraints)paramObject).fill = this.defaultFill;
    }
    else if ((paramObject instanceof String))
    {
      OptionTable localOptionTable = new OptionTable(((String)paramObject).toLowerCase(), TableConstraints.LEGAL_KEYS);
      paramObject = new TableConstraints(localOptionTable.getMap());
      if (!localOptionTable.isSpecified("fill")) {
        ((TableConstraints)paramObject).fill = (localOptionTable.isSpecified("anchor") ? 0 : this.defaultFill);
      }
    }
    else if (!(paramObject instanceof GridBagConstraints))
    {
      throw new ErrorException("TableLayout: Illegal constraints");
    }
    this.constraintTable.put(paramComponent, (GridBagConstraints)paramObject);
    if (this.targetContainer != null) {
      this.targetContainer.invalidate();
    }
  }
  
  public Dimension maximumLayoutSize(Container paramContainer)
  {
    return new Dimension(2147483647, 2147483647);
  }
  
  public float getLayoutAlignmentX(Container paramContainer)
  {
    return 0.5F;
  }
  
  public float getLayoutAlignmentY(Container paramContainer)
  {
    return 0.5F;
  }
  
  public synchronized void invalidateLayout(Container paramContainer)
  {
    this.layoutTable = null;
    Iterator localIterator = this.propertyTable.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if ((str.startsWith("width")) && (!str.equals("width"))) {
        this.propertyTable.put(str, new Integer(0));
      }
      if ((str.startsWith("height")) && (!str.equals("height"))) {
        this.propertyTable.put(str, new Integer(0));
      }
      if ((str.startsWith("weightx")) && (!str.equals("weightx"))) {
        this.propertyTable.put(str, new Double(0.0D));
      }
      if ((str.startsWith("weighty")) && (!str.equals("weighty"))) {
        this.propertyTable.put(str, new Double(0.0D));
      }
    }
  }
  
  public String toString()
  {
    String str = getClass().getName();
    str = str + "[rows=" + this.nRows + ",columns=" + this.nColumns;
    if (this.hGap != 0) {
      str = str + ",hgap=" + this.hGap;
    }
    if (this.vGap != 0) {
      str = str + ",vgap=" + this.vGap;
    }
    str = str + "]";
    return str;
  }
  
  protected GridBagConstraints lookupConstraints(Component paramComponent)
  {
    return (GridBagConstraints)this.constraintTable.get(paramComponent);
  }
  
  protected TableConstraints lookupConstraints(Component paramComponent, Container paramContainer)
  {
    synchronized (paramContainer.getTreeLock())
    {
      if (this.layoutTable == null) {
        computeLayoutTable(paramContainer);
      }
      return (TableConstraints)this.layoutTable.get(paramComponent);
    }
  }
  
  private Dimension getMinimumComponentSize(Component paramComponent)
  {
    if (isScrollbar(paramComponent)) {
      return getMinimumScrollbarSize(paramComponent);
    }
    return paramComponent.getMinimumSize();
  }
  
  private Dimension getPreferredComponentSize(Component paramComponent)
  {
    if (isScrollbar(paramComponent)) {
      return getMinimumScrollbarSize(paramComponent);
    }
    return paramComponent.getPreferredSize();
  }
  
  private boolean isScrollbar(Component paramComponent)
  {
    return ((paramComponent instanceof Scrollbar)) || ((paramComponent instanceof JScrollBar)) || ((paramComponent instanceof JSlider));
  }
  
  private Dimension getMinimumScrollbarSize(Component paramComponent)
  {
    Dimension localDimension = paramComponent.getMinimumSize();
    try
    {
      Class localClass = paramComponent.getClass();
      Method localMethod = localClass.getMethod("getOrientation", new Class[0]);
      int i = ((Integer)localMethod.invoke(paramComponent, new Object[0])).intValue();
      if (i == 0) {
        localDimension.width = Math.max(localDimension.width, 100);
      } else {
        localDimension.height = Math.max(localDimension.height, 100);
      }
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
    return localDimension;
  }
  
  private Dimension processLayout(Container paramContainer, int paramInt)
  {
    synchronized (paramContainer.getTreeLock())
    {
      return lockedProcessLayout(paramContainer, paramInt);
    }
  }
  
  private synchronized Dimension lockedProcessLayout(Container paramContainer, int paramInt)
  {
    Dimension localDimension1 = null;
    if (this.layoutTable == null) {
      computeLayoutTable(paramContainer);
    }
    int i = getIntProperty("nRows");
    int j = getIntProperty("nColumns");
    int[] arrayOfInt1 = new int[i];
    int[] arrayOfInt2 = new int[j];
    int k = paramContainer.getComponentCount();
    for (int m = 0; m < k; m++)
    {
      Component localComponent1 = paramContainer.getComponent(m);
      localObject = (TableConstraints)this.layoutTable.get(localComponent1);
      int i1 = ((TableConstraints)localObject).gridx;
      int i2 = ((TableConstraints)localObject).gridy;
      int i3 = getIntProperty("width" + i1);
      int i4 = getIntProperty("height" + i2);
      if (i3 == 0)
      {
        if ((paramInt == 1) || (this.useStrictGridBagModel)) {
          i3 = getMinimumComponentSize(localComponent1).width;
        } else {
          i3 = getPreferredComponentSize(localComponent1).width;
        }
        i3 += 2 * ((TableConstraints)localObject).ipadx + ((TableConstraints)localObject).insets.left + ((TableConstraints)localObject).insets.right;
      }
      if (i4 == 0)
      {
        if ((paramInt == 1) || (this.useStrictGridBagModel)) {
          i4 = getMinimumComponentSize(localComponent1).height;
        } else {
          i4 = getPreferredComponentSize(localComponent1).height;
        }
        i4 += 2 * ((TableConstraints)localObject).ipady + ((TableConstraints)localObject).insets.top + ((TableConstraints)localObject).insets.bottom;
      }
      if (((TableConstraints)localObject).gridwidth <= 1) {
        arrayOfInt2[i1] = Math.max(arrayOfInt2[i1], i3);
      }
      if (((TableConstraints)localObject).gridheight <= 1) {
        arrayOfInt1[i2] = Math.max(arrayOfInt1[i2], i4);
      }
    }
    m = this.hGap;
    int n = this.vGap;
    Object localObject = new double[j];
    double[] arrayOfDouble = new double[i];
    double d1 = 0.0D;
    double d2 = 0.0D;
    for (int i5 = 0; i5 < j; i5++)
    {
      m += arrayOfInt2[i5] + this.hGap;
      localObject[i5] = getDoubleProperty("weightx" + i5);
      d1 += localObject[i5];
    }
    for (i5 = 0; i5 < i; i5++)
    {
      n += arrayOfInt1[i5] + this.vGap;
      arrayOfDouble[i5] = getDoubleProperty("weighty" + i5);
      d2 += arrayOfDouble[i5];
    }
    if (paramInt == 0)
    {
      Dimension localDimension2 = paramContainer.getSize();
      Insets localInsets = paramContainer.getInsets();
      localDimension2.width -= localInsets.left + localInsets.right;
      localDimension2.height -= localInsets.top + localInsets.bottom;
      int i6 = localDimension2.width - m;
      int i7 = localDimension2.height - n;
      int i8 = localInsets.left;
      int i9 = localInsets.top;
      int i10;
      if (d1 == 0.0D) {
        switch (this.horizontalAlignment)
        {
        case 11: 
          i6 = 0;
          break;
        case 10: 
          i8 += i6 / 2;
          i6 = 0;
          break;
        case 12: 
          i8 += i6;
          i6 = 0;
          break;
        case 1: 
          d1 = j;
          for (i10 = 0; i10 < j; i10++) {
            localObject[i10] = 1.0D;
          }
        }
      }
      if (d2 == 0.0D) {
        switch (this.verticalAlignment)
        {
        case 13: 
          i7 = 0;
          break;
        case 10: 
          i9 += i7 / 2;
          i7 = 0;
          break;
        case 14: 
          i9 += i7;
          i7 = 0;
          break;
        case 1: 
          d2 = i;
          for (i10 = 0; i10 < i; i10++) {
            arrayOfDouble[i10] = 1.0D;
          }
        }
      }
      int[] arrayOfInt3 = new int[j];
      int i11 = this.hGap + i8;
      for (int i12 = 0; i12 < j; i12++)
      {
        arrayOfInt3[i12] = i11;
        if (i6 > 0)
        {
          i13 = (int)Math.round(i6 * localObject[i12] / d1);
          arrayOfInt2[i12] += i13;
          i6 -= i13;
          d1 -= localObject[i12];
        }
        i11 += arrayOfInt2[i12] + this.hGap;
      }
      int[] arrayOfInt4 = new int[i];
      int i13 = this.vGap + i9;
      for (int i14 = 0; i14 < i; i14++)
      {
        arrayOfInt4[i14] = i13;
        if (i7 > 0)
        {
          int i15 = (int)Math.round(i7 * arrayOfDouble[i14] / d2);
          arrayOfInt1[i14] += i15;
          i7 -= i15;
          d2 -= arrayOfDouble[i14];
        }
        i13 += arrayOfInt1[i14] + this.vGap;
      }
      for (i14 = 0; i14 < k; i14++)
      {
        Component localComponent2 = paramContainer.getComponent(i14);
        TableConstraints localTableConstraints = (TableConstraints)this.layoutTable.get(localComponent2);
        int i16 = localTableConstraints.gridx;
        int i17 = localTableConstraints.gridy;
        int i18 = arrayOfInt3[i16] + localTableConstraints.insets.left;
        int i19 = arrayOfInt4[i17] + localTableConstraints.insets.top;
        int i20 = arrayOfInt2[i16];
        for (int i21 = 1; (i21 < localTableConstraints.gridwidth) && (i16 + i21 < j); i21++) {
          i20 += arrayOfInt2[(i16 + i21)] + this.hGap;
        }
        i20 -= localTableConstraints.insets.left + localTableConstraints.insets.right;
        i21 = arrayOfInt1[i17];
        for (int i22 = 1; (i22 < localTableConstraints.gridheight) && (i17 + i22 < i); i22++) {
          i21 += arrayOfInt1[(i17 + i22)] + this.vGap;
        }
        i21 -= localTableConstraints.insets.top + localTableConstraints.insets.bottom;
        Dimension localDimension3 = this.useStrictGridBagModel ? getMinimumComponentSize(localComponent2) : getPreferredComponentSize(localComponent2);
        Rectangle localRectangle = computeCellBounds(new Rectangle(i18, i19, i20, i21), localDimension3, localTableConstraints);
        localComponent2.setBounds(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height);
      }
    }
    else
    {
      localDimension1 = new Dimension(m, n);
    }
    return localDimension1;
  }
  
  private void computeLayoutTable(Container paramContainer)
  {
    int[] arrayOfInt1 = null;
    int i = 0;
    int[] arrayOfInt2 = 0;
    int j = this.nColumns;
    int k = paramContainer.getComponentCount();
    int m = 0;
    this.layoutTable = new HashMap();
    for (int n = 0; n < k; n++)
    {
      Component localComponent = paramContainer.getComponent(n);
      TableConstraints localTableConstraints = getConstraints(localComponent);
      if (localTableConstraints.gridx != -1) {
        arrayOfInt2 = localTableConstraints.gridx;
      }
      if (localTableConstraints.gridy != -1) {
        i = localTableConstraints.gridy;
      }
      if ((this.nRows > 0) && (i >= this.nRows)) {
        throw new ErrorException("TableLayout: Too many rows specified");
      }
      while ((arrayOfInt1 != null) && (arrayOfInt2 < arrayOfInt1.length) && (arrayOfInt1[arrayOfInt2] > 0))
      {
        arrayOfInt2++;
        if ((j > 0) && (arrayOfInt2 >= j))
        {
          for (i1 = 0; i1 < arrayOfInt1.length; i1++) {
            if (arrayOfInt1[i1] > 0) {
              arrayOfInt1[i1] -= 1;
            }
          }
          i++;
          arrayOfInt2 = getFirstAvailableColumn(arrayOfInt1);
        }
      }
      localTableConstraints.gridx = arrayOfInt2;
      localTableConstraints.gridy = i;
      int i1 = m;
      setMaxProperty("width" + arrayOfInt2, localTableConstraints.width);
      setMaxProperty("height" + i, localTableConstraints.height);
      setMaxProperty("weightx" + arrayOfInt2, localTableConstraints.weightx);
      setMaxProperty("weighty" + i, localTableConstraints.weighty);
      int i2 = 1;
      switch (localTableConstraints.gridwidth)
      {
      case 0: 
        i1 = 1;
        if (j > 0) {
          i2 = j - arrayOfInt2;
        }
        break;
      case -1: 
        if (j <= 0) {
          throw new ErrorException("TableLayout: Illegal to use gridwidth=RELATIVE in first row");
        }
        i2 = j - arrayOfInt2 - 1;
        m = 1;
        break;
      default: 
        i2 = localTableConstraints.gridwidth;
        i1 = (this.nColumns > 0) && (arrayOfInt2 + localTableConstraints.gridwidth >= this.nColumns) ? 1 : 0;
      }
      if ((i2 > 1) && (arrayOfInt1 != null)) {
        for (i3 = arrayOfInt2; i3 < Math.min(arrayOfInt1.length, arrayOfInt2 + i2); i3++) {
          if (arrayOfInt1[i3] != 0) {
            throw new ErrorException("TableLayout: Overlapping cells");
          }
        }
      }
      int i3 = 1;
      switch (localTableConstraints.gridheight)
      {
      case 0: 
        i3 = 2147483647;
        break;
      case -1: 
        throw new ErrorException("TableLayout: Illegal to use gridheight=RELATIVE");
      default: 
        i3 = localTableConstraints.gridheight;
      }
      if (i3 > 1)
      {
        if (arrayOfInt1 == null)
        {
          arrayOfInt1 = new int[arrayOfInt2 + i2];
        }
        else if (arrayOfInt1.length < arrayOfInt2 + i2)
        {
          arrayOfInt3 = arrayOfInt1;
          arrayOfInt1 = new int[arrayOfInt2 + i2];
          System.arraycopy(arrayOfInt3, 0, arrayOfInt1, 0, arrayOfInt3.length);
        }
        for (int[] arrayOfInt3 = arrayOfInt2; arrayOfInt3 < arrayOfInt2 + i2; arrayOfInt3++) {
          arrayOfInt1[arrayOfInt3] = i3;
        }
      }
      localTableConstraints.gridwidth = i2;
      localTableConstraints.gridheight = i3;
      this.layoutTable.put(localComponent, localTableConstraints);
      arrayOfInt2 += i2;
      while ((i1 != 0) || ((j > 0) && (arrayOfInt2 >= j)))
      {
        if (j <= 0) {
          j = arrayOfInt2;
        }
        if (arrayOfInt1 != null) {
          for (int i4 = 0; i4 < arrayOfInt1.length; i4++) {
            if (arrayOfInt1[i4] > 0) {
              arrayOfInt1[i4] -= 1;
            }
          }
        }
        i++;
        arrayOfInt2 = getFirstAvailableColumn(arrayOfInt1);
        i1 = 0;
      }
    }
    if (j <= 0) {
      j = arrayOfInt2;
    }
    setIntProperty("nColumns", j);
    setIntProperty("nRows", i + 1);
  }
  
  private Rectangle computeCellBounds(Rectangle paramRectangle, Dimension paramDimension, TableConstraints paramTableConstraints)
  {
    int i = paramRectangle.x;
    int j = paramRectangle.y;
    int k = paramRectangle.width;
    int m = paramRectangle.height;
    if ((paramTableConstraints.fill == 0) || (paramTableConstraints.fill == 3)) {
      k = paramDimension.width;
    }
    if ((paramTableConstraints.fill == 0) || (paramTableConstraints.fill == 2)) {
      m = paramDimension.height;
    }
    if (k != paramRectangle.width) {
      switch (paramTableConstraints.anchor)
      {
      case 10: 
      case 11: 
      case 15: 
        i += (paramRectangle.width - k) / 2;
        break;
      case 12: 
      case 13: 
      case 14: 
        i += paramRectangle.width - k;
      }
    }
    if (m != paramRectangle.height) {
      switch (paramTableConstraints.anchor)
      {
      case 10: 
      case 13: 
      case 17: 
        j += (paramRectangle.height - m) / 2;
        break;
      case 14: 
      case 15: 
      case 16: 
        j += paramRectangle.height - m;
      }
    }
    return new Rectangle(i, j, k, m);
  }
  
  private void setMaxProperty(String paramString, int paramInt)
  {
    setIntProperty(paramString, Math.max(paramInt, getIntProperty(paramString)));
  }
  
  private void setMaxProperty(String paramString, double paramDouble)
  {
    setDoubleProperty(paramString, Math.max(paramDouble, getDoubleProperty(paramString)));
  }
  
  private void setIntProperty(String paramString, int paramInt)
  {
    this.propertyTable.put(paramString, new Integer(paramInt));
  }
  
  private int getIntProperty(String paramString)
  {
    Object localObject = this.propertyTable.get(paramString);
    if (localObject == null) {
      return 0;
    }
    return ((Integer)localObject).intValue();
  }
  
  private void setDoubleProperty(String paramString, double paramDouble)
  {
    this.propertyTable.put(paramString, new Double(paramDouble));
  }
  
  private double getDoubleProperty(String paramString)
  {
    Object localObject = this.propertyTable.get(paramString);
    if (localObject == null) {
      return 0.0D;
    }
    return ((Double)localObject).doubleValue();
  }
  
  private int getFirstAvailableColumn(int[] paramArrayOfInt)
  {
    if ((this.useStrictGridBagModel) && (paramArrayOfInt != null)) {
      for (int i = paramArrayOfInt.length; i > 0; i--) {
        if (paramArrayOfInt[(i - 1)] > 0) {
          return i;
        }
      }
    }
    return 0;
  }
}
