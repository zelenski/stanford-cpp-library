package acm.gui;

import acm.io.IODialog;
import acm.util.ErrorException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import javax.swing.JTextField;

public class IntField
  extends JTextField
{
  private static final int MINIMUM_WIDTH = 60;
  private static final int MINIMUM_HEIGHT = 22;
  private static final int PIXEL_MARGIN = 2;
  private boolean exceptionOnError;
  private int minValue;
  private int maxValue;
  private String formatString;
  private DecimalFormat formatter;
  private NumberFormat parser;
  private IODialog dialog;
  static final long serialVersionUID = 1L;
  
  public IntField()
  {
    this("", -2147483648, 2147483647);
  }
  
  public IntField(int paramInt)
  {
    this("" + paramInt, -2147483648, 2147483647);
  }
  
  public IntField(int paramInt1, int paramInt2)
  {
    this("", paramInt1, paramInt2);
  }
  
  public IntField(int paramInt1, int paramInt2, int paramInt3)
  {
    this("" + paramInt1, paramInt2, paramInt3);
  }
  
  private IntField(String paramString, int paramInt1, int paramInt2)
  {
    this.parser = NumberFormat.getNumberInstance(Locale.US);
    setBackground(Color.WHITE);
    setHorizontalAlignment(4);
    this.minValue = paramInt1;
    this.maxValue = paramInt2;
    setText(paramString);
    this.exceptionOnError = false;
  }
  
  public int getValue()
  {
    String str1 = getText().trim();
    if (str1.length() == 0)
    {
      if ((this.minValue <= 0) && (this.maxValue >= 0)) {
        return 0;
      }
      return this.minValue;
    }
    String str2 = null;
    int i = 0;
    try
    {
      i = this.parser.parse(str1).intValue();
      if ((i >= this.minValue) && (i <= this.maxValue)) {
        break label274;
      }
      str2 = "Value is outside the specified range";
    }
    catch (ParseException localParseException)
    {
      str2 = "Illegal integer format";
    }
    if (this.exceptionOnError) {
      throw new ErrorException(str2);
    }
    String str3 = "Enter an integer";
    if (this.minValue != -2147483648)
    {
      if (this.maxValue != 2147483647) {
        str3 = str3 + " between " + this.minValue + " and " + this.maxValue;
      } else {
        str3 = str3 + " greater than " + this.minValue;
      }
    }
    else if (this.maxValue != 2147483647) {
      str3 = str3 + " less than " + this.maxValue;
    }
    if (this.dialog == null) {
      this.dialog = new IODialog(this);
    }
    i = this.dialog.readInt(str3, this.minValue, this.maxValue);
    label274:
    setValue(i);
    return i;
  }
  
  public void setValue(int paramInt)
  {
    setText(this.formatter == null ? defaultFormat(paramInt) : this.formatter.format(paramInt));
  }
  
  public String getFormat()
  {
    return this.formatString;
  }
  
  public void setFormat(String paramString)
  {
    String str = getText().trim();
    int i = 0;
    if (str.length() != 0) {
      try
      {
        i = this.parser.parse(str).intValue();
      }
      catch (ParseException localParseException)
      {
        throw new ErrorException(localParseException);
      }
    }
    this.formatString = paramString;
    if (paramString == null)
    {
      this.formatter = null;
      this.parser = NumberFormat.getNumberInstance(Locale.US);
    }
    else
    {
      this.formatter = (paramString.length() == 0 ? new DecimalFormat() : new DecimalFormat(paramString));
      this.parser = this.formatter;
    }
    if (str.length() != 0) {
      setValue(i);
    }
  }
  
  public void setExceptionOnError(boolean paramBoolean)
  {
    this.exceptionOnError = paramBoolean;
  }
  
  public boolean getExceptionOnError()
  {
    return this.exceptionOnError;
  }
  
  public Dimension getPreferredSize()
  {
    Dimension localDimension = super.getPreferredSize();
    return new Dimension(Math.max(60, localDimension.width), Math.max(22, localDimension.height));
  }
  
  private String defaultFormat(int paramInt)
  {
    String str = "" + paramInt;
    int i = getSize().width - 4;
    FontMetrics localFontMetrics = getFontMetrics(getFont());
    if (localFontMetrics.stringWidth(str) > i)
    {
      str = "";
      while (localFontMetrics.stringWidth(str + "#") <= i) {
        str = str + "#";
      }
    }
    return str;
  }
}
