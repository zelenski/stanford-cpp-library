package acm.gui;

import acm.io.IODialog;
import acm.util.ErrorException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import javax.swing.JTextField;

public class DoubleField
  extends JTextField
{
  private static final int MINIMUM_WIDTH = 60;
  private static final int MINIMUM_HEIGHT = 22;
  private static final int PIXEL_MARGIN = 2;
  private boolean exceptionOnError;
  private double minValue;
  private double maxValue;
  private String formatString;
  private DecimalFormat formatter;
  private NumberFormat parser;
  private IODialog dialog;
  static final long serialVersionUID = 1L;
  
  public DoubleField()
  {
    this("", (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public DoubleField(double paramDouble)
  {
    this("" + paramDouble, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public DoubleField(double paramDouble1, double paramDouble2)
  {
    this("", paramDouble1, paramDouble2);
  }
  
  public DoubleField(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this("" + paramDouble1, paramDouble2, paramDouble3);
  }
  
  private DoubleField(String paramString, double paramDouble1, double paramDouble2)
  {
    this.parser = NumberFormat.getNumberInstance(Locale.US);
    setBackground(Color.WHITE);
    setHorizontalAlignment(4);
    this.minValue = paramDouble1;
    this.maxValue = paramDouble2;
    setText(paramString);
    this.exceptionOnError = false;
  }
  
  public double getValue()
  {
    String str1 = getText().trim();
    if (str1.length() == 0)
    {
      if ((this.minValue <= 0.0D) && (this.maxValue >= 0.0D)) {
        return 0.0D;
      }
      return this.minValue;
    }
    String str2 = null;
    double d = 0.0D;
    try
    {
      d = this.parser.parse(str1).doubleValue();
      if ((d >= this.minValue) && (d <= this.maxValue)) {
        break label286;
      }
      str2 = "Value is outside the specified range";
    }
    catch (ParseException localParseException)
    {
      str2 = "Illegal numeric format";
    }
    if (this.exceptionOnError) {
      throw new ErrorException(str2);
    }
    String str3 = "Enter a number";
    if (this.minValue != (-1.0D / 0.0D))
    {
      if (this.maxValue != (1.0D / 0.0D)) {
        str3 = str3 + " between " + this.minValue + " and " + this.maxValue;
      } else {
        str3 = str3 + " greater than " + this.minValue;
      }
    }
    else if (this.maxValue != (1.0D / 0.0D)) {
      str3 = str3 + " less than " + this.maxValue;
    }
    if (this.dialog == null) {
      this.dialog = new IODialog(this);
    }
    d = this.dialog.readDouble(str3, this.minValue, this.maxValue);
    label286:
    setValue(d);
    return d;
  }
  
  public void setValue(double paramDouble)
  {
    setText(this.formatter == null ? defaultFormat(paramDouble) : this.formatter.format(paramDouble));
  }
  
  public String getFormat()
  {
    return this.formatString;
  }
  
  public void setFormat(String paramString)
  {
    String str = getText().trim();
    double d = 0.0D;
    if (str.length() != 0) {
      try
      {
        d = this.parser.parse(str).doubleValue();
      }
      catch (ParseException localParseException)
      {
        throw new ErrorException(localParseException);
      }
    }
    this.formatString = paramString;
    if (paramString == null)
    {
      this.formatter = null;
      this.parser = NumberFormat.getNumberInstance(Locale.US);
    }
    else
    {
      this.formatter = (paramString.length() == 0 ? new DecimalFormat() : new DecimalFormat(paramString));
      this.parser = this.formatter;
    }
    if (str.length() != 0) {
      setValue(d);
    }
  }
  
  public void setExceptionOnError(boolean paramBoolean)
  {
    this.exceptionOnError = paramBoolean;
  }
  
  public boolean getExceptionOnError()
  {
    return this.exceptionOnError;
  }
  
  public Dimension getPreferredSize()
  {
    Dimension localDimension = super.getPreferredSize();
    return new Dimension(Math.max(60, localDimension.width), Math.max(22, localDimension.height));
  }
  
  private String defaultFormat(double paramDouble)
  {
    String str1 = "" + paramDouble;
    int i = getSize().width - 4;
    FontMetrics localFontMetrics = getFontMetrics(getFont());
    if (localFontMetrics.stringWidth(str1) <= i) {
      return str1;
    }
    int j = str1.indexOf("E");
    String str2 = "";
    if (j != -1)
    {
      str2 = str1.substring(j);
      str1 = str1.substring(0, j);
      try
      {
        paramDouble = this.parser.parse(str1).doubleValue();
      }
      catch (ParseException localParseException)
      {
        throw new ErrorException(localParseException);
      }
    }
    NumberFormat localNumberFormat = NumberFormat.getNumberInstance(Locale.US);
    localNumberFormat.setGroupingUsed(false);
    String str3 = str1.substring(0, str1.indexOf('.') + 1);
    int k = i - localFontMetrics.stringWidth(str3 + str2);
    if (k > 0)
    {
      int m = k / localFontMetrics.stringWidth("0");
      localNumberFormat.setMaximumFractionDigits(m);
      return localNumberFormat.format(paramDouble) + str2;
    }
    str1 = "";
    while (localFontMetrics.stringWidth(str1 + "#") <= i) {
      str1 = str1 + "#";
    }
    return str1;
  }
}
