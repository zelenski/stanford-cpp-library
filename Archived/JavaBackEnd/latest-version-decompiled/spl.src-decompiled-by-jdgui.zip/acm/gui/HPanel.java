package acm.gui;

public class HPanel
  extends TablePanel
{
  static final long serialVersionUID = 1L;
  
  public HPanel()
  {
    this(0, 0);
  }
  
  public HPanel(int paramInt1, int paramInt2)
  {
    TableLayout localTableLayout = new TableLayout(1, 0, paramInt1, paramInt2);
    localTableLayout.setHorizontalAlignment(1);
    localTableLayout.setVerticalAlignment(1);
    setLayout(localTableLayout);
  }
}
