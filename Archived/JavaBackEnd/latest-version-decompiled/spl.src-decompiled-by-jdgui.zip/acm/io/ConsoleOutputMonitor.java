package acm.io;

class ConsoleOutputMonitor
{
  private StandardConsoleModel consoleModel;
  
  public ConsoleOutputMonitor(StandardConsoleModel paramStandardConsoleModel)
  {
    this.consoleModel = paramStandardConsoleModel;
  }
  
  public synchronized void print(String paramString, int paramInt)
  {
    this.consoleModel.printCallback(paramString, paramInt);
  }
}
