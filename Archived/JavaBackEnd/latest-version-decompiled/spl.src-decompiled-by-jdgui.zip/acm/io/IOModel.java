package acm.io;

public abstract interface IOModel
{
  public abstract void print(String paramString);
  
  public abstract void print(boolean paramBoolean);
  
  public abstract void print(char paramChar);
  
  public abstract void print(double paramDouble);
  
  public abstract void print(float paramFloat);
  
  public abstract void print(int paramInt);
  
  public abstract void print(long paramLong);
  
  public abstract void print(Object paramObject);
  
  public abstract void println();
  
  public abstract void println(String paramString);
  
  public abstract void println(boolean paramBoolean);
  
  public abstract void println(char paramChar);
  
  public abstract void println(double paramDouble);
  
  public abstract void println(float paramFloat);
  
  public abstract void println(int paramInt);
  
  public abstract void println(long paramLong);
  
  public abstract void println(Object paramObject);
  
  public abstract void showErrorMessage(String paramString);
  
  public abstract String readLine();
  
  public abstract String readLine(String paramString);
  
  public abstract int readInt();
  
  public abstract int readInt(int paramInt1, int paramInt2);
  
  public abstract int readInt(String paramString);
  
  public abstract int readInt(String paramString, int paramInt1, int paramInt2);
  
  public abstract double readDouble();
  
  public abstract double readDouble(double paramDouble1, double paramDouble2);
  
  public abstract double readDouble(String paramString);
  
  public abstract double readDouble(String paramString, double paramDouble1, double paramDouble2);
  
  public abstract boolean readBoolean();
  
  public abstract boolean readBoolean(String paramString);
  
  public abstract boolean readBoolean(String paramString1, String paramString2, String paramString3);
}
