package acm.io;

import acm.program.ProgramMenuBar;
import java.awt.Color;
import java.awt.Component;
import java.awt.PrintJob;
import java.io.BufferedReader;

abstract interface ConsoleModel
{
  public static final int OUTPUT_STYLE = 0;
  public static final int INPUT_STYLE = 1;
  public static final int ERROR_STYLE = 2;
  
  public abstract void setConsole(IOConsole paramIOConsole);
  
  public abstract IOConsole getConsole();
  
  public abstract void print(String paramString, int paramInt);
  
  public abstract String readLine();
  
  public abstract void setInputScript(BufferedReader paramBufferedReader);
  
  public abstract BufferedReader getInputScript();
  
  public abstract void clear();
  
  public abstract String getText();
  
  public abstract String getText(int paramInt1, int paramInt2);
  
  public abstract int getLength();
  
  public abstract Component getConsolePane();
  
  public abstract Component getTextPane();
  
  public abstract void cut();
  
  public abstract void copy();
  
  public abstract void paste();
  
  public abstract void selectAll();
  
  public abstract boolean isPointSelection();
  
  public abstract void print(PrintJob paramPrintJob);
  
  public abstract void setInputStyle(int paramInt);
  
  public abstract void setInputColor(Color paramColor);
  
  public abstract void setErrorStyle(int paramInt);
  
  public abstract void setErrorColor(Color paramColor);
  
  public abstract void requestFocus();
  
  public abstract void setMenuBar(ProgramMenuBar paramProgramMenuBar);
}
