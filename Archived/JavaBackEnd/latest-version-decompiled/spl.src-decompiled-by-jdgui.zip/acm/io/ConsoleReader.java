package acm.io;

import java.io.Reader;

class ConsoleReader
  extends Reader
{
  private ConsoleModel consoleModel;
  private String buffer;
  
  public ConsoleReader(ConsoleModel paramConsoleModel)
  {
    this.consoleModel = paramConsoleModel;
    this.buffer = null;
  }
  
  public void close() {}
  
  public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      return 0;
    }
    if (this.buffer == null)
    {
      this.buffer = this.consoleModel.readLine();
      if (this.buffer == null) {
        return -1;
      }
      this.buffer += "\n";
    }
    if (paramInt2 < this.buffer.length())
    {
      this.buffer.getChars(0, paramInt2, paramArrayOfChar, paramInt1);
      this.buffer = this.buffer.substring(paramInt2);
    }
    else
    {
      paramInt2 = this.buffer.length();
      this.buffer.getChars(0, paramInt2, paramArrayOfChar, paramInt1);
      this.buffer = null;
    }
    return paramInt2;
  }
}
