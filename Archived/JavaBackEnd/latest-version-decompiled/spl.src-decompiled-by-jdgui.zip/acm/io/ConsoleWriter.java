package acm.io;

import java.io.Writer;

class ConsoleWriter
  extends Writer
{
  private ConsoleModel consoleModel;
  
  public ConsoleWriter(ConsoleModel paramConsoleModel)
  {
    this.consoleModel = paramConsoleModel;
  }
  
  public void close() {}
  
  public void flush() {}
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    String str = new String(paramArrayOfChar, paramInt1, paramInt2);
    int i = 0;
    int j;
    while ((j = str.indexOf(IOConsole.LINE_SEPARATOR, i)) != -1)
    {
      this.consoleModel.print(str.substring(i, j), 0);
      this.consoleModel.print("\n", 0);
      i = j + IOConsole.LINE_SEPARATOR.length();
    }
    this.consoleModel.print(str.substring(i), 0);
  }
}
