package acm.io;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ConsoleActionListener
  implements ActionListener
{
  private IOConsole console;
  
  public ConsoleActionListener(IOConsole paramIOConsole)
  {
    this.console = paramIOConsole;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.console.menuAction(paramActionEvent);
  }
}
