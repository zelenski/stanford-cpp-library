package acm.io;

class ConsoleInputMonitor
{
  private StandardConsoleModel consoleModel;
  
  public ConsoleInputMonitor(StandardConsoleModel paramStandardConsoleModel)
  {
    this.consoleModel = paramStandardConsoleModel;
  }
  
  public synchronized String readLine()
  {
    return this.consoleModel.readLineCallback();
  }
}
