package acm.io;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.StringTokenizer;

class AWTMessageCanvas
  extends Canvas
{
  public static final int MARGIN = 8;
  public static final Font MESSAGE_FONT = new Font("Dialog", 0, 12);
  private String message;
  
  public AWTMessageCanvas()
  {
    setFont(MESSAGE_FONT);
  }
  
  public void setMessage(String paramString)
  {
    this.message = paramString;
  }
  
  public void paint(Graphics paramGraphics)
  {
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int i = 8;
    int j = 8 + localFontMetrics.getAscent();
    int k = getSize().width - 8;
    StringTokenizer localStringTokenizer = new StringTokenizer(this.message, " ", true);
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      int m = localFontMetrics.stringWidth(str);
      if (i + m > k)
      {
        i = 8;
        j += localFontMetrics.getHeight();
        if (str.equals(" ")) {}
      }
      else
      {
        paramGraphics.drawString(str, i, j);
        i += m;
      }
    }
  }
}
