package acm.program;

import acm.util.JTFTools;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class AppletStarter
  implements Runnable
{
  private Program myProgram;
  private Thread mainThread;
  private Object executor;
  
  public AppletStarter(Program paramProgram)
  {
    this.myProgram = paramProgram;
  }
  
  public void start()
  {
    try
    {
      this.mainThread = new Thread(this);
      this.mainThread.start();
      if (JTFTools.testDebugOption("startup")) {
        System.out.println("Starting main thread using Thread package");
      }
    }
    catch (SecurityException localSecurityException)
    {
      if (JTFTools.testDebugOption("startup")) {
        System.out.println("Starting main thread using Executor because " + localSecurityException);
      }
      forkUsingExecutor();
    }
  }
  
  public void stop()
  {
    try
    {
      Object localObject;
      if (this.executor == null)
      {
        localObject = Class.forName("java.lang.Thread");
        Method localMethod = ((Class)localObject).getMethod("stop", new Class[0]);
        localMethod.invoke(this.mainThread, new Object[0]);
      }
      else
      {
        localObject = this.executor.getClass().getMethod("shutdownNow", new Class[0]);
        ((Method)localObject).invoke(this.executor, new Object[0]);
      }
    }
    catch (Exception localException) {}
  }
  
  public void run()
  {
    this.myProgram.startRun();
  }
  
  public Thread getMainThread()
  {
    return this.mainThread;
  }
  
  private void forkUsingExecutor()
  {
    try
    {
      Class localClass1 = Class.forName("java.util.concurrent.ScheduledExecutor");
      Class[] arrayOfClass1 = { Integer.TYPE };
      Object[] arrayOfObject1 = { new Integer(1) };
      Constructor localConstructor = localClass1.getConstructor(arrayOfClass1);
      this.executor = localConstructor.newInstance(arrayOfObject1);
      Class localClass2 = Class.forName("java.util.concurrent.TimeUnit");
      Field localField = localClass2.getField("SECONDS");
      Object localObject = localField.get(null);
      Class[] arrayOfClass2 = { Class.forName("java.lang.Runnable"), Long.TYPE, Class.forName("java.util.concurrent.TimeUnit") };
      

      Object[] arrayOfObject2 = { this, new Long(0L), localObject };
      Method localMethod = this.executor.getClass().getMethod("schedule", arrayOfClass2);
      localMethod.invoke(this.executor, arrayOfObject2);
    }
    catch (Exception localException)
    {
      if (JTFTools.testDebugOption("startup")) {
        System.out.println("Executor failed because " + localException);
      }
      this.executor = null;
      this.mainThread = Thread.currentThread();
      this.myProgram.startRun();
    }
  }
}
