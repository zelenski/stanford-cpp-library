package acm.program;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ProgramActionListener
  implements ActionListener
{
  private Program program;
  
  public ProgramActionListener(Program paramProgram)
  {
    this.program = paramProgram;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.program.menuAction(paramActionEvent);
  }
}
