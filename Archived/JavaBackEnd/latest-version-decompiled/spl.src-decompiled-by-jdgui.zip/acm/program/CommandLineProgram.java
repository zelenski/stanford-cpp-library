package acm.program;

import acm.io.IOConsole;
import acm.io.IODialog;
import acm.io.IOModel;
import acm.util.ErrorException;
import acm.util.JTFTools;
import java.applet.AppletStub;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import javax.swing.JPanel;

public class CommandLineProgram
  implements IOModel, Runnable, MouseListener, MouseMotionListener, KeyListener, ActionListener
{
  public static final String NORTH = "North";
  public static final String SOUTH = "South";
  public static final String EAST = "East";
  public static final String WEST = "West";
  public static final String CENTER = "Center";
  private HashMap<String, String> parameterTable;
  private ArrayList<Object> finalizers;
  private AppletStub appletStub;
  private String myTitle;
  private IOConsole myConsole;
  
  protected CommandLineProgram()
  {
    this.parameterTable = null;
    this.finalizers = new ArrayList();
    this.myTitle = getClass().getName();
    this.myTitle = this.myTitle.substring(this.myTitle.lastIndexOf(".") + 1);
    setConsole(createConsole());
  }
  
  public static void checkIfHeadless(String paramString)
  {
    Object localObject;
    if (!JTFTools.testDebugOption("headless")) {
      try
      {
        Class localClass = Class.forName("java.awt.GraphicsEnvironment");
        localObject = localClass.getMethod("isHeadless", new Class[0]);
        if (!Boolean.TRUE.equals(((Method)localObject).invoke(null, new Object[0]))) {
          return;
        }
      }
      catch (Exception localException1)
      {
        return;
      }
    }
    try
    {
      CommandLineProgramLoader localCommandLineProgramLoader = new CommandLineProgramLoader(paramString);
      localObject = localCommandLineProgramLoader.loadClass(paramString);
      CommandLineProgram localCommandLineProgram = (CommandLineProgram)((Class)localObject).newInstance();
      localCommandLineProgram.init();
      localCommandLineProgram.run();
      localCommandLineProgram.exit();
    }
    catch (Exception localException2)
    {
      throw new ErrorException(localException2);
    }
  }
  
  public void run() {}
  
  public void init() {}
  
  public void print(String paramString)
  {
    getOutputModel().print(paramString);
  }
  
  public final void print(boolean paramBoolean)
  {
    print("" + paramBoolean);
  }
  
  public final void print(char paramChar)
  {
    print("" + paramChar);
  }
  
  public final void print(double paramDouble)
  {
    print("" + paramDouble);
  }
  
  public final void print(float paramFloat)
  {
    print("" + paramFloat);
  }
  
  public final void print(int paramInt)
  {
    print("" + paramInt);
  }
  
  public final void print(long paramLong)
  {
    print("" + paramLong);
  }
  
  public final void print(Object paramObject)
  {
    print("" + paramObject);
  }
  
  public void println()
  {
    getOutputModel().println();
  }
  
  public void println(String paramString)
  {
    getOutputModel().println(paramString);
  }
  
  public final void println(boolean paramBoolean)
  {
    println("" + paramBoolean);
  }
  
  public final void println(char paramChar)
  {
    println("" + paramChar);
  }
  
  public final void println(double paramDouble)
  {
    println("" + paramDouble);
  }
  
  public final void println(float paramFloat)
  {
    println("" + paramFloat);
  }
  
  public final void println(int paramInt)
  {
    println("" + paramInt);
  }
  
  public final void println(long paramLong)
  {
    println("" + paramLong);
  }
  
  public final void println(Object paramObject)
  {
    println("" + paramObject);
  }
  
  public void showErrorMessage(String paramString)
  {
    getOutputModel().showErrorMessage(paramString);
  }
  
  public final String readLine()
  {
    return readLine(null);
  }
  
  public String readLine(String paramString)
  {
    return getInputModel().readLine(paramString);
  }
  
  public final int readInt()
  {
    return readInt(null, -2147483648, 2147483647);
  }
  
  public final int readInt(int paramInt1, int paramInt2)
  {
    return readInt(null, paramInt1, paramInt2);
  }
  
  public final int readInt(String paramString)
  {
    return readInt(paramString, -2147483648, 2147483647);
  }
  
  public int readInt(String paramString, int paramInt1, int paramInt2)
  {
    return getInputModel().readInt(paramString, paramInt1, paramInt2);
  }
  
  public final double readDouble()
  {
    return readDouble(null, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public final double readDouble(double paramDouble1, double paramDouble2)
  {
    return readDouble(null, paramDouble1, paramDouble2);
  }
  
  public final double readDouble(String paramString)
  {
    return readDouble(paramString, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public double readDouble(String paramString, double paramDouble1, double paramDouble2)
  {
    return getInputModel().readDouble(paramString, paramDouble1, paramDouble2);
  }
  
  public final boolean readBoolean()
  {
    return readBoolean(null);
  }
  
  public final boolean readBoolean(String paramString)
  {
    return readBoolean(paramString, "true", "false");
  }
  
  public boolean readBoolean(String paramString1, String paramString2, String paramString3)
  {
    return getInputModel().readBoolean(paramString1, paramString2, paramString3);
  }
  
  public boolean isAppletMode()
  {
    return false;
  }
  
  public void setConsole(IOConsole paramIOConsole)
  {
    this.myConsole = paramIOConsole;
  }
  
  public IOConsole getConsole()
  {
    return this.myConsole;
  }
  
  public IODialog getDialog()
  {
    return null;
  }
  
  public IOModel getInputModel()
  {
    return getConsole();
  }
  
  public IOModel getOutputModel()
  {
    return getConsole();
  }
  
  public BufferedReader getReader()
  {
    return getConsole().getReader();
  }
  
  public PrintWriter getWriter()
  {
    return getConsole().getWriter();
  }
  
  public JPanel getRegionPanel(String paramString)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void add(Component paramComponent, String paramString, Object paramObject)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void addActionListeners()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void addActionListeners(ActionListener paramActionListener)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void setTitle(String paramString)
  {
    this.myTitle = paramString;
  }
  
  public String getTitle()
  {
    return this.myTitle;
  }
  
  public void start(String[] paramArrayOfString)
  {
    if ((this.parameterTable == null) && (paramArrayOfString != null)) {
      this.parameterTable = createParameterTable(paramArrayOfString);
    }
    init();
    run();
  }
  
  public void exit()
  {
    int i = this.finalizers.size();
    for (int j = 0; j < i; j++)
    {
      Object localObject = this.finalizers.get(j);
      try
      {
        Class localClass = localObject.getClass();
        Method localMethod = localClass.getMethod("exit", new Class[0]);
        localMethod.invoke(localObject, new Object[0]);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
  }
  
  public void addExitHook(Object paramObject)
  {
    this.finalizers.add(paramObject);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent) {}
  
  public void mousePressed(MouseEvent paramMouseEvent) {}
  
  public void mouseReleased(MouseEvent paramMouseEvent) {}
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public void mouseMoved(MouseEvent paramMouseEvent) {}
  
  public void mouseDragged(MouseEvent paramMouseEvent) {}
  
  public void keyTyped(KeyEvent paramKeyEvent) {}
  
  public void keyPressed(KeyEvent paramKeyEvent) {}
  
  public void keyReleased(KeyEvent paramKeyEvent) {}
  
  public void actionPerformed(ActionEvent paramActionEvent) {}
  
  protected IOConsole createConsole()
  {
    return IOConsole.SYSTEM_CONSOLE;
  }
  
  protected IODialog createDialogIO()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public Dimension getPreferredSize()
  {
    return new Dimension(0, 0);
  }
  
  public int getWidth()
  {
    return 0;
  }
  
  public int getHeight()
  {
    return 0;
  }
  
  public String getParameter(String paramString)
  {
    String str = null;
    if (this.parameterTable != null) {
      str = (String)this.parameterTable.get(paramString.toLowerCase());
    }
    return str;
  }
  
  public void setLayout(LayoutManager paramLayoutManager)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public LayoutManager getLayout()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void setBackground(Color paramColor)
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected void addImpl(Component paramComponent, Object paramObject, int paramInt)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void remove(int paramInt)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void remove(Component paramComponent)
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void removeAll()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void validate()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void repaint()
  {
    throw new ErrorException("No graphics environment");
  }
  
  public void destroy() {}
  
  public static void main(String[] paramArrayOfString)
  {
    HashMap localHashMap = createParameterTable(paramArrayOfString);
    JTFTools.setDebugOptions((String)localHashMap.get("debug"));
    String str = (String)localHashMap.get("code");
    if (str == null) {
      str = JTFTools.getMainClass();
    }
    Class localClass = null;
    CommandLineProgram localCommandLineProgram = null;
    if (str != null)
    {
      if (str.endsWith(".class")) {
        str = str.substring(0, str.length() - 6);
      }
      str = str.replace('/', '.');
      try
      {
        localClass = Class.forName(str);
      }
      catch (ClassNotFoundException localClassNotFoundException) {}
    }
    if (localClass != null) {
      try
      {
        Object localObject = localClass.newInstance();
        if ((localObject instanceof CommandLineProgram)) {
          localCommandLineProgram = (CommandLineProgram)localObject;
        } else {
          throw new ErrorException("Main class does not specify a program");
        }
      }
      catch (IllegalAccessException localIllegalAccessException) {}catch (InstantiationException localInstantiationException) {}
    }
    if (localCommandLineProgram == null) {
      throw new ErrorException("Cannot determine the main class.");
    }
    localCommandLineProgram.setParameterTable(localHashMap);
    localCommandLineProgram.start(null);
  }
  
  public void menuAction(String paramString)
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected void setMacMenuBarFlag(boolean paramBoolean)
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected boolean getMacMenuBarFlag()
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected Component getBorder(String paramString)
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected String[] getArgumentArray()
  {
    if (this.parameterTable == null) {
      return null;
    }
    StringTokenizer localStringTokenizer = new StringTokenizer((String)this.parameterTable.get("ARGS"), "\t", false);
    String[] arrayOfString = new String[localStringTokenizer.countTokens()];
    for (int i = 0; localStringTokenizer.hasMoreTokens(); i++) {
      arrayOfString[i] = localStringTokenizer.nextToken();
    }
    return arrayOfString;
  }
  
  protected boolean isStarted()
  {
    throw new ErrorException("No graphics environment");
  }
  
  protected void startHook() {}
  
  protected void endHook() {}
  
  protected void setAppletStub(AppletStub paramAppletStub)
  {
    this.appletStub = paramAppletStub;
  }
  
  protected AppletStub getAppletStub()
  {
    return this.appletStub;
  }
  
  protected void setParameterTable(HashMap<String, String> paramHashMap)
  {
    this.parameterTable = paramHashMap;
  }
  
  protected HashMap<String, String> getParameterTable()
  {
    return this.parameterTable;
  }
  
  protected static HashMap<String, String> createParameterTable(String[] paramArrayOfString)
  {
    if (paramArrayOfString == null) {
      return null;
    }
    HashMap localHashMap = new HashMap();
    String str1 = "";
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      String str2 = paramArrayOfString[i];
      int j = str2.indexOf('=');
      if (j > 0)
      {
        String str3 = str2.substring(0, j).toLowerCase();
        String str4 = str2.substring(j + 1);
        localHashMap.put(str3, str4);
      }
      else
      {
        if (str1.length() > 0) {
          str1 = str1 + '\t';
        }
        str1 = str1 + str2;
      }
    }
    localHashMap.put("ARGS", str1);
    return localHashMap;
  }
}
