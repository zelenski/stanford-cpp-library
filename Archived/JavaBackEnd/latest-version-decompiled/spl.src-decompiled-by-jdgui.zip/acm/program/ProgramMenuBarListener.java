package acm.program;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ProgramMenuBarListener
  implements ActionListener
{
  private ProgramMenuBar menuBar;
  
  public ProgramMenuBarListener(ProgramMenuBar paramProgramMenuBar)
  {
    this.menuBar = paramProgramMenuBar;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.menuBar.fireActionListeners(paramActionEvent);
  }
}
