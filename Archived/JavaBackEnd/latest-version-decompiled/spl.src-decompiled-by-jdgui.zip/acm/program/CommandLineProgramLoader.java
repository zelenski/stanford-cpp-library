package acm.program;

import acm.util.ErrorException;
import acm.util.JTFTools;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.HashMap;

class CommandLineProgramLoader
  extends ClassLoader
{
  private static final int CONSTANT_Utf8 = 1;
  private static final int CONSTANT_Integer = 3;
  private static final int CONSTANT_Float = 4;
  private static final int CONSTANT_Long = 5;
  private static final int CONSTANT_Double = 6;
  private static final int CONSTANT_Class = 7;
  private static final int CONSTANT_String = 8;
  private static final int CONSTANT_Fieldref = 9;
  private static final int CONSTANT_Methodref = 10;
  private static final int CONSTANT_InterfaceMethodref = 11;
  private static final int CONSTANT_NameAndType = 12;
  private HashMap<Integer, Integer> classTable;
  private ClassLoader realLoader;
  private String targetName;
  private int superclassOffset;
  
  public CommandLineProgramLoader(String paramString)
  {
    this.targetName = paramString;
    try
    {
      Class localClass = Class.forName("java.lang.ClassLoader");
      Method localMethod = localClass.getMethod("getSystemClassLoader", new Class[0]);
      this.realLoader = ((ClassLoader)localMethod.invoke(null, new Object[0]));
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  public Class<?> loadClass(String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    if (paramString.equals(this.targetName))
    {
      InputStream localInputStream = getResourceAsStream(paramString + ".class");
      this.superclassOffset = findSuperclassOffset(localInputStream);
      localInputStream = getResourceAsStream(paramString + ".class");
      byte[] arrayOfByte = patchClassData(localInputStream);
      return defineClass(paramString, arrayOfByte, 0, arrayOfByte.length);
    }
    return this.realLoader.loadClass(paramString);
  }
  
  public InputStream getResourceAsStream(String paramString)
  {
    return this.realLoader.getResourceAsStream(paramString);
  }
  
  public URL getResource(String paramString)
  {
    return this.realLoader.getResource(paramString);
  }
  
  private byte[] patchClassData(InputStream paramInputStream)
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 8L);
      int i = paramInputStream.read() << 8 | paramInputStream.read();
      localByteArrayOutputStream.write(i >> 8);
      localByteArrayOutputStream.write(i & 0xFF);
      for (int j = 1; j < i; j++)
      {
        int k = paramInputStream.read();
        localByteArrayOutputStream.write(k);
        if (JTFTools.testDebugOption("constants")) {
          System.out.println(j + ": " + getConstantTypeName(k));
        }
        switch (k)
        {
        case 3: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 4: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 5: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 8L);j++; break;
        case 6: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 8L);j++; break;
        case 7: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 2L); break;
        case 8: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 2L); break;
        case 9: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 10: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 11: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 12: 
          JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, 4L); break;
        case 1: 
          int m;
          if (j == this.superclassOffset)
          {
            m = paramInputStream.read() << 8 | paramInputStream.read();
            paramInputStream.skip(m);
            String str = "acm/program/CommandLineProgram";
            m = str.length();
            localByteArrayOutputStream.write(m >> 8);
            localByteArrayOutputStream.write(m & 0xFF);
            for (int n = 0; n < m; n++) {
              localByteArrayOutputStream.write((byte)str.charAt(n));
            }
          }
          else
          {
            m = paramInputStream.read() << 8 | paramInputStream.read();
            localByteArrayOutputStream.write(m >> 8);
            localByteArrayOutputStream.write(m & 0xFF);
            JTFTools.copyBytes(paramInputStream, localByteArrayOutputStream, m);
          }
          break;
        }
      }
      for (;;)
      {
        j = paramInputStream.read();
        if (j == -1) {
          break;
        }
        localByteArrayOutputStream.write(j);
      }
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  private int findSuperclassOffset(InputStream paramInputStream)
  {
    this.classTable = new HashMap();
    try
    {
      paramInputStream.skip(8L);
      int i = paramInputStream.read() << 8 | paramInputStream.read();
      i += 2;
      for (int j = 1; j < i - 2; j++)
      {
        int k = paramInputStream.read();
        switch (k)
        {
        case 3: 
          paramInputStream.skip(4L); break;
        case 4: 
          paramInputStream.skip(4L); break;
        case 5: 
          paramInputStream.skip(8L);j++; break;
        case 6: 
          paramInputStream.skip(8L);j++; break;
        case 8: 
          paramInputStream.skip(2L); break;
        case 9: 
          paramInputStream.skip(4L); break;
        case 10: 
          paramInputStream.skip(4L); break;
        case 11: 
          paramInputStream.skip(4L); break;
        case 12: 
          paramInputStream.skip(4L); break;
        case 7: 
          int m = paramInputStream.read() << 8 | paramInputStream.read();
          this.classTable.put(new Integer(j), new Integer(m));
          break;
        case 1: 
          int n = paramInputStream.read() << 8 | paramInputStream.read();
          paramInputStream.skip(n);
        }
      }
      paramInputStream.skip(4L);
      return ((Integer)this.classTable.get(new Integer(paramInputStream.read() << 8 | paramInputStream.read()))).intValue();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  private static String getConstantTypeName(int paramInt)
  {
    switch (paramInt)
    {
    case 1: 
      return "Utf8";
    case 3: 
      return "Integer";
    case 4: 
      return "Float";
    case 5: 
      return "Long";
    case 6: 
      return "Double";
    case 7: 
      return "Class";
    case 8: 
      return "String";
    case 9: 
      return "Fieldref";
    case 10: 
      return "Methodref";
    case 11: 
      return "InterfaceMethodref";
    case 12: 
      return "NameAndType";
    }
    return "Type[" + paramInt + "]";
  }
}
