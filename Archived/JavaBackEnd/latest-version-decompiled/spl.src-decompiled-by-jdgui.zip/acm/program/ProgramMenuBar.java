package acm.program;

import acm.util.ErrorException;
import acm.util.Platform;
import java.awt.Component;
import java.awt.Container;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class ProgramMenuBar
  extends JMenuBar
  implements Iterable<JMenuItem>
{
  public static final int SHIFT = 131072;
  private Program program;
  private ActionListener menuBarListener;
  private ActionListener focusedListener;
  private HashMap<KeyStroke, JMenuItem> accelerators;
  private HashSet<JMenuItem> focusedItems;
  private MenuBar oldStyleMenuBar;
  private boolean macMenuBarFlag;
  
  public ProgramMenuBar(Program paramProgram)
  {
    this.program = paramProgram;
    this.menuBarListener = new ProgramMenuBarListener(this);
    this.focusedListener = null;
    this.accelerators = new HashMap();
    this.focusedItems = new HashSet();
    this.macMenuBarFlag = true;
    addMenus();
  }
  
  public Program getProgram()
  {
    return this.program;
  }
  
  public JMenuItem createStandardItem(String paramString)
  {
    JMenuItem localJMenuItem = null;
    if (paramString.equals("Quit"))
    {
      localJMenuItem = createProgramItem(paramString);
      if (Platform.isMac()) {
        setAccelerator(localJMenuItem, 81);
      } else {
        localJMenuItem.setName("Exit");
      }
    }
    else if (paramString.equals("Cut"))
    {
      localJMenuItem = createFocusedItem(paramString, 88);
      if (!Platform.isMac()) {
        localJMenuItem.setName("Cut (x)");
      }
    }
    else if (paramString.equals("Copy"))
    {
      localJMenuItem = createFocusedItem(paramString, 67);
      if (!Platform.isMac()) {
        localJMenuItem.setName("Copy (c)");
      }
    }
    else if (paramString.equals("Paste"))
    {
      localJMenuItem = createFocusedItem(paramString, 86);
      if (!Platform.isMac()) {
        localJMenuItem.setName("Paste (v)");
      }
    }
    else if (paramString.equals("Select All"))
    {
      localJMenuItem = createFocusedItem(paramString, 65);
    }
    else if (paramString.equals("Save"))
    {
      localJMenuItem = createFocusedItem(paramString, 83);
    }
    else if (paramString.equals("Save As"))
    {
      localJMenuItem = createFocusedItem(paramString);
    }
    else if (paramString.equals("Print"))
    {
      localJMenuItem = createProgramItem(paramString, 80);
      localJMenuItem.setName("Print...");
    }
    else if (paramString.equals("Print Console"))
    {
      localJMenuItem = createProgramItem(paramString);
    }
    else if (paramString.equals("Script"))
    {
      localJMenuItem = createProgramItem(paramString);
      localJMenuItem.setName("Script...");
    }
    else if (paramString.equals("Export Applet"))
    {
      localJMenuItem = createProgramItem(paramString);
      localJMenuItem.setName("Export Applet...");
    }
    else if (paramString.equals("Submit Project"))
    {
      localJMenuItem = createProgramItem(paramString);
      localJMenuItem.setName("Submit Project...");
    }
    else
    {
      throw new ErrorException("Illegal standard menu item: " + paramString);
    }
    return localJMenuItem;
  }
  
  public JMenuItem createProgramItem(String paramString)
  {
    JMenuItem localJMenuItem = new JMenuItem(paramString);
    localJMenuItem.setActionCommand(paramString);
    localJMenuItem.addActionListener(this.menuBarListener);
    return localJMenuItem;
  }
  
  public JMenuItem createProgramItem(String paramString, int paramInt)
  {
    JMenuItem localJMenuItem = createProgramItem(paramString);
    setAccelerator(localJMenuItem, paramInt);
    return localJMenuItem;
  }
  
  public JMenuItem createFocusedItem(String paramString)
  {
    JMenuItem localJMenuItem = createProgramItem(paramString);
    this.focusedItems.add(localJMenuItem);
    return localJMenuItem;
  }
  
  public JMenuItem createFocusedItem(String paramString, int paramInt)
  {
    JMenuItem localJMenuItem = createFocusedItem(paramString);
    setAccelerator(localJMenuItem, paramInt);
    return localJMenuItem;
  }
  
  public boolean isFocusedItem(JMenuItem paramJMenuItem)
  {
    return this.focusedItems.contains(paramJMenuItem);
  }
  
  public void setAccelerator(JMenuItem paramJMenuItem, int paramInt)
  {
    int i = Platform.isMac() ? 4 : 2;
    if (paramInt > 65536)
    {
      paramInt -= 131072;
      i |= 0x1;
    }
    KeyStroke localKeyStroke = KeyStroke.getKeyStroke((char)paramInt, i);
    this.accelerators.put(localKeyStroke, paramJMenuItem);
    if (Platform.isMac()) {
      paramJMenuItem.setAccelerator(localKeyStroke);
    } else {
      paramJMenuItem.setMnemonic(paramInt);
    }
  }
  
  public void setEnabled(String paramString, boolean paramBoolean)
  {
    int i = getMenuCount();
    for (int j = 0; j < i; j++) {
      setEnabled(getMenu(j), paramString, paramBoolean);
    }
  }
  
  public void install(Component paramComponent)
  {
    Container localContainer = this.program.getContentPane();
    while ((paramComponent != null) && (!(paramComponent instanceof JFrame)))
    {
      paramComponent = paramComponent.getParent();
      if ((paramComponent == localContainer) && (this.program.isAppletMode()))
      {
        if ((!Platform.isMac()) || (!this.macMenuBarFlag)) {
          this.program.setJMenuBar(this);
        }
        return;
      }
    }
    if (paramComponent == null) {
      return;
    }
    JFrame localJFrame = (JFrame)paramComponent;
    if ((Platform.isMac()) && (this.macMenuBarFlag))
    {
      if (this.oldStyleMenuBar == null) {
        this.oldStyleMenuBar = createOldStyleMenuBar();
      }
      localJFrame.setMenuBar(this.oldStyleMenuBar);
    }
    else
    {
      localJFrame.setJMenuBar(this);
      localJFrame.validate();
    }
  }
  
  public void setMacMenuBarFlag(boolean paramBoolean)
  {
    this.macMenuBarFlag = paramBoolean;
  }
  
  public boolean getMacMenuBarFlag()
  {
    return this.macMenuBarFlag;
  }
  
  public void fireActionListeners(ActionEvent paramActionEvent)
  {
    if ((this.focusedListener != null) && (this.focusedItems.contains(paramActionEvent.getSource()))) {
      this.focusedListener.actionPerformed(paramActionEvent);
    } else {
      this.program.menuAction(paramActionEvent);
    }
  }
  
  public boolean fireAccelerator(KeyEvent paramKeyEvent)
  {
    KeyStroke localKeyStroke = KeyStroke.getKeyStrokeForEvent(paramKeyEvent);
    JMenuItem localJMenuItem = (JMenuItem)this.accelerators.get(localKeyStroke);
    if (localJMenuItem != null)
    {
      localJMenuItem.doClick(0);
      return true;
    }
    return false;
  }
  
  public void setFocusedListener(ActionListener paramActionListener)
  {
    this.focusedListener = paramActionListener;
  }
  
  public Iterator<JMenuItem> iterator()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < getMenuCount(); i++) {
      addItemToList(localArrayList, getMenu(i));
    }
    return localArrayList.iterator();
  }
  
  protected void addMenus()
  {
    addFileMenu();
    addEditMenu();
  }
  
  protected void addFileMenu()
  {
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic('F');
    addFileMenuItems(localJMenu);
    add(localJMenu);
  }
  
  protected void addEditMenu()
  {
    JMenu localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic('E');
    addEditMenuItems(localJMenu);
    add(localJMenu);
  }
  
  protected void addFileMenuItems(JMenu paramJMenu)
  {
    paramJMenu.add(createStandardItem("Save"));
    paramJMenu.add(createStandardItem("Save As"));
    paramJMenu.addSeparator();
    paramJMenu.add(createStandardItem("Print"));
    paramJMenu.add(createStandardItem("Print Console"));
    paramJMenu.add(createStandardItem("Script"));
    paramJMenu.addSeparator();
    paramJMenu.add(createStandardItem("Export Applet"));
    paramJMenu.add(createStandardItem("Submit Project"));
    paramJMenu.addSeparator();
    paramJMenu.add(createStandardItem("Quit"));
  }
  
  protected void addEditMenuItems(JMenu paramJMenu)
  {
    paramJMenu.add(createStandardItem("Cut"));
    paramJMenu.add(createStandardItem("Copy"));
    paramJMenu.add(createStandardItem("Paste"));
    paramJMenu.add(createStandardItem("Select All"));
  }
  
  private void addItemToList(ArrayList<JMenuItem> paramArrayList, JMenuItem paramJMenuItem)
  {
    if (paramJMenuItem == null) {
      return;
    }
    if ((paramJMenuItem instanceof JMenu))
    {
      JMenu localJMenu = (JMenu)paramJMenuItem;
      for (int i = 0; i < localJMenu.getItemCount(); i++) {
        addItemToList(paramArrayList, localJMenu.getItem(i));
      }
    }
    else
    {
      paramArrayList.add(paramJMenuItem);
    }
  }
  
  private MenuBar createOldStyleMenuBar()
  {
    MenuBar localMenuBar = new MenuBar();
    int i = getMenuCount();
    for (int j = 0; j < i; j++) {
      localMenuBar.add(createOldStyleMenu(getMenu(j)));
    }
    return localMenuBar;
  }
  
  private Menu createOldStyleMenu(JMenu paramJMenu)
  {
    Menu localMenu = new Menu(paramJMenu.getText());
    int i = paramJMenu.getItemCount();
    for (int j = 0; j < i; j++) {
      localMenu.add(createOldStyleMenuItem(paramJMenu.getItem(j)));
    }
    return localMenu;
  }
  
  private MenuItem createOldStyleMenuItem(Object paramObject)
  {
    if (paramObject == null) {
      return new MenuItem("-");
    }
    if ((paramObject instanceof JMenu)) {
      return createOldStyleMenu((JMenu)paramObject);
    }
    if ((paramObject instanceof JCheckBoxMenuItem)) {
      return new OldStyleCheckBoxMenuItem((JCheckBoxMenuItem)paramObject);
    }
    if ((paramObject instanceof JMenuItem)) {
      return new OldStyleMenuItem((JMenuItem)paramObject);
    }
    throw new ErrorException("Unsupported menu item type");
  }
  
  private void setEnabled(JMenu paramJMenu, String paramString, boolean paramBoolean)
  {
    JMenu localJMenu = paramJMenu;
    int i = localJMenu.getItemCount();
    for (int j = 0; j < i; j++)
    {
      JMenuItem localJMenuItem = localJMenu.getItem(j);
      if (localJMenuItem != null) {
        setEnabled(localJMenuItem, paramString, paramBoolean);
      }
    }
  }
  
  private void setEnabled(JMenuItem paramJMenuItem, String paramString, boolean paramBoolean)
  {
    if (paramString.equals(paramJMenuItem.getActionCommand())) {
      paramJMenuItem.setEnabled(paramBoolean);
    }
  }
}
