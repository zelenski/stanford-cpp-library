package acm.program;

import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class OldStyleMenuItem
  extends MenuItem
  implements ActionListener, ChangeListener
{
  private JMenuItem twin;
  
  public OldStyleMenuItem(JMenuItem paramJMenuItem)
  {
    super(paramJMenuItem.getText());
    this.twin = paramJMenuItem;
    addActionListener(this);
    this.twin.addChangeListener(this);
    setEnabled(this.twin.isEnabled());
    KeyStroke localKeyStroke = this.twin.getAccelerator();
    if (localKeyStroke != null) {
      setShortcut(createShortcut(localKeyStroke));
    }
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.twin.doClick(0);
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    setEnabled(this.twin.isEnabled());
  }
  
  private MenuShortcut createShortcut(KeyStroke paramKeyStroke)
  {
    boolean bool = (paramKeyStroke.getModifiers() & 0x1) != 0;
    return new MenuShortcut(paramKeyStroke.getKeyCode(), bool);
  }
}
