package acm.program;

import java.awt.Component;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

class ProgramWindowListener
  implements WindowListener
{
  private Program program;
  
  public ProgramWindowListener(Program paramProgram)
  {
    this.program = paramProgram;
  }
  
  public void windowClosing(WindowEvent paramWindowEvent)
  {
    ((Component)paramWindowEvent.getSource()).setVisible(false);
    this.program.exit();
  }
  
  public void windowOpened(WindowEvent paramWindowEvent) {}
  
  public void windowClosed(WindowEvent paramWindowEvent) {}
  
  public void windowIconified(WindowEvent paramWindowEvent) {}
  
  public void windowDeiconified(WindowEvent paramWindowEvent) {}
  
  public void windowActivated(WindowEvent paramWindowEvent) {}
  
  public void windowDeactivated(WindowEvent paramWindowEvent) {}
}
