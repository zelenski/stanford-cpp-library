package acm.util;

import java.applet.AudioClip;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.DecimalFormat;
import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

public class SoundClip
  implements AudioClip
{
  public static final int MONO = 1;
  public static final int STEREO = 2;
  public static final int LEFT = 0;
  public static final int RIGHT = 1;
  public static final double STANDARD_FRAME_RATE = 22050.0D;
  public static final int MAX_SAMPLE = 32767;
  private static final int BYTES_PER_SAMPLE = 2;
  private static final int BUFFER_INCREMENT = 10000;
  private AudioFormat format;
  private SoundPlayer player;
  private String soundName;
  private double clipVolume;
  private float frameRate;
  private int nChannels;
  private int frameCount;
  private int currentFrame;
  private byte[] data;
  
  public SoundClip()
  {
    this(1);
  }
  
  public SoundClip(int paramInt)
  {
    if ((paramInt < 1) || (paramInt > 2)) {
      throw new ErrorException("SoundClip: Illegal number of channels");
    }
    this.nChannels = paramInt;
    this.frameRate = 22050.0F;
    this.soundName = "Untitled";
    this.frameCount = 0;
    this.clipVolume = 1.0D;
    this.data = new byte[0];
    this.format = new AudioFormat(this.frameRate, 16, paramInt, true, true);
  }
  
  public SoundClip(String paramString)
  {
    if (paramString.startsWith("http:"))
    {
      try
      {
        URL localURL = new URL(paramString);
        this.soundName = JTFTools.getURLSuffix(localURL.getPath());
        readSound(convertToPCM(getAudioInputStream(localURL.openStream())));
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
    else
    {
      this.soundName = paramString;
      readSound(convertToPCM(getAudioInputStream(new File(paramString))));
    }
  }
  
  public SoundClip(File paramFile)
  {
    try
    {
      this.soundName = paramFile.getName();
      readSound(convertToPCM(getAudioInputStream(paramFile)));
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  public SoundClip(URL paramURL)
  {
    try
    {
      this.soundName = JTFTools.getURLSuffix(paramURL.getPath());
      readSound(convertToPCM(getAudioInputStream(paramURL.openStream())));
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  public SoundClip(InputStream paramInputStream)
  {
    this.soundName = "Untitled";
    readSound(convertToPCM(getAudioInputStream(paramInputStream)));
  }
  
  public SoundClip(int[] paramArrayOfInt)
  {
    this(1);
    addSampleData(paramArrayOfInt);
  }
  
  public SoundClip(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    this(2);
    addSampleData(paramArrayOfInt1, paramArrayOfInt2);
  }
  
  public synchronized void play()
  {
    if (this.player == null) {
      this.player = new SoundPlayer(this);
    }
    this.player.play();
  }
  
  public void loop()
  {
    if (this.player == null) {
      this.player = new SoundPlayer(this);
    }
    this.player.loop();
  }
  
  public synchronized void stop()
  {
    if (this.player != null) {
      this.player.stop();
    }
  }
  
  public void save(String paramString)
  {
    save(new File(System.getProperty("user.dir"), paramString));
  }
  
  public void save(File paramFile)
  {
    try
    {
      AudioSystem.write(getAudioInputStream(), getFormatForFile(paramFile.getName()), paramFile);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("save: I/O error - " + localIOException.getMessage());
    }
  }
  
  public String getName()
  {
    return this.soundName;
  }
  
  public void setName(String paramString)
  {
    this.soundName = paramString;
  }
  
  public int getChannelCount()
  {
    return this.nChannels;
  }
  
  public boolean isStereo()
  {
    return this.nChannels == 2;
  }
  
  public int getFrameCount()
  {
    return this.frameCount;
  }
  
  public double getFrameRate()
  {
    return this.frameRate;
  }
  
  public double getDuration()
  {
    return this.frameCount / this.frameRate;
  }
  
  public int getFrameIndex()
  {
    return this.currentFrame;
  }
  
  public void setFrameIndex(int paramInt)
  {
    this.currentFrame = paramInt;
  }
  
  public void rewind()
  {
    setFrameIndex(0);
  }
  
  public double getVolume()
  {
    return this.clipVolume;
  }
  
  public void setVolume(double paramDouble)
  {
    this.clipVolume = paramDouble;
  }
  
  public int[] getSampleData()
  {
    return getSampleData(0);
  }
  
  public int[] getSampleData(int paramInt)
  {
    standardize();
    if ((paramInt < 0) || (paramInt >= this.nChannels)) {
      throw new ErrorException("getSamples: Channel number out of range");
    }
    int[] arrayOfInt = new int[this.frameCount];
    int i = paramInt * 2;
    for (int j = 0; j < this.frameCount; j++)
    {
      arrayOfInt[j] = (this.data[i] << 8 | this.data[(i + 1)] & 0xFF);
      i += this.nChannels * 2;
    }
    return arrayOfInt;
  }
  
  public void addSampleData(int paramInt)
  {
    standardize();
    if (this.nChannels == 2)
    {
      addSampleData(paramInt, paramInt);
    }
    else
    {
      int i = this.frameCount * 2;
      this.frameCount += 1;
      if (i >= this.data.length)
      {
        byte[] arrayOfByte = new byte[i + 10000];
        if (i > 0) {
          System.arraycopy(this.data, 0, arrayOfByte, 0, i);
        }
        this.data = arrayOfByte;
      }
      this.data[(i++)] = ((byte)(paramInt >> 8));
      this.data[(i++)] = ((byte)(paramInt & 0xFF));
    }
  }
  
  public void addSampleData(int paramInt1, int paramInt2)
  {
    standardize();
    if (this.nChannels != 2) {
      throw new ErrorException("addSampleData: Sound is not stereo");
    }
    int i = 2 * this.frameCount * 2;
    this.frameCount += 1;
    if (i >= this.data.length)
    {
      byte[] arrayOfByte = new byte[i + 10000];
      if (i > 0) {
        System.arraycopy(this.data, 0, arrayOfByte, 0, i);
      }
      this.data = arrayOfByte;
    }
    this.data[(i++)] = ((byte)(paramInt1 >> 8));
    this.data[(i++)] = ((byte)(paramInt1 & 0xFF));
    this.data[(i++)] = ((byte)(paramInt2 >> 8));
    this.data[(i++)] = ((byte)(paramInt2 & 0xFF));
  }
  
  public void addSampleData(int[] paramArrayOfInt)
  {
    standardize();
    if (this.nChannels == 2)
    {
      addSampleData(paramArrayOfInt, paramArrayOfInt);
    }
    else
    {
      int i = this.frameCount * 2;
      this.frameCount += paramArrayOfInt.length;
      byte[] arrayOfByte = new byte[this.frameCount * 2];
      if (i > 0) {
        System.arraycopy(this.data, 0, arrayOfByte, 0, i);
      }
      this.data = arrayOfByte;
      for (int j = 0; j < paramArrayOfInt.length; j++)
      {
        this.data[(i++)] = ((byte)(paramArrayOfInt[j] >> 8));
        this.data[(i++)] = ((byte)(paramArrayOfInt[j] & 0xFF));
      }
    }
  }
  
  public void addSampleData(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    standardize();
    if (this.nChannels != 2) {
      throw new ErrorException("addSampleData: Sound is not stereo");
    }
    if (paramArrayOfInt1.length != paramArrayOfInt2.length) {
      throw new ErrorException("addSampleData: Channels have unequal length");
    }
    int i = 2 * this.frameCount * 2;
    this.frameCount += paramArrayOfInt1.length;
    byte[] arrayOfByte = new byte[2 * this.frameCount * 2];
    if (i > 0) {
      System.arraycopy(this.data, 0, arrayOfByte, 0, i);
    }
    this.data = arrayOfByte;
    for (int j = 0; j < paramArrayOfInt1.length; j++)
    {
      this.data[(i++)] = ((byte)(paramArrayOfInt1[j] >> 8));
      this.data[(i++)] = ((byte)(paramArrayOfInt1[j] & 0xFF));
      this.data[(i++)] = ((byte)(paramArrayOfInt2[j] >> 8));
      this.data[(i++)] = ((byte)(paramArrayOfInt2[j] & 0xFF));
    }
  }
  
  public String toString()
  {
    String str = this.soundName;
    str = str + " (";
    str = str + (this.nChannels == 1 ? "mono" : "stereo");
    str = str + ", ";
    str = str + new DecimalFormat("#0.00").format(getDuration());
    str = str + " sec)";
    return str;
  }
  
  public static double sampleToIntensity(int paramInt)
  {
    return Math.max(-1.0D, Math.min(1.0D, paramInt / 32767.0D));
  }
  
  public static int intensityToSample(double paramDouble)
  {
    return (int)Math.round(Math.max(-1.0D, Math.min(1.0D, paramDouble)) * 32767.0D);
  }
  
  protected byte[] getData()
  {
    return this.data;
  }
  
  protected AudioFormat getFormat()
  {
    return this.format;
  }
  
  protected AudioInputStream getAudioInputStream()
  {
    return new AudioInputStream(new ByteArrayInputStream(this.data), this.format, this.frameCount);
  }
  
  private void standardize()
  {
    if (this.frameRate == 22050.0D) {
      return;
    }
    double d = 22050.0D / this.frameRate;
    int i = (int)(this.frameCount * d);
    byte[] arrayOfByte = new byte[this.nChannels * i * 2];
    int j = 0;
    for (int k = 0; k < i; k++) {
      for (int m = 0; m < this.nChannels; m++)
      {
        int n = (int)(k / d) * 2 * this.nChannels + 2 * m;
        int i1 = this.data[n] << 8 | this.data[(n + 1)] & 0xFF;
        arrayOfByte[(j++)] = ((byte)(i1 >> 8));
        arrayOfByte[(j++)] = ((byte)(i1 & 0xFF));
      }
    }
    this.data = arrayOfByte;
    this.frameCount = i;
    this.format = new AudioFormat(this.frameRate, 16, this.nChannels, true, true);
  }
  
  private AudioFileFormat.Type getFormatForFile(String paramString)
  {
    paramString = paramString.toLowerCase();
    if (paramString.endsWith(".wav")) {
      return AudioFileFormat.Type.WAVE;
    }
    if (paramString.endsWith(".aif")) {
      return AudioFileFormat.Type.AIFF;
    }
    if (paramString.endsWith(".aiff")) {
      return AudioFileFormat.Type.AIFF;
    }
    return AudioFileFormat.Type.AU;
  }
  
  private void readSound(AudioInputStream paramAudioInputStream)
  {
    this.format = paramAudioInputStream.getFormat();
    this.nChannels = this.format.getChannels();
    this.frameRate = this.format.getFrameRate();
    long l = paramAudioInputStream.getFrameLength();
    if (l > 2147483647L) {
      throw new ErrorException("SoundClip: Sound file is too large");
    }
    this.frameCount = ((int)l);
    if (this.frameCount < 0) {
      this.data = new byte[10000];
    } else {
      this.data = new byte[this.frameCount * this.nChannels * 2];
    }
    int i = 0;
    int j = 0;
    while (j == 0)
    {
      int k = this.data.length - i;
      while (k > 0) {
        try
        {
          int m = paramAudioInputStream.read(this.data, i, k);
          if (m == 0)
          {
            j = 1;
          }
          else
          {
            i += m;
            k -= m;
          }
        }
        catch (IOException localIOException)
        {
          throw new ErrorException(localIOException);
        }
      }
      if (this.frameCount >= 0) {
        j = 1;
      }
      if (j == 0)
      {
        byte[] arrayOfByte2 = new byte[2 * this.data.length];
        System.arraycopy(this.data, 0, arrayOfByte2, 0, this.data.length);
        this.data = arrayOfByte2;
      }
    }
    if ((i < this.data.length) && (this.frameCount < 0))
    {
      byte[] arrayOfByte1 = new byte[i];
      System.arraycopy(this.data, 0, arrayOfByte1, 0, i);
      this.data = arrayOfByte1;
    }
    if (this.frameCount < 0) {
      this.frameCount = (i / (2 * this.nChannels));
    }
  }
  
  private AudioInputStream convertToPCM(AudioInputStream paramAudioInputStream)
  {
    AudioFormat localAudioFormat = paramAudioInputStream.getFormat();
    localAudioFormat = new AudioFormat(localAudioFormat.getSampleRate(), 16, localAudioFormat.getChannels(), true, true);
    return AudioSystem.getAudioInputStream(localAudioFormat, paramAudioInputStream);
  }
  
  private AudioInputStream getAudioInputStream(InputStream paramInputStream)
  {
    try
    {
      if (!(paramInputStream instanceof BufferedInputStream)) {
        paramInputStream = new BufferedInputStream(paramInputStream);
      }
      return AudioSystem.getAudioInputStream(paramInputStream);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      throw new ErrorException(createUnsupportedFormatMessage());
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  private AudioInputStream getAudioInputStream(File paramFile)
  {
    try
    {
      return AudioSystem.getAudioInputStream(paramFile);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      throw new ErrorException(createUnsupportedFormatMessage());
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  private String createUnsupportedFormatMessage()
  {
    int i = this.soundName.lastIndexOf('.');
    if (i == -1) {
      return "Unsupported audio file format";
    }
    return "The " + this.soundName.substring(i + 1) + " format is not supported by JavaSound";
  }
}
