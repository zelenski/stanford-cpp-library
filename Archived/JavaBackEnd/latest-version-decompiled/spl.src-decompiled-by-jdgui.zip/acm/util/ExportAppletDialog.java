package acm.util;

import acm.program.Program;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.io.File;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;

class ExportAppletDialog
  extends JFileChooser
{
  private JCheckBox exportFilesCheckBox;
  private Component target;
  
  public ExportAppletDialog(File paramFile, Program paramProgram)
  {
    super(paramFile);
    setFileSelectionMode(1);
    setDialogTitle("Export Applet");
    String str1 = paramProgram.getClass().getName();
    String str2 = str1.substring(str1.lastIndexOf('.') + 1);
    setSelectedFile(new File(paramFile, str2));
    this.exportFilesCheckBox = new JCheckBox("Export resource files");
    this.exportFilesCheckBox.setSelected(true);
    this.target = paramProgram;
  }
  
  protected JDialog createDialog(Component paramComponent)
  {
    JDialog localJDialog = super.createDialog(paramComponent);
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new FlowLayout(0));
    localJPanel.add(this.exportFilesCheckBox);
    localJDialog.getContentPane().add(localJPanel, "South");
    localJDialog.validate();
    return localJDialog;
  }
  
  public File chooseOutputDirectory()
  {
    int i = showSaveDialog(this.target);
    if (i == 1) {
      return null;
    }
    return getSelectedFile();
  }
  
  public boolean exportFiles()
  {
    return this.exportFilesCheckBox.isSelected();
  }
}
