package acm.util;

import java.io.IOException;
import java.io.OutputStream;

final class Gif89Put
{
  static void ascii(String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[paramString.length()];
    for (int i = 0; i < arrayOfByte.length; i++) {
      arrayOfByte[i] = ((byte)paramString.charAt(i));
    }
    paramOutputStream.write(arrayOfByte);
  }
  
  static void leShort(int paramInt, OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(paramInt & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
  }
}
