package acm.util;

import java.applet.AudioClip;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class SunAudioClip
  implements AudioClip
{
  private static boolean initialized;
  private static Class<?> audioPlayerClass;
  private static Class<?> audioStreamClass;
  private static Class<?> audioDataClass;
  private static Class<?> audioDataStreamClass;
  private static Class<?> continuousAudioDataStreamClass;
  private static Constructor<?> audioDataConstructor;
  private static Constructor<?> audioDataStreamConstructor;
  private static Constructor<?> continuousAudioDataStreamConstructor;
  private static Method getData;
  private Object player;
  private Object audioData;
  private Object audioDataStream;
  private Object continuousAudioDataStream;
  private Method audioPlayerStart;
  private Method audioPlayerStop;
  
  public SunAudioClip(InputStream paramInputStream)
  {
    if (!initialized)
    {
      initStaticData();
      initialized = true;
    }
    try
    {
      Object[] arrayOfObject = { paramInputStream };
      Object localObject = audioDataConstructor.newInstance(arrayOfObject);
      this.audioData = getData.invoke(localObject, new Object[0]);
      this.player = audioPlayerClass.getField("player").get(null);
      Class[] arrayOfClass = { Class.forName("java.io.InputStream") };
      this.audioPlayerStart = this.player.getClass().getMethod("start", arrayOfClass);
      this.audioPlayerStop = this.player.getClass().getMethod("stop", arrayOfClass);
    }
    catch (Exception localException) {}
  }
  
  public void play()
  {
    try
    {
      Object[] arrayOfObject = { this.audioData };
      this.audioDataStream = audioDataStreamConstructor.newInstance(arrayOfObject);
      arrayOfObject[0] = this.audioDataStream;
      this.audioPlayerStart.invoke(this.player, arrayOfObject);
    }
    catch (Exception localException) {}
  }
  
  public void loop()
  {
    try
    {
      Object[] arrayOfObject = { this.audioData };
      this.continuousAudioDataStream = continuousAudioDataStreamConstructor.newInstance(arrayOfObject);
      arrayOfObject[0] = this.continuousAudioDataStream;
      this.audioPlayerStart.invoke(this.player, arrayOfObject);
    }
    catch (Exception localException) {}
  }
  
  public void stop()
  {
    try
    {
      Object[] arrayOfObject = new Object[1];
      if (this.continuousAudioDataStream != null)
      {
        arrayOfObject[0] = this.audioDataStream;
        this.audioPlayerStop.invoke(this.player, arrayOfObject);
      }
      if (this.audioDataStream != null)
      {
        arrayOfObject[0] = this.continuousAudioDataStream;
        this.audioPlayerStop.invoke(this.player, arrayOfObject);
      }
    }
    catch (Exception localException) {}
  }
  
  private static void initStaticData()
  {
    try
    {
      audioPlayerClass = Class.forName("sun.audio.AudioPlayer");
      audioStreamClass = Class.forName("sun.audio.AudioStream");
      audioDataClass = Class.forName("sun.audio.AudioData");
      audioDataStreamClass = Class.forName("sun.audio.AudioDataStream");
      continuousAudioDataStreamClass = Class.forName("sun.audio.ContinuousAudioDataStream");
      Class[] arrayOfClass1 = { Class.forName("java.io.InputStream") };
      audioDataConstructor = audioStreamClass.getConstructor(arrayOfClass1);
      getData = audioStreamClass.getMethod("getData", new Class[0]);
      Class[] arrayOfClass2 = { audioDataClass };
      audioDataStreamConstructor = audioDataStreamClass.getConstructor(arrayOfClass2);
      continuousAudioDataStreamConstructor = continuousAudioDataStreamClass.getConstructor(arrayOfClass2);
    }
    catch (Exception localException) {}
  }
}
