package acm.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

class MailStream
  extends PrintStream
{
  private static final int SMTP_PORT = 25;
  
  public MailStream(String paramString1, String paramString2, String paramString3)
  {
    super(new NullOutputStream());
    try
    {
      this.sender = paramString2;
      this.recipient = paramString3;
      this.socket = new Socket(paramString1, 25);
      this.out = new BufferedOutputStream(this.socket.getOutputStream());
      this.in = new BufferedInputStream(this.socket.getInputStream());
      verify("220");
      println("HELO " + InetAddress.getLocalHost().getHostName());
      verify("250");
      println("MAIL FROM: " + this.sender);
      verify("250");
      StringTokenizer localStringTokenizer = new StringTokenizer(paramString3, " ,");
      while (localStringTokenizer.hasMoreTokens())
      {
        println("RCPT TO: " + localStringTokenizer.nextToken());
        verify("250");
      }
      println("DATA");
      verify("354");
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void print(boolean paramBoolean)
  {
    print("" + paramBoolean);
  }
  
  public void print(char paramChar)
  {
    print("" + paramChar);
  }
  
  public void print(int paramInt)
  {
    print("" + paramInt);
  }
  
  public void print(long paramLong)
  {
    print("" + paramLong);
  }
  
  public void print(float paramFloat)
  {
    print("" + paramFloat);
  }
  
  public void print(double paramDouble)
  {
    print("" + paramDouble);
  }
  
  public void print(char[] paramArrayOfChar)
  {
    print(new String(paramArrayOfChar));
  }
  
  public void print(String paramString)
  {
    write(paramString);
  }
  
  public void print(Object paramObject)
  {
    print("" + paramObject);
  }
  
  public void println()
  {
    try
    {
      this.out.write(10);
      this.out.flush();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void println(boolean paramBoolean)
  {
    print(paramBoolean);
    println();
  }
  
  public void println(char paramChar)
  {
    print(paramChar);
    println();
  }
  
  public void println(int paramInt)
  {
    print(paramInt);
    println();
  }
  
  public void println(long paramLong)
  {
    print(paramLong);
    println();
  }
  
  public void println(float paramFloat)
  {
    print(paramFloat);
    println();
  }
  
  public void println(double paramDouble)
  {
    print(paramDouble);
    println();
  }
  
  public void println(char[] paramArrayOfChar)
  {
    print(paramArrayOfChar);
    println();
  }
  
  public void println(String paramString)
  {
    print(paramString);
    println();
  }
  
  public void println(Object paramObject)
  {
    print(paramObject);
    println();
  }
  
  public void write(int paramInt)
  {
    try
    {
      if (paramInt > 255) {
        throw new ErrorException("Illegal character in mail stream");
      }
      this.out.write(paramInt);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    try
    {
      for (int i = 0; i < paramInt2; i++)
      {
        int j = paramArrayOfChar[(paramInt1 + i)];
        if (j > 255) {
          throw new ErrorException("Illegal character in mail stream");
        }
        this.out.write(j);
      }
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void write(char[] paramArrayOfChar)
  {
    write(paramArrayOfChar, 0, paramArrayOfChar.length);
  }
  
  public void write(String paramString)
  {
    try
    {
      for (int i = 0; i < paramString.length(); i++)
      {
        int j = paramString.charAt(i);
        if (j > 255) {
          throw new ErrorException("Illegal character in mail stream");
        }
        this.out.write(j);
      }
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public boolean checkError()
  {
    return false;
  }
  
  public void flush()
  {
    try
    {
      this.out.flush();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void close()
  {
    try
    {
      println(".");
      verify("250");
      this.out.close();
      this.socket.close();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void cancel()
  {
    try
    {
      this.socket.close();
      this.out.close();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public void sendStandardHeaders(String paramString1, String paramString2)
  {
    println("To: " + this.recipient);
    if ((paramString1 != null) && (paramString1.length() != 0))
    {
      int i = 0;
      for (int j = 0; j < paramString1.length(); j++)
      {
        char c = paramString1.charAt(j);
        if ((c != ' ') && (c != '-') && (!Character.isJavaIdentifierPart(c)))
        {
          i = 1;
          break;
        }
      }
      if (i != 0) {
        this.sender = ('"' + paramString1 + '"' + " <" + this.sender + ">");
      } else {
        this.sender = (paramString1 + " <" + this.sender + ">");
      }
    }
    println("From: " + this.sender);
    if ((paramString2 != null) && (paramString2.length() != 0)) {
      println("Subject: " + paramString2);
    }
    println("Date: " + RFC2822_DATE_FORMAT.format(new Date()));
  }
  
  private void verify(String paramString)
  {
    try
    {
      String str = "";
      for (;;)
      {
        int i = this.in.read();
        if ((i == -1) || (i == 10)) {
          break;
        }
        str = str + (char)i;
      }
      if ((paramString != null) && (!str.startsWith(paramString))) {
        throw new ErrorException("Unexpected SMTP response: " + str);
      }
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  private static SimpleDateFormat RFC2822_DATE_FORMAT = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
  private Socket socket;
  private InputStream in;
  private OutputStream out;
  private String sender;
  private String recipient;
}
