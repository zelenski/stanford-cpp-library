package acm.util;

import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.lang.reflect.Method;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class SpeedBarListener
  implements AdjustmentListener, ChangeListener
{
  private Animator animator;
  private Object speedBar;
  private Method getValue;
  private Method getMinimum;
  private Method getMaximum;
  
  public static void register(Animator paramAnimator, Object paramObject)
  {
    SpeedBarListener localSpeedBarListener = new SpeedBarListener();
    localSpeedBarListener.animator = paramAnimator;
    localSpeedBarListener.speedBar = paramObject;
    Class localClass = paramObject.getClass();
    Method localMethod = lookForMethod(localClass, "addAdjustmentListener");
    if (localMethod == null) {
      localMethod = lookForMethod(localClass, "addChangeListener");
    }
    if (localMethod == null) {
      localMethod = lookForMethod(localClass, "addChangeListener");
    }
    try
    {
      localSpeedBarListener.getValue = localClass.getMethod("getValue", new Class[0]);
      localSpeedBarListener.getMinimum = localClass.getMethod("getMinimum", new Class[0]);
      localSpeedBarListener.getMaximum = localClass.getMethod("getMaximum", new Class[0]);
      Object[] arrayOfObject = { localSpeedBarListener };
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Exception localException)
    {
      throw new ErrorException("Illegal speed bar object");
    }
    localSpeedBarListener.setSpeed();
  }
  
  public void adjustmentValueChanged(AdjustmentEvent paramAdjustmentEvent)
  {
    setSpeed();
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    setSpeed();
  }
  
  public void setSpeed()
  {
    try
    {
      int i = ((Integer)this.getMinimum.invoke(this.speedBar, new Object[0])).intValue();
      int j = ((Integer)this.getMaximum.invoke(this.speedBar, new Object[0])).intValue();
      int k = ((Integer)this.getValue.invoke(this.speedBar, new Object[0])).intValue();
      double d = (k - i) / (j - i);
      this.animator.setSpeed(d);
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  private static Method lookForMethod(Class<?> paramClass, String paramString)
  {
    Method[] arrayOfMethod = paramClass.getMethods();
    for (int i = 0; i < arrayOfMethod.length; i++) {
      if (paramString.equals(arrayOfMethod[i].getName())) {
        return arrayOfMethod[i];
      }
    }
    return null;
  }
}
