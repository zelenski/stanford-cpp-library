package acm.util;

import java.awt.Image;
import java.awt.image.PixelGrabber;
import java.io.IOException;

class DirectGif89Frame
  extends Gif89Frame
{
  private int[] argbPixels;
  
  public DirectGif89Frame(Image paramImage)
    throws IOException
  {
    PixelGrabber localPixelGrabber = new PixelGrabber(paramImage, 0, 0, -1, -1, true);
    
    String str = null;
    try
    {
      if (!localPixelGrabber.grabPixels()) {
        str = "can't grab pixels from image";
      }
    }
    catch (InterruptedException localInterruptedException)
    {
      str = "interrupted grabbing pixels from image";
    }
    if (str != null) {
      throw new IOException(str + " (" + getClass().getName() + ")");
    }
    this.theWidth = localPixelGrabber.getWidth();
    this.theHeight = localPixelGrabber.getHeight();
    this.argbPixels = ((int[])localPixelGrabber.getPixels());
    this.ciPixels = new byte[this.argbPixels.length];
  }
  
  public DirectGif89Frame(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    this.theWidth = paramInt1;
    this.theHeight = paramInt2;
    this.argbPixels = new int[this.theWidth * this.theHeight];
    System.arraycopy(paramArrayOfInt, 0, this.argbPixels, 0, this.argbPixels.length);
    this.ciPixels = new byte[this.argbPixels.length];
  }
  
  Object getPixelSource()
  {
    return this.argbPixels;
  }
}
