package acm.util;

import java.awt.Color;
import java.util.Random;

public class RandomGenerator
  extends Random
{
  private static RandomGenerator standardInstance;
  static final long serialVersionUID = 1L;
  
  public int nextInt(int paramInt)
  {
    return nextInt(0, paramInt - 1);
  }
  
  public boolean nextBoolean()
  {
    return nextBoolean(0.5D);
  }
  
  public int nextInt(int paramInt1, int paramInt2)
  {
    return paramInt1 + (int)((paramInt2 - paramInt1 + 1) * nextDouble());
  }
  
  public double nextDouble(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 + (paramDouble2 - paramDouble1) * nextDouble();
  }
  
  public boolean nextBoolean(double paramDouble)
  {
    return nextDouble() < paramDouble;
  }
  
  public Color nextColor()
  {
    return new Color(nextInt(256), nextInt(256), nextInt(256));
  }
  
  public static RandomGenerator getInstance()
  {
    if (standardInstance == null) {
      standardInstance = new RandomGenerator();
    }
    return standardInstance;
  }
}
