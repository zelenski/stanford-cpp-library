package acm.util;

import java.applet.AudioClip;

class NullAudioClip
  implements AudioClip
{
  public void play() {}
  
  public void loop() {}
  
  public void stop() {}
}
