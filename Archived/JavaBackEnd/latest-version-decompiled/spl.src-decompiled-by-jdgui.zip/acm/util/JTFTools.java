package acm.util;

import acm.program.Program;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.swing.JFileChooser;
import javax.swing.JProgressBar;

public class JTFTools
{
  public static void pause(double paramDouble)
  {
    Applet localApplet = (Applet)appletTable.get(Thread.currentThread());
    if (localApplet == null)
    {
      localApplet = mostRecentApplet;
      appletTable.put(Thread.currentThread(), localApplet);
    }
    try
    {
      int i = (int)paramDouble;
      int j = (int)Math.round((paramDouble - i) * 1000000.0D);
      Thread.sleep(i, j);
    }
    catch (InterruptedException localInterruptedException) {}
  }
  
  public static String toHexString(int paramInt)
  {
    return Integer.toHexString(paramInt).toUpperCase();
  }
  
  public static String toHexString(int paramInt1, int paramInt2)
  {
    String str = toHexString(paramInt1);
    while (str.length() < paramInt2) {
      str = "0" + str;
    }
    return str;
  }
  
  public static Container createEmptyContainer()
  {
    return new EmptyContainer();
  }
  
  public static Frame getEnclosingFrame(Component paramComponent)
  {
    if ((paramComponent instanceof Program)) {
      paramComponent = ((Program)paramComponent).getContentPane();
    }
    while ((paramComponent != null) && (!(paramComponent instanceof Frame))) {
      paramComponent = paramComponent.getParent();
    }
    return (Frame)paramComponent;
  }
  
  public static Font getStandardFont(Font paramFont)
  {
    if (!fontFamilyTableInitialized) {
      initFontFamilyTable();
    }
    if ((paramFont == null) || (fontFamilyTable == null)) {
      return paramFont;
    }
    String str = paramFont.getFamily();
    if (fontFamilyTable.get(trimFamilyName(str)) != null) {
      return paramFont;
    }
    if ((str.equals("Serif")) || (str.equals("Times"))) {
      str = getFirstAvailableFontSubstitution(SERIF_SUBSTITUTIONS);
    } else if (str.equals("SansSerif")) {
      str = getFirstAvailableFontSubstitution(SANSSERIF_SUBSTITUTIONS);
    } else if (str.equals("Monospaced")) {
      str = getFirstAvailableFontSubstitution(MONOSPACED_SUBSTITUTIONS);
    } else {
      return paramFont;
    }
    if (str == null) {
      return paramFont;
    }
    return new Font(str, paramFont.getStyle(), paramFont.getSize());
  }
  
  public static String[] getFontList()
  {
    if (!fontFamilyTableInitialized) {
      initFontFamilyTable();
    }
    return fontFamilyArray;
  }
  
  public static String findFontFamily(String paramString)
  {
    if (!fontFamilyTableInitialized) {
      initFontFamilyTable();
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ";", false);
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = (String)fontFamilyTable.get(trimFamilyName(localStringTokenizer.nextToken()));
      if (str != null) {
        return str;
      }
    }
    return null;
  }
  
  public static Font decodeFont(String paramString)
  {
    return decodeFont(paramString, null);
  }
  
  public static Font decodeFont(String paramString, Font paramFont)
  {
    String str1 = paramString;
    int i = paramFont == null ? 0 : paramFont.getStyle();
    int j = paramFont == null ? 12 : paramFont.getSize();
    int k = paramString.indexOf('-');
    if (k >= 0)
    {
      str1 = paramString.substring(0, k);
      paramString = paramString.substring(k + 1).toLowerCase();
      String str2 = paramString;
      k = paramString.indexOf('-');
      if (k >= 0)
      {
        str2 = paramString.substring(0, k);
        paramString = paramString.substring(k + 1);
      }
      else
      {
        paramString = "*";
      }
      if (Character.isDigit(str2.charAt(0)))
      {
        String str3 = str2;
        str2 = paramString;
        paramString = str3;
      }
      if (str2.equals("plain")) {
        i = 0;
      } else if (str2.equals("bold")) {
        i = 1;
      } else if (str2.equals("italic")) {
        i = 2;
      } else if (str2.equals("bolditalic")) {
        i = 3;
      } else if (!str2.equals("*")) {
        throw new ErrorException("Illegal font style");
      }
      if (!paramString.equals("*")) {
        try
        {
          j = Integer.valueOf(paramString).intValue();
        }
        catch (NumberFormatException localNumberFormatException)
        {
          throw new ErrorException("Illegal font size");
        }
      }
    }
    if (str1.equals("*"))
    {
      str1 = paramFont == null ? "Default" : paramFont.getName();
    }
    else
    {
      if (!fontFamilyTableInitialized) {
        initFontFamilyTable();
      }
      if (fontFamilyTable != null)
      {
        str1 = (String)fontFamilyTable.get(trimFamilyName(str1));
        if (str1 == null) {
          str1 = "Default";
        }
      }
    }
    return getStandardFont(new Font(str1, i, j));
  }
  
  public static Color decodeColor(String paramString)
  {
    if (paramString.equalsIgnoreCase("desktop")) {
      return SystemColor.desktop;
    }
    if (paramString.equalsIgnoreCase("activeCaption")) {
      return SystemColor.activeCaption;
    }
    if (paramString.equalsIgnoreCase("activeCaptionText")) {
      return SystemColor.activeCaptionText;
    }
    if (paramString.equalsIgnoreCase("activeCaptionBorder")) {
      return SystemColor.activeCaptionBorder;
    }
    if (paramString.equalsIgnoreCase("inactiveCaption")) {
      return SystemColor.inactiveCaption;
    }
    if (paramString.equalsIgnoreCase("inactiveCaptionText")) {
      return SystemColor.inactiveCaptionText;
    }
    if (paramString.equalsIgnoreCase("inactiveCaptionBorder")) {
      return SystemColor.inactiveCaptionBorder;
    }
    if (paramString.equalsIgnoreCase("window")) {
      return SystemColor.window;
    }
    if (paramString.equalsIgnoreCase("windowBorder")) {
      return SystemColor.windowBorder;
    }
    if (paramString.equalsIgnoreCase("windowText")) {
      return SystemColor.windowText;
    }
    if (paramString.equalsIgnoreCase("menu")) {
      return SystemColor.menu;
    }
    if (paramString.equalsIgnoreCase("menuText")) {
      return SystemColor.menuText;
    }
    if (paramString.equalsIgnoreCase("text")) {
      return SystemColor.text;
    }
    if (paramString.equalsIgnoreCase("textText")) {
      return SystemColor.textText;
    }
    if (paramString.equalsIgnoreCase("textHighlight")) {
      return SystemColor.textHighlight;
    }
    if (paramString.equalsIgnoreCase("textHighlightText")) {
      return SystemColor.textHighlightText;
    }
    if (paramString.equalsIgnoreCase("textInactiveText")) {
      return SystemColor.textInactiveText;
    }
    if (paramString.equalsIgnoreCase("control")) {
      return SystemColor.control;
    }
    if (paramString.equalsIgnoreCase("controlText")) {
      return SystemColor.controlText;
    }
    if (paramString.equalsIgnoreCase("controlHighlight")) {
      return SystemColor.controlHighlight;
    }
    if (paramString.equalsIgnoreCase("controlLtHighlight")) {
      return SystemColor.controlLtHighlight;
    }
    if (paramString.equalsIgnoreCase("controlShadow")) {
      return SystemColor.controlShadow;
    }
    if (paramString.equalsIgnoreCase("controlDkShadow")) {
      return SystemColor.controlDkShadow;
    }
    if (paramString.equalsIgnoreCase("scrollbar")) {
      return SystemColor.scrollbar;
    }
    if (paramString.equalsIgnoreCase("info")) {
      return SystemColor.info;
    }
    if (paramString.equalsIgnoreCase("infoText")) {
      return SystemColor.infoText;
    }
    if (paramString.equalsIgnoreCase("black")) {
      return Color.BLACK;
    }
    if (paramString.equalsIgnoreCase("blue")) {
      return Color.BLUE;
    }
    if (paramString.equalsIgnoreCase("cyan")) {
      return Color.CYAN;
    }
    if (paramString.equalsIgnoreCase("darkGray")) {
      return Color.DARK_GRAY;
    }
    if (paramString.equalsIgnoreCase("DARK_GRAY")) {
      return Color.DARK_GRAY;
    }
    if (paramString.equalsIgnoreCase("gray")) {
      return Color.GRAY;
    }
    if (paramString.equalsIgnoreCase("green")) {
      return Color.GREEN;
    }
    if (paramString.equalsIgnoreCase("lightGray")) {
      return Color.LIGHT_GRAY;
    }
    if (paramString.equalsIgnoreCase("LIGHT_GRAY")) {
      return Color.LIGHT_GRAY;
    }
    if (paramString.equalsIgnoreCase("magenta")) {
      return Color.MAGENTA;
    }
    if (paramString.equalsIgnoreCase("orange")) {
      return Color.ORANGE;
    }
    if (paramString.equalsIgnoreCase("pink")) {
      return Color.PINK;
    }
    if (paramString.equalsIgnoreCase("red")) {
      return Color.RED;
    }
    if (paramString.equalsIgnoreCase("white")) {
      return Color.WHITE;
    }
    if (paramString.equalsIgnoreCase("yellow")) {
      return Color.YELLOW;
    }
    try
    {
      if (paramString.startsWith("0x")) {
        paramString = paramString.substring(2);
      } else if (paramString.startsWith("#")) {
        paramString = paramString.substring(1);
      }
      int i = paramString.length();
      int j = 255;
      if (i == 8)
      {
        j = Integer.parseInt(paramString.substring(0, 2), 16);
        paramString = paramString.substring(2);
      }
      else if (i != 6)
      {
        throw new ErrorException("decodeColor: Colors must have 6 or 8 hexadecimal digits");
      }
      return new Color(Integer.parseInt(paramString, 16) | j << 24, true);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new ErrorException("decodeColor: Illegal color value");
    }
  }
  
  public static String showOpenDialog(String paramString1, String paramString2)
  {
    FileChooserFilter localFileChooserFilter = new FileChooserFilter(paramString2);
    JFileChooser localJFileChooser = new JFileChooser(localFileChooserFilter.getDirectory());
    localJFileChooser.setFileFilter(localFileChooserFilter);
    localJFileChooser.setDialogTitle(paramString1);
    if (localJFileChooser.showOpenDialog(null) == 0) {
      return localJFileChooser.getSelectedFile().getAbsolutePath();
    }
    return "";
  }
  
  public static String showSaveDialog(String paramString1, String paramString2)
  {
    FileChooserFilter localFileChooserFilter = new FileChooserFilter(paramString2);
    String str = localFileChooserFilter.getDirectory();
    JFileChooser localJFileChooser = new JFileChooser(str);
    localJFileChooser.setSelectedFile(new File(str, localFileChooserFilter.getPattern()));
    localJFileChooser.setDialogTitle(paramString1);
    if (localJFileChooser.showSaveDialog(null) == 0) {
      return localJFileChooser.getSelectedFile().getAbsolutePath();
    }
    return "";
  }
  
  public static boolean matchFilenamePattern(String paramString1, String paramString2)
  {
    return recursiveMatch(paramString1, 0, paramString2, 0);
  }
  
  public static void registerApplet(Applet paramApplet)
  {
    registerApplet(paramApplet, Thread.currentThread());
    mostRecentApplet = paramApplet;
  }
  
  public static void registerApplet(Applet paramApplet, Thread paramThread)
  {
    appletTable.put(paramThread, paramApplet);
  }
  
  public static Applet getApplet()
  {
    Applet localApplet = (Applet)appletTable.get(Thread.currentThread());
    if (localApplet == null) {
      localApplet = mostRecentApplet;
    }
    return localApplet;
  }
  
  public static void setDebugOptions(String paramString)
  {
    debugOptions = "+" + paramString.toLowerCase() + "+";
  }
  
  public static boolean testDebugOption(String paramString)
  {
    if (debugOptions == null) {
      return false;
    }
    return debugOptions.indexOf("+" + paramString.toLowerCase() + "+") >= 0;
  }
  
  public static String getCommandLine()
  {
    switch ()
    {
    case 1: 
    case 2: 
      return getShellCommandLine();
    case 3: 
      return DOSCommandLine.getCommandLine();
    }
    return getShellCommandLine();
  }
  
  public static String getMainClass()
  {
    String str1 = null;
    try
    {
      str1 = System.getProperty("java.main");
    }
    catch (Exception localException) {}
    if (str1 == null) {
      str1 = readMainClassFromClassPath();
    }
    if (str1 == null)
    {
      String str2 = getCommandLine();
      str1 = readMainClassFromCommandLine(str2);
    }
    return str1;
  }
  
  public static boolean checkIfLoaded(String paramString)
  {
    if (Platform.compareVersion("1.2") < 0) {
      return false;
    }
    boolean bool = false;
    try
    {
      if (System.getSecurityManager() != null) {
        return false;
      }
      if (managerThatFails == null) {
        try
        {
          Class localClass = Class.forName("acm.util.SecurityManagerThatFails");
          managerThatFails = (SecurityManager)localClass.newInstance();
        }
        catch (Exception localException1)
        {
          return false;
        }
      }
      System.setSecurityManager(managerThatFails);
      try
      {
        bool = Class.forName(paramString) != null;
      }
      catch (ExceptionInInitializerError localExceptionInInitializerError)
      {
        bool = true;
      }
      catch (NoClassDefFoundError localNoClassDefFoundError) {}finally
      {
        System.setSecurityManager(null);
      }
    }
    catch (Exception localException2) {}
    return bool;
  }
  
  public static void terminateAppletThreads(Applet paramApplet)
  {
    try
    {
      Thread localThread1 = Thread.currentThread();
      Class localClass = Class.forName("java.lang.Thread");
      Method localMethod = localClass.getMethod("stop", new Class[0]);
      Iterator localIterator = appletTable.keySet().iterator();
      while (localIterator.hasNext())
      {
        Thread localThread2 = (Thread)localIterator.next();
        if ((localThread2 != localThread1) && (localThread2.isAlive()) && (isAnonymous(localThread2)) && (paramApplet == appletTable.get(localThread2))) {
          localMethod.invoke(localThread2, new Object[0]);
        }
      }
    }
    catch (Exception localException) {}
  }
  
  public static boolean isAnonymous(Thread paramThread)
  {
    String str = paramThread.getName();
    if (!str.startsWith("Thread-")) {
      return false;
    }
    for (int i = 7; i < str.length(); i++) {
      if (!Character.isDigit(str.charAt(i))) {
        return false;
      }
    }
    return true;
  }
  
  public static PrintStream openMailStream(String paramString1, String paramString2, String paramString3)
  {
    return new MailStream(paramString1, paramString2, paramString3);
  }
  
  public static void cancelMail(PrintStream paramPrintStream)
  {
    ((MailStream)paramPrintStream).cancel();
  }
  
  public static void sendStandardHeaders(PrintStream paramPrintStream, String paramString1, String paramString2)
  {
    ((MailStream)paramPrintStream).sendStandardHeaders(paramString1, paramString2);
  }
  
  public static OutputStream openHexByteOutputStream(PrintStream paramPrintStream)
  {
    return new HexByteOutputStream(paramPrintStream);
  }
  
  public static OutputStream openBase64OutputStream(PrintStream paramPrintStream)
  {
    return new Base64OutputStream(paramPrintStream);
  }
  
  public static void padBase64OutputStream(OutputStream paramOutputStream)
  {
    ((Base64OutputStream)paramOutputStream).pad();
  }
  
  public static void exportJar(File paramFile1, File paramFile2, String paramString, Object paramObject)
  {
    try
    {
      ZipOutputStream localZipOutputStream = new ZipOutputStream(new FileOutputStream(paramFile1));
      dumpJarAndResources("", paramFile2, localZipOutputStream, null, paramString, null, false, paramObject);
      localZipOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public static boolean executeExportAction(Program paramProgram, String paramString)
  {
    if ((paramString.equals("Export Applet")) || (paramString.equals("Submit Project")))
    {
      new Thread(new ThreadedMenuAction(paramProgram, paramString)).start();
      return true;
    }
    return false;
  }
  
  public static String getLocalHostName()
  {
    try
    {
      InetAddress localInetAddress = InetAddress.getLocalHost();
      Class localClass = localInetAddress.getClass();
      Method localMethod = localClass.getMethod("getCanonicalHostName", new Class[0]);
      return (String)localMethod.invoke(localInetAddress, new Object[0]);
    }
    catch (Exception localException) {}
    return null;
  }
  
  public static void copyFile(File paramFile1, File paramFile2)
  {
    try
    {
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile1));
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramFile2));
      copyBytes(localBufferedInputStream, localBufferedOutputStream, paramFile1.length());
      localBufferedInputStream.close();
      localBufferedOutputStream.close();
      Platform.copyFileTypeAndCreator(paramFile1, paramFile2);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  public static void copyBytes(InputStream paramInputStream, OutputStream paramOutputStream, long paramLong)
    throws IOException
  {
    byte[] arrayOfByte = new byte[4096];
    while (paramLong > 0L)
    {
      int i = (int)Math.min(4096L, paramLong);
      i = paramInputStream.read(arrayOfByte, 0, i);
      if (i == -1) {
        return;
      }
      paramOutputStream.write(arrayOfByte, 0, i);
      paramLong -= i;
    }
  }
  
  static String getURLSuffix(String paramString)
  {
    return paramString.substring(paramString.lastIndexOf('/') + 1);
  }
  
  static void exportApplet(Program paramProgram, JProgressBar paramJProgressBar)
  {
    try
    {
      String str1 = paramProgram.getClass().getName();
      String str2 = str1.substring(str1.lastIndexOf(".") + 1);
      File localFile1 = new File(System.getProperty("user.dir"));
      File localFile2 = new File(System.getProperty("user.home"));
      ExportAppletDialog localExportAppletDialog = new ExportAppletDialog(localFile2, paramProgram);
      File localFile3 = localExportAppletDialog.chooseOutputDirectory();
      if (localFile3 == null) {
        return;
      }
      if (localFile3.exists())
      {
        if (!localFile3.isDirectory()) {
          localFile3 = new File(localFile3.getParent());
        }
      }
      else {
        localFile3.mkdir();
      }
      if (paramJProgressBar != null)
      {
        paramJProgressBar.setMaximum(countResources(localFile1, RESOURCE_EXTENSIONS, "acm.jar") + 1);
        ProgressBarDialog.popup(paramJProgressBar);
      }
      File localFile4 = new File(localFile1, "index.html");
      if (localFile4.canRead()) {
        copyFile(localFile4, new File(localFile3, "index.html"));
      } else {
        dumpHTMLIndex(localFile3, paramProgram, str1, str2);
      }
      if (paramJProgressBar != null)
      {
        if (ProgressBarDialog.hasBeenCancelled(paramJProgressBar)) {
          return;
        }
        paramJProgressBar.setValue(paramJProgressBar.getValue() + 1);
      }
      dumpJarAndResources(localFile1, localFile3, str2 + ".jar", "acm.jar", paramJProgressBar, localExportAppletDialog.exportFiles(), null);
      if (paramJProgressBar != null) {
        ProgressBarDialog.dismiss(paramJProgressBar);
      }
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  private static void initFontFamilyTable()
  {
    fontFamilyTableInitialized = true;
    for (int i = 1; (fontFamilyArray == null) && (i <= 2); i++) {
      try
      {
        Class localClass;
        Method localMethod1;
        if (i == 1)
        {
          localClass = Class.forName("java.awt.GraphicsEnvironment");
          localMethod1 = localClass.getMethod("getLocalGraphicsEnvironment", new Class[0]);
          Method localMethod2 = localClass.getMethod("getAvailableFontFamilyNames", new Class[0]);
          Object localObject = localMethod1.invoke(null, new Object[0]);
          fontFamilyArray = (String[])localMethod2.invoke(localObject, new Object[0]);
        }
        else
        {
          localClass = Class.forName("java.awt.Toolkit");
          localMethod1 = localClass.getMethod("getFontList", new Class[0]);
          fontFamilyArray = (String[])localMethod1.invoke(Toolkit.getDefaultToolkit(), new Object[0]);
        }
      }
      catch (Exception localException) {}
    }
    fontFamilyTable = new HashMap();
    for (i = 0; i < fontFamilyArray.length; i++) {
      fontFamilyTable.put(trimFamilyName(fontFamilyArray[i]), fontFamilyArray[i]);
    }
    fontFamilyTable.put("serif", getFirstAvailableFontSubstitution(SERIF_SUBSTITUTIONS));
    fontFamilyTable.put("sansserif", getFirstAvailableFontSubstitution(SANSSERIF_SUBSTITUTIONS));
    fontFamilyTable.put("monospaced", getFirstAvailableFontSubstitution(MONOSPACED_SUBSTITUTIONS));
  }
  
  private static String getFirstAvailableFontSubstitution(String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (fontFamilyTable.get(trimFamilyName(paramArrayOfString[i])) != null) {
        return paramArrayOfString[i];
      }
    }
    return null;
  }
  
  private static String trimFamilyName(String paramString)
  {
    String str = "";
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if ((c != ' ') && (c != '-')) {
        str = str + Character.toLowerCase(c);
      }
    }
    return str;
  }
  
  private static boolean recursiveMatch(String paramString1, int paramInt1, String paramString2, int paramInt2)
  {
    int i = paramString1.length();
    int j = paramString2.length();
    if (paramInt2 == j) {
      return paramInt1 == i;
    }
    int k = paramString2.charAt(paramInt2);
    if (k == 42)
    {
      for (m = paramInt1; m <= i; m++) {
        if (recursiveMatch(paramString1, m, paramString2, paramInt2 + 1)) {
          return true;
        }
      }
      return false;
    }
    if (paramInt1 == i) {
      return false;
    }
    int m = paramString1.charAt(paramInt1);
    if (k == 91)
    {
      int n = 0;
      int i1 = 0;
      paramInt2++;
      if (paramInt2 == j) {
        throw new ErrorException("matchFilenamePattern: missing ]");
      }
      if (paramString2.charAt(paramInt2) == '^')
      {
        paramInt2++;
        i1 = 1;
      }
      while ((paramInt2 < j) && (paramString2.charAt(paramInt2) != ']')) {
        if ((paramInt2 + 2 < j) && (paramString2.charAt(paramInt2 + 1) == '-'))
        {
          n |= ((m >= paramString2.charAt(paramInt2)) && (m <= paramString2.charAt(paramInt2 + 2)) ? 1 : 0);
          paramInt2 += 3;
        }
        else
        {
          n |= (m == paramString2.charAt(paramInt2) ? 1 : 0);
          paramInt2++;
        }
      }
      if (paramInt2 == j) {
        throw new ErrorException("matchFilenamePattern: missing ]");
      }
      if (n == i1) {
        return false;
      }
    }
    else if ((k != 63) && 
      (k != m))
    {
      return false;
    }
    return recursiveMatch(paramString1, paramInt1 + 1, paramString2, paramInt2 + 1);
  }
  
  private static String getShellCommandLine()
  {
    try
    {
      String str = Platform.isMac() ? "command" : "args";
      String[] arrayOfString = { "bash", "-c", "ps -p $PPID -o " + str };
      Process localProcess = Runtime.getRuntime().exec(arrayOfString);
      localProcess.waitFor();
      if (localProcess.getErrorStream().read() != -1) {
        return null;
      }
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localProcess.getInputStream()));
      localBufferedReader.readLine();
      return localBufferedReader.readLine();
    }
    catch (Exception localException) {}
    return null;
  }
  
  private static String readMainClassFromManifest(String paramString)
  {
    try
    {
      if (testDebugOption("main")) {
        System.out.println("Read class from JAR manifest in " + paramString);
      }
      ZipFile localZipFile = new ZipFile(paramString);
      ZipEntry localZipEntry = localZipFile.getEntry("META-INF/MANIFEST.MF");
      if (localZipEntry == null) {
        return null;
      }
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localZipFile.getInputStream(localZipEntry)));
      for (String str1 = localBufferedReader.readLine(); str1 != null; str1 = localBufferedReader.readLine()) {
        if (str1.startsWith("Main-Class:"))
        {
          String str2 = str1.substring("Main-Class:".length()).trim();
          if (testDebugOption("main")) {
            System.out.println("Main class = " + str2);
          }
          return str2;
        }
      }
      return null;
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  private static String readMainClassFromCommandLine(String paramString)
  {
    if (testDebugOption("main")) {
      System.out.println("Read class from command line: " + paramString);
    }
    if (paramString == null) {
      return null;
    }
    int i = 0;
    try
    {
      StreamTokenizer localStreamTokenizer = new StreamTokenizer(new StringReader(paramString));
      localStreamTokenizer.resetSyntax();
      localStreamTokenizer.wordChars(33, 255);
      localStreamTokenizer.quoteChar(34);
      localStreamTokenizer.quoteChar(39);
      localStreamTokenizer.whitespaceChars(32, 32);
      localStreamTokenizer.whitespaceChars(9, 9);
      int j = 0;
      for (;;)
      {
        int k = localStreamTokenizer.nextToken();
        String str = localStreamTokenizer.sval;
        switch (k)
        {
        case -1: 
          return null;
        case -3: 
        case 34: 
        case 39: 
          break;
        default: 
          return null;
        }
        if (j != 0)
        {
          if (str.startsWith("-"))
          {
            if (str.equals("-jar")) {
              i = 1;
            } else if ((str.equals("-cp")) || (str.equals("-classpath"))) {
              localStreamTokenizer.nextToken();
            }
          }
          else
          {
            if (i != 0) {
              return readMainClassFromManifest(str);
            }
            if (testDebugOption("main")) {
              System.out.println("Main class = " + str);
            }
            return str;
          }
        }
        else {
          j = 1;
        }
      }
      return null;
    }
    catch (IOException localIOException) {}
  }
  
  private static String readMainClassFromClassPath()
  {
    Object localObject1 = null;
    String str1 = System.getProperty("java.class.path");
    if (str1 == null) {
      str1 = System.getProperty("user.dir");
    }
    if (str1 == null) {
      return null;
    }
    if (testDebugOption("main")) {
      System.out.println("Read class from class path: " + str1);
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str1, ":;");
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken();
      File localFile = new File(str2);
      String[] arrayOfString = null;
      Object localObject2;
      Object localObject3;
      if (localFile.isDirectory()) {
        arrayOfString = localFile.list();
      } else if ((str2.endsWith(".jar")) && (!nameAppears(str2, SKIP_JARS))) {
        try
        {
          ZipFile localZipFile = new ZipFile(localFile);
          localObject2 = new ArrayList();
          localObject3 = localZipFile.entries();
          while (((Enumeration)localObject3).hasMoreElements()) {
            ((ArrayList)localObject2).add(((ZipEntry)((Enumeration)localObject3).nextElement()).getName());
          }
          arrayOfString = new String[((ArrayList)localObject2).size()];
          for (int j = 0; j < arrayOfString.length; j++) {
            arrayOfString[j] = ((String)((ArrayList)localObject2).get(j));
          }
        }
        catch (IOException localIOException)
        {
          arrayOfString = null;
        }
      }
      if (arrayOfString != null) {
        for (int i = 0; i < arrayOfString.length; i++)
        {
          localObject2 = arrayOfString[i];
          if (((String)localObject2).endsWith(".class"))
          {
            localObject3 = ((String)localObject2).substring(0, ((String)localObject2).lastIndexOf(".class"));
            if ((((String)localObject3).indexOf("/") == -1) && (checkIfLoaded((String)localObject3))) {
              try
              {
                Class localClass = Class.forName((String)localObject3);
                Class[] arrayOfClass = { arrayOfString.getClass() };
                if (localClass.getMethod("main", arrayOfClass) != null)
                {
                  if (testDebugOption("main")) {
                    System.out.println("Main class = " + (String)localObject3);
                  }
                  if (localObject1 != null) {
                    return null;
                  }
                  localObject1 = localObject3;
                }
              }
              catch (Exception localException) {}
            }
          }
        }
      }
    }
    return localObject1;
  }
  
  protected static void submitProject(Program paramProgram, JProgressBar paramJProgressBar)
  {
    SubmitOptions localSubmitOptions = getOptions(paramProgram);
    if ((localSubmitOptions.popup()) && (localSubmitOptions.isComplete()))
    {
      String str1 = paramProgram.getClass().getName();
      String str2 = str1.substring(str1.lastIndexOf(".") + 1);
      String str3 = "==" + System.currentTimeMillis() + "==";
      String str4 = localSubmitOptions.getSMTPServer();
      String str5 = localSubmitOptions.getAuthorName();
      String str6 = localSubmitOptions.getAuthorEMail();
      String str7 = localSubmitOptions.getSubmissionEMail();
      String str8 = str6;
      int i = str6.indexOf("@");
      if (i != -1) {
        str8 = str8.substring(0, i);
      }
      String str9 = str2 + "_" + str8;
      File localFile = new File(System.getProperty("user.dir"));
      if (paramJProgressBar != null)
      {
        paramJProgressBar.setMaximum(countResources(localFile, SUBMIT_EXTENSIONS, null));
        ProgressBarDialog.popup(paramJProgressBar);
      }
      PrintStream localPrintStream = openMailStream(str4, str6, str7);
      sendStandardHeaders(localPrintStream, str5, str2);
      localPrintStream.println("Mime-Version: 1.0");
      localPrintStream.println("Content-Type: multipart/mixed; boundary=\"" + str3 + '"');
      localPrintStream.println();
      localPrintStream.println("--" + str3);
      localPrintStream.println("Content-Transfer-Encoding: base64");
      localPrintStream.println("Content-Type: application/zip; name=" + str9 + ".zip");
      localPrintStream.println("Content-Disposition: attachment; filename=" + str9 + ".zip");
      submitDirectory(localPrintStream, str9, paramJProgressBar);
      if (ProgressBarDialog.hasBeenCancelled(paramJProgressBar)) {
        cancelMail(localPrintStream);
      }
      localPrintStream.println("--" + str3 + "--");
      localPrintStream.close();
      if (paramJProgressBar != null) {
        ProgressBarDialog.dismiss(paramJProgressBar);
      }
    }
  }
  
  private static void dumpHTMLIndex(File paramFile, Program paramProgram, String paramString1, String paramString2)
    throws IOException
  {
    File localFile = new File(paramFile, "index.html");
    PrintWriter localPrintWriter = new PrintWriter(new FileWriter(localFile));
    Dimension localDimension = paramProgram.getSize();
    localPrintWriter.println("<html>");
    localPrintWriter.println("<head>");
    localPrintWriter.println("<meta name=\"generator\" content=\"ACM Java Libraries V1.1\">");
    localPrintWriter.println("<title>" + paramString2 + "</title>");
    localPrintWriter.println("</head>");
    localPrintWriter.println("<body>");
    localPrintWriter.println("<center>");
    localPrintWriter.println("<table border=2 cellpadding=0 cellspacing=0>");
    localPrintWriter.println("<tr><td>");
    localPrintWriter.println("<applet archive=\"" + paramString2 + ".jar\"");
    localPrintWriter.println("        code=\"" + paramString1.replace('.', '/') + ".class\"");
    localPrintWriter.println("        width=" + localDimension.width + " height=" + localDimension.height + ">");
    localPrintWriter.println("</applet>");
    localPrintWriter.println("</td></tr>");
    localPrintWriter.println("</table>");
    localPrintWriter.println("</center>");
    localPrintWriter.println("</body>");
    localPrintWriter.println("</html>");
    localPrintWriter.close();
  }
  
  private static void dumpJarAndResources(File paramFile1, File paramFile2, String paramString1, String paramString2, JProgressBar paramJProgressBar, boolean paramBoolean, Object paramObject)
    throws IOException
  {
    File localFile = new File(paramFile2, paramString1);
    ZipOutputStream localZipOutputStream = new ZipOutputStream(new FileOutputStream(localFile));
    dumpJarAndResources("", paramFile1, localZipOutputStream, paramFile2, paramString2, paramJProgressBar, paramBoolean, paramObject);
    localZipOutputStream.close();
  }
  
  private static void dumpJarAndResources(String paramString1, File paramFile1, ZipOutputStream paramZipOutputStream, File paramFile2, String paramString2, JProgressBar paramJProgressBar, boolean paramBoolean, Object paramObject)
    throws IOException
  {
    if (ProgressBarDialog.hasBeenCancelled(paramJProgressBar)) {
      return;
    }
    dumpTree(paramString1, paramFile1, paramZipOutputStream, paramFile2, paramJProgressBar, 0, paramBoolean, paramObject);
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString2, ";");
    while (localStringTokenizer.hasMoreTokens())
    {
      String str1 = localStringTokenizer.nextToken().trim();
      File localFile = getLibrary(str1);
      if (localFile != null)
      {
        ZipFile localZipFile = new ZipFile(localFile);
        Enumeration localEnumeration = localZipFile.entries();
        while (localEnumeration.hasMoreElements())
        {
          ZipEntry localZipEntry = (ZipEntry)localEnumeration.nextElement();
          String str2 = localZipEntry.getName();
          if (!nameAppears(str2, SKIP_FILES))
          {
            BufferedInputStream localBufferedInputStream = new BufferedInputStream(localZipFile.getInputStream(localZipEntry));
            if ((paramObject != null) && (str2.endsWith(".class")))
            {
              localZipEntry = new ZipEntry(str2);
              paramZipOutputStream.putNextEntry(localZipEntry);
              transformClass(paramObject, localBufferedInputStream, paramZipOutputStream);
            }
            else
            {
              paramZipOutputStream.putNextEntry(localZipEntry);
              copyBytes(localBufferedInputStream, paramZipOutputStream, localZipEntry.getSize());
            }
            for (;;)
            {
              int i = localBufferedInputStream.read();
              if (i == -1) {
                break;
              }
              paramZipOutputStream.write(i);
            }
            paramZipOutputStream.closeEntry();
            localBufferedInputStream.close();
          }
          if (paramJProgressBar != null) {
            paramJProgressBar.setValue(paramJProgressBar.getValue() + 1);
          }
        }
      }
    }
  }
  
  private static void dumpTree(String paramString, File paramFile1, ZipOutputStream paramZipOutputStream, File paramFile2, JProgressBar paramJProgressBar, int paramInt, boolean paramBoolean, Object paramObject)
    throws IOException
  {
    if (ProgressBarDialog.hasBeenCancelled(paramJProgressBar)) {
      return;
    }
    String str = paramFile1.getName();
    Object localObject;
    if (paramFile1.isDirectory())
    {
      localObject = paramFile1.list();
      if (paramInt > 0) {
        paramString = paramString + str + "/";
      }
      for (int i = 0; i < localObject.length; i++) {
        dumpTree(paramString, new File(paramFile1, localObject[i]), paramZipOutputStream, paramFile2, paramJProgressBar, paramInt + 1, paramBoolean, paramObject);
      }
    }
    else if (isResourceComponent(str))
    {
      localObject = paramString + str;
      if (((String)localObject).startsWith("Java Classes/")) {
        localObject = ((String)localObject).substring(((String)localObject).indexOf('/') + 1);
      }
      ZipEntry localZipEntry = new ZipEntry((String)localObject);
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile1));
      paramZipOutputStream.putNextEntry(localZipEntry);
      if ((paramObject != null) && (str.endsWith(".class"))) {
        transformClass(paramObject, localBufferedInputStream, paramZipOutputStream);
      } else {
        copyBytes(localBufferedInputStream, paramZipOutputStream, paramFile1.length());
      }
      localBufferedInputStream.close();
      if ((paramBoolean) && (paramFile2 != null) && (!str.endsWith(".class")))
      {
        localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile1));
        paramFile2 = new File(paramFile2, paramString);
        File localFile = new File(paramFile2, str);
        paramFile2.mkdirs();
        BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(localFile));
        copyBytes(localBufferedInputStream, localBufferedOutputStream, paramFile1.length());
        localBufferedInputStream.close();
        localBufferedOutputStream.close();
      }
      if (paramJProgressBar != null) {
        paramJProgressBar.setValue(paramJProgressBar.getValue() + 1);
      }
    }
  }
  
  private static void transformClass(Object paramObject, InputStream paramInputStream, OutputStream paramOutputStream)
  {
    Method localMethod = null;
    try
    {
      Class[] arrayOfClass = { Class.forName("java.io.InputStream"), Class.forName("java.io.OutputStream") };
      localMethod = paramObject.getClass().getMethod("transform", arrayOfClass);
    }
    catch (Exception localException1)
    {
      throw new ErrorException("exportJar: Illegal class transformer object");
    }
    try
    {
      Object[] arrayOfObject = { paramInputStream, paramOutputStream };
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Exception localException2)
    {
      throw new ErrorException(localException2);
    }
  }
  
  private static int countResources(File paramFile, String[] paramArrayOfString, String paramString)
  {
    String str = paramFile.getName();
    int i = 0;
    if (paramFile.isDirectory())
    {
      String[] arrayOfString = paramFile.list();
      for (int k = 0; k < arrayOfString.length; k++) {
        i += countResources(new File(paramFile, arrayOfString[k]), paramArrayOfString, null);
      }
    }
    else
    {
      for (int j = 0; (j < paramArrayOfString.length) && (i == 0); j++) {
        if (str.endsWith(paramArrayOfString[j])) {
          i = 1;
        }
      }
    }
    if (paramString != null)
    {
      File localFile = getLibrary(paramString);
      if (localFile != null) {
        try
        {
          ZipFile localZipFile = new ZipFile(localFile);
          for (Enumeration localEnumeration = localZipFile.entries(); localEnumeration.hasMoreElements(); localEnumeration.nextElement()) {
            i++;
          }
        }
        catch (IOException localIOException) {}
      }
    }
    return i;
  }
  
  private static File getLibrary(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    File localFile = new File(paramString);
    if ((paramString.startsWith(".")) || (localFile.isAbsolute())) {
      return localFile;
    }
    String str = System.getProperty("java.class.path");
    if (str == null) {
      str = "";
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str, ":");
    while (localStringTokenizer.hasMoreTokens())
    {
      localObject = localStringTokenizer.nextToken();
      if ((((String)localObject).equals(paramString)) || (((String)localObject).endsWith("/" + paramString))) {
        return new File((String)localObject);
      }
    }
    Object localObject = new File(System.getProperty("user.dir"));
    localFile = new File((File)localObject, paramString);
    return localFile.exists() ? localFile : null;
  }
  
  private static boolean isResourceComponent(String paramString)
  {
    for (int i = 0; i < RESOURCE_EXTENSIONS.length; i++) {
      if (paramString.endsWith(RESOURCE_EXTENSIONS[i])) {
        return true;
      }
    }
    return false;
  }
  
  private static void submitDirectory(PrintStream paramPrintStream, String paramString, JProgressBar paramJProgressBar)
  {
    try
    {
      OutputStream localOutputStream = openBase64OutputStream(paramPrintStream);
      ZipOutputStream localZipOutputStream1 = new ZipOutputStream(new BufferedOutputStream(localOutputStream));
      ZipOutputStream localZipOutputStream2 = new ZipOutputStream(new NullOutputStream());
      File localFile = new File(System.getProperty("user.dir"));
      dumpZip(paramString + "/", localFile, localZipOutputStream1, localZipOutputStream2, true, paramJProgressBar);
      localZipOutputStream2.close();
      localZipOutputStream1.finish();
      localZipOutputStream1.flush();
      padBase64OutputStream(localOutputStream);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException(localIOException);
    }
  }
  
  private static void dumpZip(String paramString, File paramFile, ZipOutputStream paramZipOutputStream1, ZipOutputStream paramZipOutputStream2, boolean paramBoolean, JProgressBar paramJProgressBar)
    throws IOException
  {
    if (ProgressBarDialog.hasBeenCancelled(paramJProgressBar)) {
      return;
    }
    String str = paramFile.getName();
    Object localObject;
    if (paramFile.isDirectory())
    {
      localObject = paramFile.list();
      if (!paramBoolean) {
        paramString = paramString + str + "/";
      }
      for (int i = 0; i < localObject.length; i++) {
        dumpZip(paramString, new File(paramFile, localObject[i]), paramZipOutputStream1, paramZipOutputStream2, false, paramJProgressBar);
      }
    }
    else if (isSubmitComponent(str))
    {
      localObject = paramString + str;
      ZipEntry localZipEntry = new ZipEntry((String)localObject);
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile));
      if (paramZipOutputStream2 != null)
      {
        paramZipOutputStream2.putNextEntry(localZipEntry);
        copyBytes(localBufferedInputStream, paramZipOutputStream2, paramFile.length());
        paramZipOutputStream2.closeEntry();
        localBufferedInputStream.close();
        localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile));
      }
      paramZipOutputStream1.putNextEntry(localZipEntry);
      copyBytes(localBufferedInputStream, paramZipOutputStream1, paramFile.length());
      paramZipOutputStream1.closeEntry();
      localBufferedInputStream.close();
      if (paramJProgressBar != null) {
        paramJProgressBar.setValue(paramJProgressBar.getValue() + 1);
      }
    }
  }
  
  private static boolean isSubmitComponent(String paramString)
  {
    for (int i = 0; i < SUBMIT_EXTENSIONS.length; i++) {
      if (paramString.endsWith(SUBMIT_EXTENSIONS[i])) {
        return true;
      }
    }
    return false;
  }
  
  private static SubmitOptions getOptions(Program paramProgram)
  {
    SubmitOptions localSubmitOptions = (SubmitOptions)optionsTable.get(paramProgram);
    if (localSubmitOptions == null)
    {
      localSubmitOptions = new SubmitOptions(paramProgram);
      optionsTable.put(paramProgram, localSubmitOptions);
    }
    return localSubmitOptions;
  }
  
  private static boolean nameAppears(String paramString, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i].equals(paramString)) {
        return true;
      }
    }
    return false;
  }
  
  private static final String[] SKIP_FILES = { ".DS_Store", "FINDER.DAT", "RESOURCE.FRK" };
  private static final String[] RESOURCE_EXTENSIONS = { ".txt", ".dat", ".gif", ".jpg", ".jpeg", ".png", ".au", ".wav", ".class" };
  private static final String[] SUBMIT_EXTENSIONS = { ".java", ".html", ".txt", ".dat", ".gif", ".jpg", ".jpeg", ".png", ".au", ".wav" };
  private static HashMap<Component, SubmitOptions> optionsTable = new HashMap();
  private static final int BUFFER_SIZE = 4096;
  private static final String[] SERIF_SUBSTITUTIONS = { "Serif", "Times", "TimesRoman", "Times-Roman" };
  private static final String[] SANSSERIF_SUBSTITUTIONS = { "SansSerif", "Helvetica", "Arial" };
  private static final String[] MONOSPACED_SUBSTITUTIONS = { "Monospaced", "Courier", "Monaco" };
  private static final String[] SKIP_JARS = { "acm.jar", "acm11.jar", "swingall.jar", "patchJTF.jar" };
  private static boolean fontFamilyTableInitialized = false;
  private static String[] fontFamilyArray = null;
  private static HashMap<String, String> fontFamilyTable = null;
  private static HashMap<Thread, Applet> appletTable = new HashMap();
  private static Applet mostRecentApplet = null;
  private static SecurityManager managerThatFails = null;
  private static String debugOptions = null;
}
