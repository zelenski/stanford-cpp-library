package acm.util;

import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class OptionTable
{
  private HashMap<String, String> optionTable;
  static final long serialVersionUID = 1L;
  
  public OptionTable(String paramString)
  {
    this(paramString, null);
  }
  
  public OptionTable(String paramString, String[] paramArrayOfString)
  {
    this.optionTable = new HashMap();
    try
    {
      StreamTokenizer localStreamTokenizer = createTokenizer(paramString);
      int i = localStreamTokenizer.nextToken();
      while (i != -1)
      {
        if (i != -3) {
          throw new ErrorException("Illegal option string: " + paramString);
        }
        String str = localStreamTokenizer.sval;
        if ((paramArrayOfString != null) && (!keyExists(str, paramArrayOfString))) {
          throw new ErrorException("Unrecognized option: " + str);
        }
        i = localStreamTokenizer.nextToken();
        if (i == 61)
        {
          i = localStreamTokenizer.nextToken();
          if ((i != -3) && (i != 34) && (i != 39)) {
            throw new ErrorException("Illegal option string: " + paramString);
          }
          this.optionTable.put(str, localStreamTokenizer.sval);
          i = localStreamTokenizer.nextToken();
        }
        else
        {
          this.optionTable.put(str, "");
        }
      }
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("Illegal option string: " + paramString);
    }
  }
  
  public OptionTable(Map<String, String> paramMap)
  {
    this.optionTable = new HashMap();
    for (Iterator localIterator = paramMap.keySet().iterator(); localIterator.hasNext();)
    {
      String str1 = (String)localIterator.next();
      String str2 = (String)paramMap.get(str1);
      this.optionTable.put(str1, str2);
    }
  }
  
  public boolean isSpecified(String paramString)
  {
    return this.optionTable.containsKey(paramString);
  }
  
  public String getOption(String paramString)
  {
    return getOption(paramString, null);
  }
  
  public String getOption(String paramString1, String paramString2)
  {
    String str = (String)this.optionTable.get(paramString1);
    return (str == null) || (str.equals("")) ? paramString2 : str;
  }
  
  public int getIntOption(String paramString)
  {
    return getIntOption(paramString, 0);
  }
  
  public int getIntOption(String paramString, int paramInt)
  {
    String str = getOption(paramString, null);
    if ((str == null) || (str.equals(""))) {
      return paramInt;
    }
    return Integer.decode(str).intValue();
  }
  
  public double getDoubleOption(String paramString)
  {
    return getDoubleOption(paramString, 0.0D);
  }
  
  public double getDoubleOption(String paramString, double paramDouble)
  {
    String str = getOption(paramString, null);
    if ((str == null) || (str.equals(""))) {
      return paramDouble;
    }
    return Double.valueOf(str).doubleValue();
  }
  
  public HashMap<String, String> getMap()
  {
    return this.optionTable;
  }
  
  private StreamTokenizer createTokenizer(String paramString)
  {
    StreamTokenizer localStreamTokenizer = new StreamTokenizer(new StringReader(paramString));
    localStreamTokenizer.resetSyntax();
    localStreamTokenizer.wordChars(33, 60);
    localStreamTokenizer.wordChars(62, 126);
    localStreamTokenizer.quoteChar(34);
    localStreamTokenizer.quoteChar(39);
    localStreamTokenizer.whitespaceChars(32, 32);
    localStreamTokenizer.whitespaceChars(9, 9);
    return localStreamTokenizer;
  }
  
  private boolean keyExists(String paramString, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramString.equals(paramArrayOfString[i])) {
        return true;
      }
    }
    return false;
  }
}
