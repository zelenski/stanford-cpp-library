package acm.util;

import java.awt.Image;

class TIFFImageSaver
  extends ImageSaver
{
  private static final int HEADER_SIZE = 8;
  private static final int IFD_OP_COUNT = 13;
  public static final int TT_BYTE = 1;
  public static final int TT_ASCII = 2;
  public static final int TT_SHORT = 3;
  public static final int TT_LONG = 4;
  public static final int TT_RATIONAL = 5;
  private int[][] pixels;
  private int width;
  private int height;
  private int offsetIFD;
  private int offsetNullIFD;
  private int offsetBitsPerSample;
  private int offsetXResolution;
  private int offsetYResolution;
  private int offsetStripPointers;
  private int offsetStripByteCounts;
  private int offsetData;
  private int stripDelta;
  
  public void saveImage(Image paramImage)
  {
    this.pixels = MediaTools.getPixelArray(paramImage);
    this.width = this.pixels[0].length;
    this.height = this.pixels.length;
    calculateOffsets();
    dumpHeader();
    dumpIFD();
    dumpNullIFD();
    dumpBitsPerSampleData();
    dumpResolutionData();
    dumpStripPointers();
    dumpStripByteCounts();
    dumpStripData();
  }
  
  private void dumpHeader()
  {
    dumpByte(77);
    dumpByte(77);
    dumpShort(42);
    dumpLong(8);
  }
  
  private void dumpIFD()
  {
    dumpShort(13);
    dumpIFDNewSubFileType();
    dumpIFDImageWidth();
    dumpIFDImageHeight();
    dumpIFDBitsPerSample();
    dumpIFDCompression();
    dumpIFDPhotometricInterpration();
    dumpIFDStripPointers();
    dumpIFDSamplesPerPixel();
    dumpIFDRowsPerStrip();
    dumpIFDStripByteCounts();
    dumpIFDXResolution();
    dumpIFDYResolution();
    dumpIFDResolutionUnit();
  }
  
  private void dumpIFDNewSubFileType()
  {
    dumpShort(254);
    dumpShort(4);
    dumpLong(1);
    dumpLong(0);
  }
  
  private void dumpIFDImageWidth()
  {
    dumpShort(256);
    dumpShort(4);
    dumpLong(1);
    dumpLong(this.width);
  }
  
  private void dumpIFDImageHeight()
  {
    dumpShort(257);
    dumpShort(4);
    dumpLong(1);
    dumpLong(this.height);
  }
  
  private void dumpIFDBitsPerSample()
  {
    dumpShort(258);
    dumpShort(4);
    dumpLong(3);
    dumpLong(this.offsetBitsPerSample);
  }
  
  private void dumpIFDCompression()
  {
    dumpShort(259);
    dumpShort(3);
    dumpLong(1);
    dumpShort(1);
    dumpShort(0);
  }
  
  private void dumpIFDPhotometricInterpration()
  {
    dumpShort(262);
    dumpShort(3);
    dumpLong(1);
    dumpShort(2);
    dumpShort(0);
  }
  
  private void dumpIFDStripPointers()
  {
    dumpShort(273);
    dumpShort(4);
    dumpLong(this.height);
    dumpLong(this.offsetStripPointers);
  }
  
  private void dumpIFDSamplesPerPixel()
  {
    dumpShort(277);
    dumpShort(3);
    dumpLong(1);
    dumpShort(3);
    dumpShort(0);
  }
  
  private void dumpIFDRowsPerStrip()
  {
    dumpShort(278);
    dumpShort(4);
    dumpLong(1);
    dumpLong(1);
  }
  
  private void dumpIFDStripByteCounts()
  {
    dumpShort(279);
    dumpShort(4);
    dumpLong(this.height);
    dumpLong(this.offsetStripByteCounts);
  }
  
  private void dumpIFDXResolution()
  {
    dumpShort(282);
    dumpShort(5);
    dumpLong(1);
    dumpLong(this.offsetXResolution);
  }
  
  private void dumpIFDYResolution()
  {
    dumpShort(283);
    dumpShort(5);
    dumpLong(1);
    dumpLong(this.offsetYResolution);
  }
  
  private void dumpIFDResolutionUnit()
  {
    dumpShort(296);
    dumpShort(3);
    dumpLong(1);
    dumpShort(1);
    dumpShort(0);
  }
  
  private void dumpNullIFD()
  {
    dumpLong(0);
  }
  
  private void dumpBitsPerSampleData()
  {
    dumpLong(8);
    dumpLong(8);
    dumpLong(8);
  }
  
  private void dumpResolutionData()
  {
    dumpLong(72);
    dumpLong(1);
    dumpLong(72);
    dumpLong(1);
  }
  
  private void dumpStripPointers()
  {
    for (int i = 0; i < this.height; i++) {
      dumpLong(this.offsetData + i * this.stripDelta);
    }
  }
  
  private void dumpStripByteCounts()
  {
    for (int i = 0; i < this.height; i++) {
      dumpLong(3 * this.width);
    }
  }
  
  private void dumpStripData()
  {
    for (int i = 0; i < this.height; i++)
    {
      for (int j = 0; j < this.width; j++)
      {
        int k = this.pixels[i][j];
        dumpByte(getPixelComponent(k, 'R'));
        dumpByte(getPixelComponent(k, 'G'));
        dumpByte(getPixelComponent(k, 'B'));
      }
      for (j = 3 * this.width; j < this.stripDelta; j++) {
        dumpByte(0);
      }
    }
  }
  
  private void calculateOffsets()
  {
    this.offsetIFD = 8;
    this.offsetNullIFD = (this.offsetIFD + 156 + 2);
    this.offsetBitsPerSample = (this.offsetNullIFD + 4);
    this.offsetXResolution = (this.offsetBitsPerSample + 12);
    this.offsetYResolution = (this.offsetXResolution + 8);
    this.offsetStripPointers = (this.offsetYResolution + 8);
    this.offsetStripByteCounts = (this.offsetStripPointers + 4 * this.height);
    this.offsetData = (this.offsetStripByteCounts + 4 * this.height);
    this.stripDelta = (3 * this.width + 3 & 0xFFFFFFFC);
  }
}
