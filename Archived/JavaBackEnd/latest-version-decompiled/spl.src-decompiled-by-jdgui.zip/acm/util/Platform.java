package acm.util;

import java.awt.Toolkit;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.StringTokenizer;

public class Platform
{
  public static final int UNKNOWN = 0;
  public static final int MAC = 1;
  public static final int UNIX = 2;
  public static final int WINDOWS = 3;
  private static final String JTF_VERSION = "1.99.1";
  
  public static int getPlatform()
  {
    if (platform != -1) {
      return platform;
    }
    String str = System.getProperty("os.name", "").toLowerCase();
    if (str.startsWith("mac")) {
      return Platform.platform = 1;
    }
    if (str.startsWith("windows")) {
      return Platform.platform = 3;
    }
    if (str.startsWith("microsoft")) {
      return Platform.platform = 3;
    }
    if (str.startsWith("ms")) {
      return Platform.platform = 3;
    }
    if (str.startsWith("unix")) {
      return Platform.platform = 2;
    }
    if (str.startsWith("linux")) {
      return Platform.platform = 2;
    }
    return Platform.platform = 0;
  }
  
  public static boolean isMac()
  {
    return getPlatform() == 1;
  }
  
  public static boolean isWindows()
  {
    return getPlatform() == 3;
  }
  
  public static boolean isUnix()
  {
    return getPlatform() == 2;
  }
  
  public static void setFileTypeAndCreator(String paramString1, String paramString2, String paramString3)
  {
    if (!isMac()) {
      return;
    }
    try
    {
      setFileTypeAndCreator(new File(paramString1), paramString2, paramString3);
    }
    catch (Exception localException) {}
  }
  
  public static void setFileTypeAndCreator(File paramFile, String paramString1, String paramString2)
  {
    if (!isMac()) {
      return;
    }
    try
    {
      Class localClass1 = Class.forName("com.apple.mrj.MRJOSType");
      Class localClass2 = Class.forName("com.apple.mrj.MRJFileUtils");
      Class[] arrayOfClass1 = { Class.forName("java.lang.String") };
      Constructor localConstructor = localClass1.getConstructor(arrayOfClass1);
      Class[] arrayOfClass2 = { Class.forName("java.io.File"), localClass1, localClass1 };
      Method localMethod = localClass2.getMethod("setFileTypeAndCreator", arrayOfClass2);
      Object[] arrayOfObject1 = { (paramString1 + "    ").substring(0, 4) };
      Object localObject1 = localConstructor.newInstance(arrayOfObject1);
      Object[] arrayOfObject2 = { (paramString2 + "    ").substring(0, 4) };
      Object localObject2 = localConstructor.newInstance(arrayOfObject2);
      Object[] arrayOfObject3 = { paramFile, localObject1, localObject2 };
      localMethod.invoke(null, arrayOfObject3);
    }
    catch (Exception localException) {}
  }
  
  public static void copyFileTypeAndCreator(File paramFile1, File paramFile2)
  {
    if (!isMac()) {
      return;
    }
    try
    {
      Class localClass1 = Class.forName("com.apple.mrj.MRJOSType");
      Class localClass2 = Class.forName("com.apple.mrj.MRJFileUtils");
      Class[] arrayOfClass1 = { Class.forName("java.io.File") };
      Method localMethod1 = localClass2.getMethod("getFileType", arrayOfClass1);
      Method localMethod2 = localClass2.getMethod("getFileCreator", arrayOfClass1);
      Class[] arrayOfClass2 = { Class.forName("java.io.File"), localClass1, localClass1 };
      Method localMethod3 = localClass2.getMethod("setFileTypeAndCreator", arrayOfClass2);
      Object[] arrayOfObject1 = { paramFile1 };
      Object localObject1 = localMethod1.invoke(null, arrayOfObject1);
      Object localObject2 = localMethod2.invoke(null, arrayOfObject1);
      Object[] arrayOfObject2 = { paramFile2, localObject1, localObject2 };
      localMethod3.invoke(null, arrayOfObject2);
    }
    catch (Exception localException) {}
  }
  
  public static String getJTFVersion()
  {
    return "1.99.1";
  }
  
  public static int compareVersion(String paramString)
  {
    return compareVersion(System.getProperty("java.version"), paramString);
  }
  
  public static int compareVersion(String paramString1, String paramString2)
  {
    StringTokenizer localStringTokenizer1 = new StringTokenizer(paramString1, ".");
    StringTokenizer localStringTokenizer2 = new StringTokenizer(paramString2, ".");
    while ((localStringTokenizer1.hasMoreTokens()) && (localStringTokenizer2.hasMoreTokens()))
    {
      int i = Integer.parseInt(localStringTokenizer1.nextToken());
      int j = Integer.parseInt(localStringTokenizer2.nextToken());
      if (i != j) {
        return i < j ? -1 : 1;
      }
    }
    if (localStringTokenizer1.hasMoreTokens()) {
      return 1;
    }
    if (localStringTokenizer2.hasMoreTokens()) {
      return -1;
    }
    return 0;
  }
  
  public static boolean isSwingAvailable()
  {
    if (!swingChecked)
    {
      swingChecked = true;
      isSwingAvailable = false;
      if (compareVersion("1.2") >= 0) {
        try
        {
          isSwingAvailable = Class.forName("javax.swing.JComponent") != null;
        }
        catch (Exception localException) {}
      }
    }
    return isSwingAvailable;
  }
  
  public static boolean isSunAudioAvailable()
  {
    if (!sunAudioChecked)
    {
      sunAudioChecked = true;
      try
      {
        isSunAudioAvailable = Class.forName("sun.audio.AudioPlayer") != null;
      }
      catch (Exception localException)
      {
        isSunAudioAvailable = false;
      }
    }
    return isSunAudioAvailable;
  }
  
  public static boolean isJMFAvailable()
  {
    if (!jmfChecked)
    {
      jmfChecked = true;
      try
      {
        isJMFAvailable = Class.forName("javax.media.Player") != null;
      }
      catch (Exception localException)
      {
        isJMFAvailable = false;
      }
    }
    return isJMFAvailable;
  }
  
  public static boolean areCollectionsAvailable()
  {
    if (!collectionsChecked)
    {
      collectionsChecked = true;
      try
      {
        areCollectionsAvailable = Class.forName("java.util.ArrayList") != null;
      }
      catch (Exception localException)
      {
        areCollectionsAvailable = false;
      }
    }
    return areCollectionsAvailable;
  }
  
  public static boolean areStandardFontFamiliesAvailable()
  {
    if (!fontsChecked)
    {
      fontsChecked = true;
      try
      {
        Class localClass = Class.forName("java.awt.Toolkit");
        Method localMethod = localClass.getMethod("getFontList", new Class[0]);
        String[] arrayOfString = (String[])localMethod.invoke(Toolkit.getDefaultToolkit(), new Object[0]);
        int i = 0;
        for (int j = 0; j < arrayOfString.length; j++) {
          if ((arrayOfString[j].equals("Serif")) || (arrayOfString[j].equals("SansSerif")) || (arrayOfString[j].equals("Monospaced"))) {
            i++;
          }
        }
        areStandardFontFamiliesAvailable = i == 3;
      }
      catch (Exception localException)
      {
        areStandardFontFamiliesAvailable = false;
      }
    }
    return areStandardFontFamiliesAvailable;
  }
  
  private static int platform = -1;
  private static boolean areStandardFontFamiliesAvailable;
  private static boolean fontsChecked;
  private static boolean isSwingAvailable;
  private static boolean swingChecked;
  private static boolean areCollectionsAvailable;
  private static boolean collectionsChecked;
  private static boolean isSunAudioAvailable;
  private static boolean sunAudioChecked;
  private static boolean isJMFAvailable;
  private static boolean jmfChecked;
}
