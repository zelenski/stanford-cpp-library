package acm.util;

import java.io.IOException;
import java.io.OutputStream;

class GifPixelsEncoder
{
  private static final int EOF = -1;
  private int imgW;
  private int imgH;
  private byte[] pixAry;
  private boolean wantInterlaced;
  private int initCodeSize;
  private int countDown;
  private int xCur;
  private int yCur;
  private int curPass;
  static final int BITS = 12;
  static final int HSIZE = 5003;
  int n_bits;
  
  GifPixelsEncoder(int paramInt1, int paramInt2, byte[] paramArrayOfByte, boolean paramBoolean, int paramInt3)
  {
    this.imgW = paramInt1;
    this.imgH = paramInt2;
    this.pixAry = paramArrayOfByte;
    this.wantInterlaced = paramBoolean;
    this.initCodeSize = Math.max(2, paramInt3);
  }
  
  void encode(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(this.initCodeSize);
    
    this.countDown = (this.imgW * this.imgH);
    this.xCur = (this.yCur = this.curPass = 0);
    
    compress(this.initCodeSize + 1, paramOutputStream);
    
    paramOutputStream.write(0);
  }
  
  private void bumpPosition()
  {
    this.xCur += 1;
    if (this.xCur == this.imgW)
    {
      this.xCur = 0;
      if (!this.wantInterlaced) {
        this.yCur += 1;
      } else {
        switch (this.curPass)
        {
        case 0: 
          this.yCur += 8;
          if (this.yCur >= this.imgH)
          {
            this.curPass += 1;
            this.yCur = 4;
          }
          break;
        case 1: 
          this.yCur += 8;
          if (this.yCur >= this.imgH)
          {
            this.curPass += 1;
            this.yCur = 2;
          }
          break;
        case 2: 
          this.yCur += 4;
          if (this.yCur >= this.imgH)
          {
            this.curPass += 1;
            this.yCur = 1;
          }
          break;
        case 3: 
          this.yCur += 2;
        }
      }
    }
  }
  
  private int nextPixel()
  {
    if (this.countDown == 0) {
      return -1;
    }
    this.countDown -= 1;
    
    int i = this.pixAry[(this.yCur * this.imgW + this.xCur)];
    
    bumpPosition();
    
    return i & 0xFF;
  }
  
  int maxbits = 12;
  int maxcode;
  int maxmaxcode = 4096;
  
  final int MAXCODE(int paramInt)
  {
    return (1 << paramInt) - 1;
  }
  
  int[] htab = new int[5003];
  int[] codetab = new int[5003];
  int hsize = 5003;
  int free_ent = 0;
  boolean clear_flg = false;
  int g_init_bits;
  int ClearCode;
  int EOFCode;
  
  void compress(int paramInt, OutputStream paramOutputStream)
    throws IOException
  {
    this.g_init_bits = paramInt;
    

    this.clear_flg = false;
    this.n_bits = this.g_init_bits;
    this.maxcode = MAXCODE(this.n_bits);
    
    this.ClearCode = (1 << paramInt - 1);
    this.EOFCode = (this.ClearCode + 1);
    this.free_ent = (this.ClearCode + 2);
    
    char_init();
    
    int m = nextPixel();
    
    int i2 = 0;
    for (int i = this.hsize; i < 65536; i *= 2) {
      i2++;
    }
    i2 = 8 - i2;
    
    int i1 = this.hsize;
    cl_hash(i1);
    
    output(this.ClearCode, paramOutputStream);
    int k;
    while ((k = nextPixel()) != -1)
    {
      i = (k << this.maxbits) + m;
      int j = k << i2 ^ m;
      if (this.htab[j] == i)
      {
        m = this.codetab[j];
      }
      else
      {
        if (this.htab[j] >= 0)
        {
          int n = i1 - j;
          if (j == 0) {
            n = 1;
          }
          do
          {
            if (j -= n < 0) {
              j += i1;
            }
            if (this.htab[j] == i)
            {
              m = this.codetab[j];
              break;
            }
          } while (this.htab[j] >= 0);
        }
        output(m, paramOutputStream);
        m = k;
        if (this.free_ent < this.maxmaxcode)
        {
          this.codetab[j] = (this.free_ent++);
          this.htab[j] = i;
        }
        else
        {
          cl_block(paramOutputStream);
        }
      }
    }
    output(m, paramOutputStream);
    output(this.EOFCode, paramOutputStream);
  }
  
  int cur_accum = 0;
  int cur_bits = 0;
  int[] masks = { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 };
  int a_count;
  
  void output(int paramInt, OutputStream paramOutputStream)
    throws IOException
  {
    this.cur_accum &= this.masks[this.cur_bits];
    if (this.cur_bits > 0) {
      this.cur_accum |= paramInt << this.cur_bits;
    } else {
      this.cur_accum = paramInt;
    }
    this.cur_bits += this.n_bits;
    while (this.cur_bits >= 8)
    {
      char_out((byte)(this.cur_accum & 0xFF), paramOutputStream);
      this.cur_accum >>= 8;
      this.cur_bits -= 8;
    }
    if ((this.free_ent > this.maxcode) || (this.clear_flg)) {
      if (this.clear_flg)
      {
        this.maxcode = MAXCODE(this.n_bits = this.g_init_bits);
        this.clear_flg = false;
      }
      else
      {
        this.n_bits += 1;
        if (this.n_bits == this.maxbits) {
          this.maxcode = this.maxmaxcode;
        } else {
          this.maxcode = MAXCODE(this.n_bits);
        }
      }
    }
    if (paramInt == this.EOFCode)
    {
      while (this.cur_bits > 0)
      {
        char_out((byte)(this.cur_accum & 0xFF), paramOutputStream);
        this.cur_accum >>= 8;
        this.cur_bits -= 8;
      }
      flush_char(paramOutputStream);
    }
  }
  
  void cl_block(OutputStream paramOutputStream)
    throws IOException
  {
    cl_hash(this.hsize);
    this.free_ent = (this.ClearCode + 2);
    this.clear_flg = true;
    
    output(this.ClearCode, paramOutputStream);
  }
  
  void cl_hash(int paramInt)
  {
    for (int i = 0; i < paramInt; i++) {
      this.htab[i] = -1;
    }
  }
  
  void char_init()
  {
    this.a_count = 0;
  }
  
  byte[] accum = new byte[256];
  
  void char_out(byte paramByte, OutputStream paramOutputStream)
    throws IOException
  {
    this.accum[(this.a_count++)] = paramByte;
    if (this.a_count >= 254) {
      flush_char(paramOutputStream);
    }
  }
  
  void flush_char(OutputStream paramOutputStream)
    throws IOException
  {
    if (this.a_count > 0)
    {
      paramOutputStream.write(this.a_count);
      paramOutputStream.write(this.accum, 0, this.a_count);
      this.a_count = 0;
    }
  }
}
