package acm.util;

import java.security.Permission;

class SecurityManagerThatFails
  extends SecurityManager
{
  public void checkRead(String paramString)
  {
    throw new SecurityException("always fail");
  }
  
  public void checkPermission(Permission paramPermission) {}
}
