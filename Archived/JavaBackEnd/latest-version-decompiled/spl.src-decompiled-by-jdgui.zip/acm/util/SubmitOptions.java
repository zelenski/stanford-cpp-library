package acm.util;

import acm.gui.TableLayout;
import acm.program.Program;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

class SubmitOptions
  implements ActionListener, DocumentListener
{
  private static final int FIELD_WIDTH = 300;
  private static final int DIALOG_WIDTH = 500;
  private static final int DIALOG_HEIGHT = 230;
  private static final int SMTP_PORT = 25;
  private Component parent;
  private JDialog dialog;
  private JTextField authorNameField;
  private JTextField authorEMailField;
  private JTextField instructorEMailField;
  private JTextField smtpServerField;
  private JButton cancelButton;
  private JButton submitButton;
  private boolean submitFlag;
  
  public SubmitOptions(Program paramProgram)
  {
    this.parent = paramProgram;
    this.authorNameField = new JTextField();
    this.authorEMailField = new JTextField();
    this.instructorEMailField = new JTextField();
    this.smtpServerField = new JTextField();
    this.cancelButton = new JButton("Cancel");
    this.submitButton = new JButton("Submit");
    this.authorEMailField.getDocument().addDocumentListener(this);
    this.instructorEMailField.getDocument().addDocumentListener(this);
    this.smtpServerField.getDocument().addDocumentListener(this);
    this.cancelButton.addActionListener(this);
    this.submitButton.addActionListener(this);
    initPreferences(paramProgram);
  }
  
  public String getAuthorName()
  {
    return this.authorNameField.getText().trim();
  }
  
  public String getAuthorEMail()
  {
    return this.authorEMailField.getText().trim();
  }
  
  public String getSubmissionEMail()
  {
    return this.instructorEMailField.getText().trim();
  }
  
  public String getSMTPServer()
  {
    return this.smtpServerField.getText().trim();
  }
  
  public boolean isComplete()
  {
    if (getAuthorEMail().indexOf('@') == -1) {
      return false;
    }
    if (getSubmissionEMail().indexOf('@') == -1) {
      return false;
    }
    if (getSMTPServer().length() == 0) {
      return false;
    }
    return true;
  }
  
  public boolean popup()
  {
    Frame localFrame = JTFTools.getEnclosingFrame(this.parent);
    if (localFrame == null) {
      return false;
    }
    this.dialog = new JDialog(localFrame, "Submit Project Options", true);
    Container localContainer = this.dialog.getContentPane();
    localContainer.setLayout(new TableLayout(6, 2, 0, 4));
    localContainer.add(new JLabel("Instructor email ", 4));
    localContainer.add(this.instructorEMailField, "width=300");
    localContainer.add(new JLabel("Author name ", 4));
    localContainer.add(this.authorNameField, "width=300");
    localContainer.add(new JLabel("Author email ", 4));
    localContainer.add(this.authorEMailField, "width=300");
    localContainer.add(new JLabel("SMTP server ", 4));
    localContainer.add(this.smtpServerField, "width=300");
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new FlowLayout());
    localJPanel.add(this.cancelButton);
    localJPanel.add(this.submitButton);
    localContainer.add(new JLabel(""));
    localContainer.add(localJPanel, "top=10");
    this.dialog.setSize(500, 230);
    this.submitFlag = false;
    this.submitButton.setEnabled(isComplete());
    this.dialog.setVisible(true);
    return this.submitFlag;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.submitFlag = (paramActionEvent.getSource() == this.submitButton);
    this.dialog.setVisible(false);
  }
  
  public void changedUpdate(DocumentEvent paramDocumentEvent)
  {
    this.submitButton.setEnabled(isComplete());
  }
  
  public void removeUpdate(DocumentEvent paramDocumentEvent)
  {
    this.submitButton.setEnabled(isComplete());
  }
  
  public void insertUpdate(DocumentEvent paramDocumentEvent)
  {
    this.submitButton.setEnabled(isComplete());
  }
  
  private void initPreferences(Program paramProgram)
  {
    this.instructorEMailField.setText(getDefaultField("INSTRUCTOR_EMAIL", paramProgram));
    this.authorNameField.setText(getDefaultField("AUTHOR_NAME", paramProgram));
    String str1 = getDefaultField("AUTHOR_EMAIL", paramProgram);
    if (str1.length() == 0)
    {
      str1 = System.getProperty("user.name");
      if (str1 == null)
      {
        str1 = "";
      }
      else
      {
        str2 = JTFTools.getLocalHostName();
        if (str2 != null) {
          str1 = str1 + "@" + str2;
        }
      }
    }
    this.authorEMailField.setText(str1);
    String str2 = getDefaultField("SMTP_SERVER", paramProgram);
    if (str2.length() == 0)
    {
      str2 = System.getProperty("mail.smtp.host");
      if (str2 == null)
      {
        String str3 = JTFTools.getLocalHostName();
        if (str3 == null)
        {
          str2 = "";
        }
        else
        {
          str2 = "smtp." + str3.substring(str3.indexOf('.') + 1);
          try
          {
            new Socket(str2, 25).close();
          }
          catch (Exception localException)
          {
            str2 = "";
          }
        }
      }
    }
    this.smtpServerField.setText(str2);
  }
  
  private String getDefaultField(String paramString, Program paramProgram)
  {
    try
    {
      Field localField = paramProgram.getClass().getField(paramString);
      String str = (String)localField.get(paramProgram);
      if ((str != null) && (str.trim().length() != 0)) {
        return str;
      }
    }
    catch (Exception localException) {}
    return "";
  }
}
