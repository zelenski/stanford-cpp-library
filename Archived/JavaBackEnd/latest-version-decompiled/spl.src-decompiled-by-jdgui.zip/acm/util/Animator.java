package acm.util;

import java.applet.Applet;
import java.awt.Component;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JScrollBar;
import javax.swing.JSlider;

public class Animator
  extends Thread
{
  public static final int INITIAL = 0;
  public static final int RUNNING = 1;
  public static final int STEPPING = 2;
  public static final int CALLING = 3;
  public static final int STOPPING = 4;
  public static final int STOPPED = 5;
  public static final int FINISHED = 6;
  public static final int TERMINATING = 7;
  private static final double SLOW_DELAY = 1000.0D;
  private static final double CLIP_DELAY = 200.0D;
  private static final double FAST_DELAY = 0.0D;
  
  public Animator()
  {
    initAnimator();
  }
  
  public Animator(ThreadGroup paramThreadGroup)
  {
    super(paramThreadGroup, (Runnable)null);
    initAnimator();
  }
  
  public Animator(Runnable paramRunnable)
  {
    super(paramRunnable);
    initAnimator();
  }
  
  public Animator(ThreadGroup paramThreadGroup, Runnable paramRunnable)
  {
    super(paramThreadGroup, paramRunnable);
    initAnimator();
  }
  
  public int getAnimatorState()
  {
    return this.animatorState;
  }
  
  public void pause(double paramDouble)
  {
    if (this.animatorState == 7) {
      terminate();
    }
    JTFTools.pause(paramDouble);
  }
  
  public void startAction()
  {
    start(1);
  }
  
  public void stopAction()
  {
    switch (this.animatorState)
    {
    case 1: 
    case 2: 
    case 3: 
      this.animatorState = 4;
      break;
    }
  }
  
  public void stepAction()
  {
    start(2);
  }
  
  public void callAction()
  {
    this.callDepth = this.currentDepth;
    start(3);
  }
  
  public boolean buttonAction(String paramString)
  {
    if (paramString.equals("Start")) {
      startAction();
    } else if (paramString.equals("Stop")) {
      stopAction();
    } else if (paramString.equals("Step")) {
      stepAction();
    } else if (paramString.equals("Call")) {
      callAction();
    } else {
      return false;
    }
    return true;
  }
  
  public void setSpeed(double paramDouble)
  {
    this.animatorSpeed = paramDouble;
    Object localObject;
    int i;
    int j;
    if ((this.speedBar instanceof JSlider))
    {
      localObject = (JSlider)this.speedBar;
      i = ((JSlider)localObject).getMinimum();
      j = ((JSlider)localObject).getMaximum();
      ((JSlider)localObject).setValue((int)Math.round(i + paramDouble * (j - i)));
    }
    else if ((this.speedBar instanceof JScrollBar))
    {
      localObject = (JScrollBar)this.speedBar;
      i = ((JScrollBar)localObject).getMinimum();
      j = ((JScrollBar)localObject).getMaximum();
      ((JScrollBar)localObject).setValue((int)Math.round(i + paramDouble * (j - i)));
    }
  }
  
  public double getSpeed()
  {
    return this.animatorSpeed;
  }
  
  public void trace()
  {
    trace(0);
  }
  
  public void trace(int paramInt)
  {
    if (Thread.currentThread() != this) {
      throw new ErrorException("trace() can be called only by the animator thread itself");
    }
    this.currentDepth = paramInt;
    switch (this.animatorState)
    {
    case 1: 
      delay();
      break;
    case 2: 
    case 4: 
      breakpoint();
      break;
    case 3: 
      if (this.callDepth < this.currentDepth) {
        delay();
      } else {
        breakpoint();
      }
      break;
    case 7: 
      terminate();
    }
  }
  
  public void breakpoint()
  {
    if (Thread.currentThread() != this) {
      throw new ErrorException("breakpoint() can be called only by the animator thread itself");
    }
    this.animatorState = 5;
    breakHook();
    suspendAnimator();
  }
  
  public void delay()
  {
    int i = 1;
    double d = 0.0D;
    if (this.animatorSpeed < 0.25D)
    {
      d = 1000.0D + this.animatorSpeed / 0.25D * -800.0D;
    }
    else if (this.animatorSpeed < 0.9D)
    {
      d = 200.0D + Math.sqrt((this.animatorSpeed - 0.25D) / 0.65D) * -200.0D;
    }
    else
    {
      switch ((int)(this.animatorSpeed * 99.989999999999995D - 90.0D))
      {
      case 0: 
        i = 1; break;
      case 1: 
        i = this.delayCount % 10 != 0 ? 1 : 0; break;
      case 2: 
        i = this.delayCount % 7 != 0 ? 1 : 0; break;
      case 3: 
        i = this.delayCount % 5 != 0 ? 1 : 0; break;
      case 4: 
        i = this.delayCount % 3 != 0 ? 1 : 0; break;
      case 5: 
        i = this.delayCount % 2 == 0 ? 1 : 0; break;
      case 6: 
        i = this.delayCount % 3 == 0 ? 1 : 0; break;
      case 7: 
        i = this.delayCount % 4 == 0 ? 1 : 0; break;
      case 8: 
        i = this.delayCount % 6 == 0 ? 1 : 0; break;
      case 9: 
        i = 0;
      }
      this.delayCount = ((this.delayCount + 1) % 420);
    }
    if (i != 0)
    {
      delayHook();
      JTFTools.pause(d);
    }
  }
  
  public void registerSpeedBar(JSlider paramJSlider)
  {
    SpeedBarListener.register(this, paramJSlider);
    this.speedBar = paramJSlider;
  }
  
  public void registerSpeedBar(JScrollBar paramJScrollBar)
  {
    SpeedBarListener.register(this, paramJScrollBar);
    this.speedBar = paramJScrollBar;
  }
  
  public Component getSpeedBar()
  {
    return this.speedBar;
  }
  
  public void requestTermination()
  {
    this.animatorState = 7;
  }
  
  public void checkForTermination()
  {
    if (this.animatorState == 7) {
      terminate();
    } else {
      yield();
    }
  }
  
  public static void shutdown(Applet paramApplet)
  {
    try
    {
      Class localClass = Class.forName("java.lang.Thread");
      Method localMethod = localClass.getMethod("stop", new Class[0]);
      Object[] arrayOfObject = new Object[0];
      ArrayList localArrayList = (ArrayList)animatorTable.get(paramApplet);
      if (localArrayList != null)
      {
        animatorTable.remove(paramApplet);
        int i = localArrayList.size();
        for (int j = 0; j < i; j++)
        {
          Thread localThread = (Thread)localArrayList.get(j);
          localMethod.invoke(localThread, arrayOfObject);
        }
      }
    }
    catch (Exception localException) {}
  }
  
  protected void delayHook() {}
  
  protected void breakHook() {}
  
  protected void resumeHook() {}
  
  protected void controllerHook() {}
  
  public void start()
  {
    start(1);
  }
  
  private void initAnimator()
  {
    Applet localApplet = JTFTools.getApplet();
    if (localApplet != null)
    {
      JTFTools.registerApplet(localApplet, this);
      ArrayList localArrayList = (ArrayList)animatorTable.get(localApplet);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList();
        animatorTable.put(localApplet, localArrayList);
      }
      localArrayList.add(this);
    }
  }
  
  private void start(int paramInt)
  {
    switch (this.animatorState)
    {
    case 0: 
    case 6: 
      this.animatorState = paramInt;
      resumeHook();
      controllerHook();
      super.start();
      break;
    case 5: 
      this.animatorState = paramInt;
      resumeHook();
      controllerHook();
      resumeAnimator();
      break;
    }
  }
  
  private synchronized void suspendAnimator()
  {
    this.resumed = false;
    while (!this.resumed) {
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  private synchronized void resumeAnimator()
  {
    this.resumed = true;
    notifyAll();
  }
  
  private void terminate()
  {
    this.animatorState = 6;
    if (Thread.currentThread() == this) {
      throw new ThreadDeath();
    }
    throw new ErrorException("Illegal call to terminate");
  }
  
  private static HashMap<Applet, ArrayList<Thread>> animatorTable = new HashMap();
  private int animatorState = 0;
  private int currentDepth = 0;
  private int callDepth = 0;
  private int delayCount = 0;
  private double animatorSpeed = 0.5D;
  private Component speedBar;
  private boolean resumed;
}
