package acm.util;

import java.awt.Point;
import java.io.IOException;
import java.io.OutputStream;

abstract class Gif89Frame
{
  public static final int DM_UNDEFINED = 0;
  public static final int DM_LEAVE = 1;
  public static final int DM_BGCOLOR = 2;
  public static final int DM_REVERT = 3;
  int theWidth = -1;
  int theHeight = -1;
  byte[] ciPixels;
  private Point thePosition = new Point(0, 0);
  private boolean isInterlaced;
  private int csecsDelay;
  private int disposalCode = 1;
  
  public void setPosition(Point paramPoint)
  {
    this.thePosition = new Point(paramPoint);
  }
  
  public void setInterlaced(boolean paramBoolean)
  {
    this.isInterlaced = paramBoolean;
  }
  
  public void setDelay(int paramInt)
  {
    this.csecsDelay = paramInt;
  }
  
  public void setDisposalMode(int paramInt)
  {
    this.disposalCode = paramInt;
  }
  
  abstract Object getPixelSource();
  
  int getWidth()
  {
    return this.theWidth;
  }
  
  int getHeight()
  {
    return this.theHeight;
  }
  
  byte[] getPixelSink()
  {
    return this.ciPixels;
  }
  
  void encode(OutputStream paramOutputStream, boolean paramBoolean, int paramInt1, int paramInt2)
    throws IOException
  {
    writeGraphicControlExtension(paramOutputStream, paramBoolean, paramInt2);
    writeImageDescriptor(paramOutputStream);
    new GifPixelsEncoder(this.theWidth, this.theHeight, this.ciPixels, this.isInterlaced, paramInt1).encode(paramOutputStream);
  }
  
  private void writeGraphicControlExtension(OutputStream paramOutputStream, boolean paramBoolean, int paramInt)
    throws IOException
  {
    int i = paramInt == -1 ? 0 : 1;
    if ((i == 1) || (paramBoolean))
    {
      paramOutputStream.write(33);
      paramOutputStream.write(249);
      paramOutputStream.write(4);
      paramOutputStream.write(this.disposalCode << 2 | i);
      Gif89Put.leShort(this.csecsDelay, paramOutputStream);
      paramOutputStream.write(paramInt);
      paramOutputStream.write(0);
    }
  }
  
  private void writeImageDescriptor(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(44);
    Gif89Put.leShort(this.thePosition.x, paramOutputStream);
    Gif89Put.leShort(this.thePosition.y, paramOutputStream);
    Gif89Put.leShort(this.theWidth, paramOutputStream);
    Gif89Put.leShort(this.theHeight, paramOutputStream);
    paramOutputStream.write(this.isInterlaced ? 64 : 0);
  }
}
