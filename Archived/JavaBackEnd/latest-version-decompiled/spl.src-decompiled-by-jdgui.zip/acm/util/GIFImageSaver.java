package acm.util;

import java.awt.Image;
import java.io.File;
import java.util.Iterator;
import javax.imageio.ImageIO;

class GIFImageSaver
  extends ImageSaver
{
  private GIF89ImageSaver gif89Saver;
  
  public GIFImageSaver()
  {
    super("GIF", 2);
    if (!ImageIO.getImageWritersBySuffix("gif").hasNext()) {
      this.gif89Saver = new GIF89ImageSaver();
    }
  }
  
  public void saveImage(Image paramImage)
  {
    if (this.gif89Saver != null)
    {
      this.gif89Saver.setOutputStream(getOutputStream());
      this.gif89Saver.saveImage(paramImage);
    }
    else
    {
      super.saveImage(paramImage);
    }
  }
  
  public void updateFileType(File paramFile)
  {
    if (this.gif89Saver != null) {
      this.gif89Saver.updateFileType(paramFile);
    }
  }
}
