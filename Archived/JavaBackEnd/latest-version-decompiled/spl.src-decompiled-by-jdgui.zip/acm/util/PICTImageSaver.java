package acm.util;

import java.awt.Image;

class PICTImageSaver
  extends ImageSaver
{
  private static final int OP_CLIP = 1;
  private static final int OP_VERSION = 17;
  private static final int OP_DEF_HILITE = 30;
  private static final int OP_SHORT_LINE = 34;
  private static final int OP_DIRECT_BITS_RECT = 154;
  private static final int OP_SHORT_COMMENT = 160;
  private static final int OP_LONG_COMMENT = 161;
  private static final int OP_END_PICT = 255;
  private static final int OP_HEADER = 3072;
  private static final int PS_BEGIN = 190;
  private static final int PS_END = 191;
  private static final int PS_HANDLE = 192;
  private static final int PS_DICT_SIZE = 500;
  private static final int VERSION = 767;
  private static final int PICT_PADDING = 512;
  private static final int RGB_DIRECT = 16;
  private static final int SRC_COPY = 0;
  private int[][] pixels;
  private String[] psPreview;
  private int width;
  private int height;
  private int rowBytes;
  
  public void saveImage(Image paramImage)
  {
    this.pixels = MediaTools.getPixelArray(paramImage);
    Object localObject = paramImage.getProperty("PSPreview", null);
    this.psPreview = ((localObject instanceof String[]) ? (String[])localObject : null);
    this.width = this.pixels[0].length;
    this.height = this.pixels.length;
    this.rowBytes = (4 * this.width);
    if (this.paddingFlag) {
      dumpPadding();
    }
    dumpHeader();
    dumpDefHilite();
    dumpClipRegion();
    dumpBoundsMarkers();
    if (this.psPreview != null)
    {
      dumpShort(160);
      dumpShort(190);
    }
    dumpDirectBitsRect();
    if (this.psPreview != null)
    {
      dumpPSPreview();
      dumpShort(160);
      dumpShort(191);
    }
    dumpEndPict();
  }
  
  public void setPaddingFlag(boolean paramBoolean)
  {
    this.paddingFlag = paramBoolean;
  }
  
  private void dumpPadding()
  {
    for (int i = 0; i < 512; i++) {
      dumpByte(0);
    }
  }
  
  private void dumpHeader()
  {
    dumpShort(0);
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpShort(17);
    dumpShort(767);
    dumpShort(3072);
    dumpShort(65534);
    dumpShort(0);
    dumpShort(72);
    dumpShort(0);
    dumpShort(72);
    dumpShort(0);
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpLong(0);
  }
  
  private void dumpDefHilite()
  {
    dumpShort(30);
  }
  
  private void dumpClipRegion()
  {
    dumpShort(1);
    dumpShort(10);
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
  }
  
  private void dumpBoundsMarkers()
  {
    dumpShort(34);
    dumpShort(0);
    dumpShort(0);
    dumpShort(0);
    dumpShort(34);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpShort(0);
  }
  
  private void dumpDirectBitsRect()
  {
    dumpShort(154);
    dumpPixMap();
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpShort(0);
    dumpPixelData();
  }
  
  private void dumpPixMap()
  {
    dumpLong(255);
    dumpShort(this.rowBytes | 0x8000);
    dumpShort(0);
    dumpShort(0);
    dumpShort(this.height);
    dumpShort(this.width);
    dumpShort(0);
    dumpShort(4);
    dumpLong(0);
    dumpShort(72);
    dumpShort(0);
    dumpShort(72);
    dumpShort(0);
    dumpShort(16);
    dumpShort(32);
    dumpShort(3);
    dumpShort(8);
    dumpLong(0);
    dumpLong(0);
    dumpLong(0);
  }
  
  private void dumpEndPict()
  {
    dumpShort(255);
  }
  
  private void dumpPixelData()
  {
    int i = 0;
    byte[] arrayOfByte = new byte[this.rowBytes];
    for (int j = 0; j < this.height; j++)
    {
      int k = packScanLine(arrayOfByte, this.pixels[j]);
      if (this.rowBytes > 250)
      {
        dumpShort(k);
        i += 2;
      }
      else
      {
        dumpByte(k);
        i++;
      }
      for (int m = 0; m < k; m++) {
        dumpByte(arrayOfByte[m]);
      }
      i += k;
    }
    if (i % 2 == 1) {
      dumpByte(0);
    }
  }
  
  private int packScanLine(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    int i = 0;
    for (int j = 0; j < 3; j++)
    {
      char c = "RGB".charAt(j);
      int k = i;
      int m = i + 1;
      int n = 0;
      int i1;
      int i2;
      int i3;
      while (n < this.width)
      {
        i1 = getPixelComponent(paramArrayOfInt[(n++)], c);
        paramArrayOfByte[(m++)] = ((byte)i1);
        i2 = 1;
        i3 = 0;
        if (n < this.width)
        {
          int i4 = getPixelComponent(paramArrayOfInt[n], c);
          i3 = i1 == i4 ? 1 : 0;
          if (i3 != 0) {
            while ((i2 < 128) && (n < this.width))
            {
              i4 = getPixelComponent(paramArrayOfInt[n], c);
              if (i1 != i4) {
                break;
              }
              i2++;
              n++;
            }
          }
          while ((i2 < 128) && (n < this.width))
          {
            i4 = getPixelComponent(paramArrayOfInt[n], c);
            if (i1 == i4)
            {
              m--;
              i2--;
              n--;
              break;
            }
            paramArrayOfByte[(m++)] = ((byte)i4);
            i1 = i4;
            i2++;
            n++;
          }
        }
        if (i3 != 0) {
          paramArrayOfByte[i] = ((byte)(0x80 | 129 - i2));
        } else {
          paramArrayOfByte[i] = ((byte)(i2 - 1));
        }
        i = m++;
      }
      if (i - k > this.width + this.width / 128)
      {
        i1 = this.width;
        i = k;
        for (i2 = 0; i2 < this.width; i2++)
        {
          if (i2 % 128 == 0)
          {
            i3 = i1 > 128 ? 128 : i1;
            paramArrayOfByte[(i++)] = ((byte)(i3 - 1));
            i1 -= i3;
          }
          paramArrayOfByte[(i++)] = ((byte)getPixelComponent(paramArrayOfInt[i2], c));
        }
      }
    }
    return i;
  }
  
  private void dumpPSPreview()
  {
    addPSComment("/dictCount countdictstack def");
    addPSComment("/opCount count 1 sub def");
    addPSComment("500 dict begin");
    addPSComment("/showpage {} def");
    addPSComment("0 setgray 0 setlinecap");
    addPSComment("1 setlinewidth 0 setlinejoin");
    addPSComment("10 setmiterlimit [] 0 setdash");
    addPSComment("/languagelevel where {");
    addPSComment("  pop languagelevel");
    addPSComment("  1 ne { false setstrokeadjust false setoverprint } if");
    addPSComment("} if");
    addPSComment("gsave");
    addPSComment("clippath pathbbox");
    addPSComment("pop pop " + this.height + " add translate");
    addPSComment("1 -1 scale");
    for (int i = 0; i < this.psPreview.length; i++) {
      addPSComment(this.psPreview[i]);
    }
    addPSComment("grestore");
    addPSComment("end");
    addPSComment("count opCount sub {pop} repeat");
    addPSComment("countdictstack dictCount sub {end} repeat");
  }
  
  private void addPSComment(String paramString)
  {
    if (paramString.length() % 2 == 0) {
      paramString = paramString + " ";
    }
    dumpShort(161);
    dumpShort(192);
    dumpShort(paramString.length() + 1);
    for (int i = 0; i < paramString.length(); i++) {
      dumpByte(paramString.charAt(i));
    }
    dumpByte(13);
  }
  
  private boolean paddingFlag = true;
}
