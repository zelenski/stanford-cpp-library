package acm.util;

class TIFImageSaver
  extends TIFFImageSaver
{}
