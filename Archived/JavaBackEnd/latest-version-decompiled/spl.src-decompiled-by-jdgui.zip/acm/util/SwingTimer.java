package acm.util;

import java.awt.event.ActionListener;
import javax.swing.Timer;

public class SwingTimer
  extends Timer
{
  static final long serialVersionUID = 1L;
  
  public SwingTimer(int paramInt, ActionListener paramActionListener)
  {
    super(paramInt, paramActionListener);
  }
}
