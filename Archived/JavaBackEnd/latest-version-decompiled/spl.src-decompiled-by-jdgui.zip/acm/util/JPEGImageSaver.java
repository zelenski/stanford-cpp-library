package acm.util;

class JPEGImageSaver
  extends ImageSaver
{
  public JPEGImageSaver()
  {
    super("JPEG", 1);
  }
}
