package acm.graphics;

import acm.util.Animator;
import acm.util.ErrorException;
import acm.util.MediaTools;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;

public class GPen
  extends GObject
{
  private Animator animator;
  private boolean regionOpen;
  private boolean regionStarted;
  private boolean penVisible;
  private PathList path;
  private Image penImage;
  private Color fillColor;
  static final long serialVersionUID = 21L;
  
  public GPen()
  {
    this.penVisible = false;
    this.path = new PathList();
    this.animator = new Animator();
    setSpeed(1.0D);
    erasePath();
  }
  
  public GPen(double paramDouble1, double paramDouble2)
  {
    this();
    setLocation(paramDouble1, paramDouble2);
  }
  
  public void erasePath()
  {
    this.path.clear();
    this.regionOpen = false;
    this.regionStarted = false;
    repaint();
  }
  
  public void setLocation(double paramDouble1, double paramDouble2)
  {
    if (this.regionStarted) {
      throw new ErrorException("It is illegal to move the pen while you are defining a filled region.");
    }
    super.setLocation(paramDouble1, paramDouble2);
    this.animator.delay();
  }
  
  public void drawLine(double paramDouble1, double paramDouble2)
  {
    double d1 = getX();
    double d2 = getY();
    if (this.regionStarted)
    {
      this.path.add(new DrawLineElement(paramDouble1, paramDouble2));
    }
    else
    {
      this.path.add(new SetLocationElement(d1, d2), new DrawLineElement(paramDouble1, paramDouble2));
      this.regionStarted = this.regionOpen;
    }
    super.setLocation(d1 + paramDouble1, d2 + paramDouble2);
    this.animator.delay();
  }
  
  public final void drawPolarLine(double paramDouble1, double paramDouble2)
  {
    double d = paramDouble2 * 3.141592653589793D / 180.0D;
    drawLine(paramDouble1 * Math.cos(d), -paramDouble1 * Math.sin(d));
  }
  
  public void setColor(Color paramColor)
  {
    if (this.regionStarted) {
      throw new ErrorException("It is illegal to change the color while you are defining a filled region.");
    }
    this.path.add(new SetColorElement(paramColor));
    super.setColor(paramColor);
  }
  
  public void setFillColor(Color paramColor)
  {
    if (this.regionStarted) {
      throw new ErrorException("It is illegal to change the fill color while you are defining a filled region.");
    }
    this.fillColor = paramColor;
  }
  
  public Color getFillColor()
  {
    return this.fillColor == null ? getColor() : this.fillColor;
  }
  
  public void startFilledRegion()
  {
    if (this.regionOpen) {
      throw new ErrorException("You are already filling a region.");
    }
    this.regionOpen = true;
    this.regionStarted = false;
    this.path.add(new StartRegionElement(this.fillColor));
  }
  
  public void endFilledRegion()
  {
    if (!this.regionOpen) {
      throw new ErrorException("You need to call startFilledRegion before you call endFilledRegion.");
    }
    this.regionOpen = false;
    this.regionStarted = false;
    this.path.add(new EndRegionElement());
    repaint();
  }
  
  public void showPen()
  {
    this.penVisible = true;
    repaint();
    this.animator.delay();
  }
  
  public void hidePen()
  {
    this.penVisible = false;
    repaint();
    this.animator.delay();
  }
  
  public boolean isPenVisible()
  {
    return this.penVisible;
  }
  
  public void setSpeed(double paramDouble)
  {
    this.animator.setSpeed(paramDouble);
  }
  
  public double getSpeed()
  {
    return this.animator.getSpeed();
  }
  
  protected void paint2d(Graphics2D paramGraphics2D)
  {
    paramGraphics2D = (Graphics2D)paramGraphics2D.create();
    Color localColor = getObjectColor();
    if (localColor != null) {
      paramGraphics2D.setColor(localColor);
    }
    PathState localPathState = new PathState();
    this.path.mapPaint(paramGraphics2D, localPathState);
    if (this.penVisible) {
      drawPen(paramGraphics2D);
    }
  }
  
  public GRectangle getBounds()
  {
    PathState localPathState = new PathState();
    return this.path.getBounds(localPathState);
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    return false;
  }
  
  public void setPenImage(Image paramImage)
  {
    this.penImage = MediaTools.loadImage(paramImage);
  }
  
  public Image getPenImage()
  {
    if (this.penImage == null) {
      this.penImage = PenImage.getImage();
    }
    return this.penImage;
  }
  
  protected void drawPen(Graphics paramGraphics)
  {
    Component localComponent = getComponent();
    if (localComponent == null) {
      return;
    }
    if (this.penImage == null) {
      this.penImage = PenImage.getImage();
    }
    int i = this.penImage.getWidth(localComponent);
    int j = this.penImage.getHeight(localComponent);
    int k = (int)Math.round(getX());
    int m = (int)Math.round(getY());
    paramGraphics.drawImage(this.penImage, k - i / 2, m - j / 2, localComponent);
  }
  
  protected Rectangle getPenBounds()
  {
    Component localComponent = getComponent();
    if (localComponent == null) {
      return new Rectangle();
    }
    if (this.penImage == null) {
      this.penImage = PenImage.getImage();
    }
    int i = this.penImage.getWidth(localComponent);
    int j = this.penImage.getHeight(localComponent);
    int k = (int)Math.round(getX());
    int m = (int)Math.round(getY());
    return new Rectangle(k - i / 2, m - j / 2, i, j);
  }
}
