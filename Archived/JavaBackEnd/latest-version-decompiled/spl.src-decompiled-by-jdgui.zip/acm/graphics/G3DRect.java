package acm.graphics;

import java.awt.Graphics;
import java.awt.Graphics2D;

public class G3DRect
  extends GRect
{
  private boolean isRaised;
  static final long serialVersionUID = 21L;
  
  public G3DRect(double paramDouble1, double paramDouble2)
  {
    this(0.0D, 0.0D, paramDouble1, paramDouble2, false);
  }
  
  public G3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    this(paramDouble1, paramDouble2, paramDouble3, paramDouble4, false);
  }
  
  public G3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean)
  {
    super(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    this.isRaised = paramBoolean;
  }
  
  public void paint(Graphics paramGraphics)
  {
    if (!isVisible()) {
      return;
    }
    Graphics2D localGraphics2D = createTransformedGraphics(paramGraphics);
    if (isFilled())
    {
      localGraphics2D.setColor(getFillColor());
      localGraphics2D.fill3DRect(0, 0, GMath.round(getFrameWidth()), GMath.round(getFrameHeight()), this.isRaised);
      
      localGraphics2D.setColor(getColor());
    }
    localGraphics2D.draw3DRect(0, 0, GMath.round(getFrameWidth()), GMath.round(getFrameHeight()), this.isRaised);
    
    localGraphics2D.dispose();
  }
  
  public void setRaised(boolean paramBoolean)
  {
    this.isRaised = paramBoolean;
  }
  
  public boolean isRaised()
  {
    return this.isRaised;
  }
}
