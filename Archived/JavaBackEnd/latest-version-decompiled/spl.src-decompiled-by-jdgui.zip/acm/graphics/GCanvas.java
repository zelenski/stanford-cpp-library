package acm.graphics;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import javax.swing.JComponent;

public class GCanvas
  extends JComponent
  implements GContainer
{
  private GCanvasListener gCanvasListener;
  private GObject lastObject;
  private GObject dragObject;
  private GObjectList contents;
  private boolean autoRepaint;
  private boolean nativeArcFlag;
  
  public GCanvas()
  {
    this.contents = new GObjectList(this);
    setBackground(Color.WHITE);
    setForeground(Color.BLACK);
    setOpaque(true);
    setAutoRepaintFlag(true);
    setNativeArcFlag(false);
    setLayout(null);
    this.gCanvasListener = new GCanvasListener(this);
    addMouseListener(this.gCanvasListener);
    addMouseMotionListener(this.gCanvasListener);
  }
  
  public void add(GObject paramGObject)
  {
    this.contents.add(paramGObject);
    conditionalRepaint();
  }
  
  public final void add(GObject paramGObject, double paramDouble1, double paramDouble2)
  {
    paramGObject.setLocation(paramDouble1, paramDouble2);
    add(paramGObject);
  }
  
  public final void add(GObject paramGObject, GPoint paramGPoint)
  {
    add(paramGObject, paramGPoint.getX(), paramGPoint.getY());
  }
  
  public void remove(GObject paramGObject)
  {
    this.contents.remove(paramGObject);
    conditionalRepaint();
  }
  
  public void removeAll()
  {
    this.contents.removeAll();
    super.removeAll();
    repaint();
  }
  
  public Component add(Component paramComponent)
  {
    super.add(paramComponent);
    Dimension localDimension1 = paramComponent.getSize();
    if ((localDimension1.width == 0) || (localDimension1.height == 0))
    {
      Dimension localDimension2 = paramComponent.getPreferredSize();
      if (localDimension1.width == 0) {
        localDimension1.width = localDimension2.width;
      }
      if (localDimension1.height == 0) {
        localDimension1.height = localDimension2.height;
      }
      paramComponent.setSize(localDimension1);
    }
    return paramComponent;
  }
  
  public final void add(Component paramComponent, double paramDouble1, double paramDouble2)
  {
    paramComponent.setLocation(GMath.round(paramDouble1), GMath.round(paramDouble2));
    add(paramComponent);
  }
  
  public final void add(Component paramComponent, GPoint paramGPoint)
  {
    add(paramComponent, paramGPoint.getX(), paramGPoint.getY());
  }
  
  public void remove(Component paramComponent)
  {
    super.remove(paramComponent);
    conditionalRepaint();
  }
  
  public int getElementCount()
  {
    return this.contents.getElementCount();
  }
  
  public GObject getElement(int paramInt)
  {
    return this.contents.getElement(paramInt);
  }
  
  public GObject getElementAt(double paramDouble1, double paramDouble2)
  {
    return this.contents.getElementAt(paramDouble1, paramDouble2, false);
  }
  
  public final GObject getElementAt(GPoint paramGPoint)
  {
    return getElementAt(paramGPoint.getX(), paramGPoint.getY());
  }
  
  public Iterator<GObject> iterator()
  {
    return new GIterator(this, 0);
  }
  
  public Iterator<GObject> iterator(int paramInt)
  {
    return new GIterator(this, paramInt);
  }
  
  public void paint(Graphics paramGraphics)
  {
    if (isOpaque())
    {
      paramGraphics.setColor(getBackground());
      paramGraphics.fillRect(0, 0, getWidth(), getHeight());
      paramGraphics.setColor(getForeground());
    }
    super.paint(paramGraphics);
  }
  
  public void paintComponent(Graphics paramGraphics)
  {
    this.contents.mapPaint(paramGraphics);
    super.paintComponent(paramGraphics);
  }
  
  public void setAutoRepaintFlag(boolean paramBoolean)
  {
    this.autoRepaint = paramBoolean;
  }
  
  public boolean getAutoRepaintFlag()
  {
    return this.autoRepaint;
  }
  
  public void setNativeArcFlag(boolean paramBoolean)
  {
    this.nativeArcFlag = paramBoolean;
  }
  
  public boolean getNativeArcFlag()
  {
    return this.nativeArcFlag;
  }
  
  protected void sendToFront(GObject paramGObject)
  {
    this.contents.sendToFront(paramGObject);
    conditionalRepaint();
  }
  
  protected void sendToBack(GObject paramGObject)
  {
    this.contents.sendToBack(paramGObject);
    conditionalRepaint();
  }
  
  protected void sendForward(GObject paramGObject)
  {
    this.contents.sendForward(paramGObject);
    conditionalRepaint();
  }
  
  protected void sendBackward(GObject paramGObject)
  {
    this.contents.sendBackward(paramGObject);
    conditionalRepaint();
  }
  
  protected void dispatchMouseEvent(MouseEvent paramMouseEvent)
  {
    GObject localGObject = this.contents.getElementAt(paramMouseEvent.getX(), paramMouseEvent.getY(), true);
    GMouseEvent localGMouseEvent = null;
    if (localGObject != this.lastObject)
    {
      if (this.lastObject != null)
      {
        localGMouseEvent = new GMouseEvent(this.lastObject, 505, paramMouseEvent);
        this.lastObject.fireMouseListeners(localGMouseEvent);
      }
      if (localGObject != null)
      {
        localGMouseEvent = new GMouseEvent(localGObject, 504, paramMouseEvent);
        localGObject.fireMouseListeners(localGMouseEvent);
      }
    }
    this.lastObject = localGObject;
    if (this.dragObject != null) {
      localGObject = this.dragObject;
    }
    if (localGObject != null)
    {
      int i = paramMouseEvent.getID();
      if ((i != 505) && (i != 504) && (
        (i != 506) || (this.dragObject != null)))
      {
        if (i == 501) {
          this.dragObject = localGObject;
        } else if (i == 502) {
          this.dragObject = null;
        }
        localGMouseEvent = new GMouseEvent(localGObject, i, paramMouseEvent);
        localGObject.fireMouseListeners(localGMouseEvent);
      }
    }
    if ((localGMouseEvent != null) && (localGMouseEvent.isConsumed())) {
      paramMouseEvent.consume();
    }
  }
  
  protected void conditionalRepaint()
  {
    if (this.autoRepaint) {
      repaint();
    }
  }
  
  protected void updateEnabledList()
  {
    this.contents.updateEnabledList();
  }
  
  static MouseEvent createMouseEvent(Object paramObject, int paramInt, MouseEvent paramMouseEvent)
  {
    return new GMouseEvent(paramObject, paramInt, paramMouseEvent);
  }
}
