package acm.graphics;

import java.awt.Graphics2D;
import java.awt.Polygon;

class SetLocationElement
  extends PathElement
{
  private double cx;
  private double cy;
  
  public SetLocationElement(double paramDouble1, double paramDouble2)
  {
    this.cx = paramDouble1;
    this.cy = paramDouble2;
  }
  
  public void paint(Graphics2D paramGraphics2D, PathState paramPathState)
  {
    paramPathState.cx = this.cx;
    paramPathState.cy = this.cy;
    if (paramPathState.region != null) {
      paramPathState.region.addPoint(GMath.round(paramPathState.sx * this.cx), GMath.round(paramPathState.sy * this.cy));
    }
  }
  
  public void updateBounds(GRectangle paramGRectangle, PathState paramPathState)
  {
    paramPathState.cx = this.cx;
    paramPathState.cy = this.cy;
  }
}
