package acm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D.Double;

public class GArc
  extends GObject
  implements GFillable
{
  public static final double ARC_TOLERANCE = 2.5D;
  private double frameWidth;
  private double frameHeight;
  private double arcStart;
  private double arcSweep;
  private Color fillColor;
  private boolean isFilled;
  static final long serialVersionUID = 21L;
  
  public GArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    this(0.0D, 0.0D, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public GArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    this.frameWidth = paramDouble3;
    this.frameHeight = paramDouble4;
    this.arcStart = paramDouble5;
    this.arcSweep = paramDouble6;
    setLocation(paramDouble1, paramDouble2);
  }
  
  public void setStartAngle(double paramDouble)
  {
    this.arcStart = paramDouble;
    repaint();
  }
  
  public double getStartAngle()
  {
    return this.arcStart;
  }
  
  public void setSweepAngle(double paramDouble)
  {
    this.arcSweep = paramDouble;
    repaint();
  }
  
  public double getSweepAngle()
  {
    return this.arcSweep;
  }
  
  public GPoint getStartPoint()
  {
    return getArcPoint(this.arcStart);
  }
  
  public GPoint getEndPoint()
  {
    return getArcPoint(this.arcStart + this.arcSweep);
  }
  
  protected void paint2d(Graphics2D paramGraphics2D)
  {
    Arc2D.Double localDouble = new Arc2D.Double(0.0D, 0.0D, this.frameWidth, this.frameHeight, this.arcStart, this.arcSweep, isFilled() ? 2 : 0);
    if (isFilled())
    {
      paramGraphics2D.setColor(getFillColor());
      paramGraphics2D.fill(localDouble);
      paramGraphics2D.setColor(getColor());
    }
    paramGraphics2D.draw(localDouble);
  }
  
  public GRectangle getBounds()
  {
    double d1 = this.frameWidth / 2.0D;
    double d2 = this.frameHeight / 2.0D;
    double d3 = getX() + d1;
    double d4 = getY() + d2;
    double d5 = d3 + GMath.cosDegrees(this.arcStart) * d1;
    double d6 = d4 - GMath.sinDegrees(this.arcStart) * d2;
    double d7 = d3 + GMath.cosDegrees(this.arcStart + this.arcSweep) * d1;
    double d8 = d4 - GMath.sinDegrees(this.arcStart + this.arcSweep) * d2;
    double d9 = Math.min(d5, d7);
    double d10 = Math.max(d5, d7);
    double d11 = Math.min(d6, d8);
    double d12 = Math.max(d6, d8);
    if (containsAngle(0.0D)) {
      d10 = d3 + d1;
    }
    if (containsAngle(90.0D)) {
      d11 = d4 - d2;
    }
    if (containsAngle(180.0D)) {
      d9 = d3 - d1;
    }
    if (containsAngle(270.0D)) {
      d12 = d4 + d2;
    }
    if (isFilled())
    {
      d9 = Math.min(d9, d3);
      d11 = Math.min(d11, d4);
      d10 = Math.max(d10, d3);
      d12 = Math.max(d12, d4);
    }
    return new GRectangle(d9, d11, d10 - d9, d12 - d11);
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    double d1 = this.frameWidth / 2.0D;
    double d2 = this.frameHeight / 2.0D;
    if ((d1 == 0.0D) || (d2 == 0.0D)) {
      return false;
    }
    double d3 = paramDouble1 - (getX() + d1);
    double d4 = paramDouble2 - (getY() + d2);
    double d5 = d3 * d3 / (d1 * d1) + d4 * d4 / (d2 * d2);
    if (isFilled())
    {
      if (d5 > 1.0D) {
        return false;
      }
    }
    else
    {
      double d6 = 2.5D / ((d1 + d2) / 2.0D);
      if (Math.abs(1.0D - d5) > d6) {
        return false;
      }
    }
    return containsAngle(GMath.toDegrees(Math.atan2(-d4, d3)));
  }
  
  public void setFrameRectangle(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    this.frameWidth = paramDouble3;
    this.frameHeight = paramDouble4;
    setLocation(paramDouble1, paramDouble2);
  }
  
  public final void setFrameRectangle(GRectangle paramGRectangle)
  {
    setFrameRectangle(paramGRectangle.getX(), paramGRectangle.getY(), paramGRectangle.getWidth(), paramGRectangle.getHeight());
  }
  
  public GRectangle getFrameRectangle()
  {
    return new GRectangle(getX(), getY(), this.frameWidth, this.frameHeight);
  }
  
  public void setFilled(boolean paramBoolean)
  {
    this.isFilled = paramBoolean;
    repaint();
  }
  
  public boolean isFilled()
  {
    return this.isFilled;
  }
  
  public void setFillColor(Color paramColor)
  {
    this.fillColor = paramColor;
    repaint();
  }
  
  public Color getFillColor()
  {
    return this.fillColor == null ? getColor() : this.fillColor;
  }
  
  public String paramString()
  {
    String str1 = super.paramString();
    str1 = str1.substring(str1.indexOf(')') + 1);
    GRectangle localGRectangle = getFrameRectangle();
    String str2 = "frame=(" + localGRectangle.getX() + ", " + localGRectangle.getY() + ", " + localGRectangle.getWidth() + ", " + localGRectangle.getHeight() + ")";
    
    str2 = str2 + ", start=" + this.arcStart + ", sweep=" + this.arcSweep;
    return str2 + str1;
  }
  
  private GPoint getArcPoint(double paramDouble)
  {
    double d1 = this.frameWidth / 2.0D;
    double d2 = this.frameHeight / 2.0D;
    double d3 = getX() + d1;
    double d4 = getY() + d2;
    return new GPoint(d3 + d1 * GMath.cosDegrees(paramDouble), d4 - d2 * GMath.sinDegrees(paramDouble));
  }
  
  private boolean containsAngle(double paramDouble)
  {
    double d1 = Math.min(getStartAngle(), getStartAngle() + getSweepAngle());
    
    double d2 = Math.abs(getSweepAngle());
    if (d2 >= 360.0D) {
      return true;
    }
    paramDouble = paramDouble < 0.0D ? 360.0D - -paramDouble % 360.0D : paramDouble % 360.0D;
    d1 = d1 < 0.0D ? 360.0D - -d1 % 360.0D : d1 % 360.0D;
    if (d1 + d2 > 360.0D) {
      return (paramDouble >= d1) || (paramDouble <= d1 + d2 - 360.0D);
    }
    return (paramDouble >= d1) && (paramDouble <= d1 + d2);
  }
}
