package acm.graphics;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

class GCanvasListener
  implements MouseListener, MouseMotionListener
{
  private GCanvas gCanvas;
  
  public GCanvasListener(GCanvas paramGCanvas)
  {
    this.gCanvas = paramGCanvas;
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    this.gCanvas.requestFocus();
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mouseExited(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    this.gCanvas.dispatchMouseEvent(paramMouseEvent);
  }
}
