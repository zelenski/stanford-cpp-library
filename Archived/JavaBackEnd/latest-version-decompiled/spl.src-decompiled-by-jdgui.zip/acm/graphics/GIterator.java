package acm.graphics;

import acm.util.ErrorException;
import java.util.Iterator;

class GIterator
  implements Iterator<GObject>
{
  private GContainer cont;
  private int dir;
  private int index;
  private int nElements;
  
  public GIterator(GContainer paramGContainer, int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
    case 1: 
      this.dir = paramInt;
      break;
    default: 
      throw new ErrorException("Illegal direction for iterator");
    }
    this.cont = paramGContainer;
    this.index = 0;
    this.nElements = paramGContainer.getElementCount();
  }
  
  public boolean hasNext()
  {
    return this.index < this.nElements;
  }
  
  public GObject next()
  {
    if (this.dir == 1) {
      return this.cont.getElement(this.nElements - this.index++ - 1);
    }
    return this.cont.getElement(this.index++);
  }
  
  public GObject nextElement()
  {
    return next();
  }
  
  public void remove()
  {
    if (this.dir == 1) {
      this.cont.remove(this.cont.getElement(this.nElements - --this.index - 1));
    } else {
      this.cont.remove(this.cont.getElement(--this.index));
    }
    this.nElements -= 1;
  }
}
