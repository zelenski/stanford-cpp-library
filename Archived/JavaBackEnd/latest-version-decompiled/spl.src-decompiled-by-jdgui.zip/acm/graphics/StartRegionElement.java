package acm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

class StartRegionElement
  extends PathElement
{
  private Color color;
  
  public StartRegionElement(Color paramColor)
  {
    this.color = paramColor;
  }
  
  public void paint(Graphics2D paramGraphics2D, PathState paramPathState)
  {
    paramPathState.region = new Polygon();
    paramPathState.fillColor = this.color;
  }
}
