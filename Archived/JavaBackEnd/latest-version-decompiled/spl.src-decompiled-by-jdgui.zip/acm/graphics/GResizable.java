package acm.graphics;

public abstract interface GResizable
{
  public abstract void setSize(double paramDouble1, double paramDouble2);
  
  public abstract void setSize(GDimension paramGDimension);
  
  public abstract void setBounds(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public abstract void setBounds(GRectangle paramGRectangle);
}
