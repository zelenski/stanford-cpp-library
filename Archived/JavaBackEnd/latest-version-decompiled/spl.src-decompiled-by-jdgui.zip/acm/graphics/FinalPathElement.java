package acm.graphics;

import java.awt.Graphics2D;
import java.awt.Polygon;

class FinalPathElement
  extends PathElement
{
  public void paint(Graphics2D paramGraphics2D, PathState paramPathState)
  {
    if (paramPathState.region != null) {
      paramGraphics2D.drawPolyline(paramPathState.region.xpoints, paramPathState.region.ypoints, paramPathState.region.npoints);
    }
  }
}
