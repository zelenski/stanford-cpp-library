package acm.graphics;

import java.awt.Point;
import java.io.Serializable;

public class GPoint
  implements Serializable
{
  private double xc;
  private double yc;
  static final long serialVersionUID = 21L;
  
  public GPoint()
  {
    this(0.0D, 0.0D);
  }
  
  public GPoint(double paramDouble1, double paramDouble2)
  {
    this.xc = paramDouble1;
    this.yc = paramDouble2;
  }
  
  public GPoint(GPoint paramGPoint)
  {
    this(paramGPoint.xc, paramGPoint.yc);
  }
  
  public GPoint(Point paramPoint)
  {
    this(paramPoint.x, paramPoint.y);
  }
  
  public double getX()
  {
    return this.xc;
  }
  
  public double getY()
  {
    return this.yc;
  }
  
  public void setLocation(double paramDouble1, double paramDouble2)
  {
    this.xc = paramDouble1;
    this.yc = paramDouble2;
  }
  
  public void setLocation(GPoint paramGPoint)
  {
    setLocation(paramGPoint.xc, paramGPoint.yc);
  }
  
  public GPoint getLocation()
  {
    return new GPoint(this.xc, this.yc);
  }
  
  public void translate(double paramDouble1, double paramDouble2)
  {
    this.xc += paramDouble1;
    this.yc += paramDouble2;
  }
  
  public Point toPoint()
  {
    return new Point((int)Math.round(this.xc), (int)Math.round(this.yc));
  }
  
  public int hashCode()
  {
    return new Float((float)this.xc).hashCode() ^ 37 * new Float((float)this.yc).hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof GPoint)) {
      return false;
    }
    GPoint localGPoint = (GPoint)paramObject;
    return ((float)this.xc == (float)localGPoint.xc) && ((float)this.yc == (float)localGPoint.yc);
  }
  
  public String toString()
  {
    return "(" + (float)this.xc + ", " + (float)this.yc + ")";
  }
}
