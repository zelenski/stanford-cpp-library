package acm.graphics;

import acm.util.JTFTools;
import acm.util.MediaTools;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;

public class GLabel
  extends GObject
{
  public static final Font DEFAULT_FONT = new Font("Default", 0, 12);
  private String label;
  private Font labelFont;
  
  public GLabel(String paramString)
  {
    this(paramString, 0.0D, 0.0D);
  }
  
  public GLabel(String paramString, double paramDouble1, double paramDouble2)
  {
    this.label = paramString;
    setFont(DEFAULT_FONT);
    setLocation(paramDouble1, paramDouble2);
  }
  
  public void setFont(Font paramFont)
  {
    this.labelFont = JTFTools.getStandardFont(paramFont);
    repaint();
  }
  
  public void setFont(String paramString)
  {
    setFont(JTFTools.decodeFont(paramString, getFont()));
  }
  
  public Font getFont()
  {
    return this.labelFont;
  }
  
  public void setLabel(String paramString)
  {
    this.label = paramString;
    repaint();
  }
  
  public String getLabel()
  {
    return this.label;
  }
  
  protected void paint2d(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setFont(this.labelFont);
    paramGraphics2D.drawString(this.label, 0, 0);
  }
  
  public double getAscent()
  {
    return getFontMetrics().getAscent();
  }
  
  public double getDescent()
  {
    return getFontMetrics().getDescent();
  }
  
  public FontMetrics getFontMetrics()
  {
    Component localComponent = getComponent();
    if (localComponent == null) {
      localComponent = DUMMY_COMPONENT;
    }
    return localComponent.getFontMetrics(this.labelFont);
  }
  
  public GRectangle getBounds()
  {
    FontMetrics localFontMetrics = getFontMetrics();
    Object localObject = new Rectangle2D.Double(0.0D, -localFontMetrics.getAscent(), localFontMetrics.stringWidth(this.label), localFontMetrics.getHeight());
    

    AffineTransform localAffineTransform = getMatrix();
    if (localAffineTransform != null) {
      localObject = localAffineTransform.createTransformedShape((Shape)localObject);
    }
    Rectangle localRectangle = ((Shape)localObject).getBounds();
    return new GRectangle(getX() + localRectangle.getX(), getY() + localRectangle.getY(), localRectangle.getWidth(), localRectangle.getHeight());
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    FontMetrics localFontMetrics = getFontMetrics();
    Object localObject = new Rectangle2D.Double(0.0D, -localFontMetrics.getAscent(), localFontMetrics.stringWidth(this.label), localFontMetrics.getHeight());
    

    AffineTransform localAffineTransform = getMatrix();
    if (localAffineTransform != null) {
      localObject = localAffineTransform.createTransformedShape((Shape)localObject);
    }
    return ((Shape)localObject).contains(paramDouble1 - getX(), paramDouble2 - getY());
  }
  
  public String paramString()
  {
    return super.paramString() + ", string=\"" + this.label + "\"";
  }
  
  private static final Component DUMMY_COMPONENT = MediaTools.getImageObserver();
  static final long serialVersionUID = 21L;
}
