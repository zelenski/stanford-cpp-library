package acm.graphics;

import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.io.Serializable;
import java.util.ArrayList;

class VertexList
  implements Serializable
{
  private ArrayList<GPoint> vertices;
  private double cx;
  private double cy;
  
  public VertexList()
  {
    this.vertices = new ArrayList();
    this.cx = 0.0D;
    this.cy = 0.0D;
  }
  
  public VertexList(VertexList paramVertexList)
  {
    this();
    for (int i = 0; i < paramVertexList.vertices.size(); i++) {
      this.vertices.add(paramVertexList.vertices.get(i));
    }
  }
  
  public synchronized void addVertex(double paramDouble1, double paramDouble2)
  {
    this.cx = paramDouble1;
    this.cy = paramDouble2;
    this.vertices.add(new GPoint(this.cx, this.cy));
  }
  
  public synchronized void addEdge(double paramDouble1, double paramDouble2)
  {
    this.cx += paramDouble1;
    this.cy += paramDouble2;
    this.vertices.add(new GPoint(this.cx, this.cy));
  }
  
  public void addArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    double d1 = paramDouble2 / paramDouble1;
    double d2 = paramDouble1 / 2.0D;
    double d3 = paramDouble2 / 2.0D;
    double d4 = this.cx - d2 * GMath.cosDegrees(paramDouble3);
    double d5 = this.cy + d3 * GMath.sinDegrees(paramDouble3);
    if (paramDouble4 > 359.99000000000001D) {
      paramDouble4 = 360.0D;
    }
    if (paramDouble4 < -359.99000000000001D) {
      paramDouble4 = -360.0D;
    }
    double d6 = Math.atan2(1.0D, Math.max(paramDouble1, paramDouble2));
    int i = (int)(GMath.toRadians(Math.abs(paramDouble4)) / d6);
    d6 = GMath.toRadians(paramDouble4) / i;
    double d7 = GMath.toRadians(paramDouble3);
    for (int j = 0; j < i; j++)
    {
      d7 += d6;
      double d8 = d4 + d2 * Math.cos(d7);
      double d9 = d5 - d2 * Math.sin(d7) * d1;
      addVertex(d8, d9);
    }
  }
  
  public synchronized void add(GPoint[] paramArrayOfGPoint)
  {
    for (int i = 0; i < paramArrayOfGPoint.length; i++) {
      this.vertices.add(new GPoint(paramArrayOfGPoint[i].getX(), paramArrayOfGPoint[i].getY()));
    }
  }
  
  public synchronized void remove(GPoint paramGPoint)
  {
    this.vertices.remove(paramGPoint);
  }
  
  public synchronized void clear()
  {
    this.vertices.clear();
  }
  
  public int size()
  {
    return this.vertices.size();
  }
  
  GPoint get(int paramInt)
  {
    return (GPoint)this.vertices.get(paramInt);
  }
  
  public GPoint getCurrentPoint()
  {
    return this.vertices.size() == 0 ? null : new GPoint(this.cx, this.cy);
  }
  
  public synchronized GRectangle getBounds(AffineTransform paramAffineTransform)
  {
    int i = this.vertices.size();
    if (i == 0) {
      return new GRectangle();
    }
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = 0.0D;
    int j = 1;
    for (int k = 0; k < this.vertices.size(); k++)
    {
      GPoint localGPoint = (GPoint)this.vertices.get(k);
      Point2D.Double localDouble = new Point2D.Double(localGPoint.getX(), localGPoint.getY());
      if (paramAffineTransform != null) {
        paramAffineTransform.transform(localDouble, localDouble);
      }
      double d5 = localDouble.getX();
      double d6 = localDouble.getY();
      if (j != 0)
      {
        d1 = d5;
        d2 = d5;
        d3 = d6;
        d4 = d6;
        j = 0;
      }
      else
      {
        d1 = Math.min(d1, d5);
        d2 = Math.max(d2, d5);
        d3 = Math.min(d3, d6);
        d4 = Math.max(d4, d6);
      }
    }
    return new GRectangle(d1, d3, d2 - d1, d4 - d3);
  }
  
  public synchronized boolean contains(double paramDouble1, double paramDouble2, AffineTransform paramAffineTransform)
  {
    int i = this.vertices.size();
    boolean bool = false;
    for (int j = 0; j < i; j++)
    {
      GPoint localGPoint = (GPoint)this.vertices.get(j);
      Point2D.Double localDouble1 = new Point2D.Double(localGPoint.getX(), localGPoint.getY());
      if (paramAffineTransform != null) {
        paramAffineTransform.transform(localDouble1, localDouble1);
      }
      localGPoint = (GPoint)this.vertices.get((j + 1) % i);
      Point2D.Double localDouble2 = new Point2D.Double(localGPoint.getX(), localGPoint.getY());
      if (paramAffineTransform != null) {
        paramAffineTransform.transform(localDouble2, localDouble2);
      }
      if (((localDouble1.getY() < paramDouble2) && (localDouble2.getY() >= paramDouble2)) || ((localDouble2.getY() < paramDouble2) && (localDouble1.getY() >= paramDouble2))) {
        if (localDouble1.getX() + (paramDouble2 - localDouble1.getY()) / (localDouble2.getY() - localDouble1.getY()) * (localDouble2.getX() - localDouble1.getX()) < paramDouble1) {
          bool = !bool;
        }
      }
    }
    return bool;
  }
  
  public void recenter()
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = 0.0D;
    int i = 1;
    for (int j = 0; j < this.vertices.size(); j++)
    {
      GPoint localGPoint1 = (GPoint)this.vertices.get(j);
      if (i != 0)
      {
        d1 = localGPoint1.getX();
        d2 = localGPoint1.getX();
        d3 = localGPoint1.getY();
        d4 = localGPoint1.getY();
        i = 0;
      }
      else
      {
        d1 = Math.min(d1, localGPoint1.getX());
        d2 = Math.max(d2, localGPoint1.getX());
        d3 = Math.min(d3, localGPoint1.getY());
        d4 = Math.max(d4, localGPoint1.getY());
      }
    }
    double d5 = (d1 + d2) / 2.0D;
    double d6 = (d3 + d4) / 2.0D;
    for (int k = 0; k < this.vertices.size(); k++)
    {
      GPoint localGPoint2 = (GPoint)this.vertices.get(k);
      localGPoint2.translate(-d5, -d6);
    }
  }
}
