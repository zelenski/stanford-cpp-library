package acm.graphics;

import java.awt.Dimension;
import java.io.Serializable;

public class GDimension
  implements Serializable
{
  private double width;
  private double height;
  static final long serialVersionUID = 21L;
  
  public GDimension()
  {
    this(0.0D, 0.0D);
  }
  
  public GDimension(double paramDouble1, double paramDouble2)
  {
    this.width = paramDouble1;
    this.height = paramDouble2;
  }
  
  public GDimension(GDimension paramGDimension)
  {
    this(paramGDimension.width, paramGDimension.height);
  }
  
  public GDimension(Dimension paramDimension)
  {
    this(paramDimension.width, paramDimension.height);
  }
  
  public double getWidth()
  {
    return this.width;
  }
  
  public double getHeight()
  {
    return this.height;
  }
  
  public void setSize(double paramDouble1, double paramDouble2)
  {
    this.width = paramDouble1;
    this.height = paramDouble2;
  }
  
  public void setSize(GDimension paramGDimension)
  {
    setSize(paramGDimension.width, paramGDimension.height);
  }
  
  public GDimension getSize()
  {
    return new GDimension(this.width, this.height);
  }
  
  public Dimension toDimension()
  {
    return new Dimension((int)Math.round(this.width), (int)Math.round(this.height));
  }
  
  public int hashCode()
  {
    return new Float((float)this.width).hashCode() ^ 37 * new Float((float)this.height).hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof GDimension)) {
      return false;
    }
    GDimension localGDimension = (GDimension)paramObject;
    return ((float)this.width == (float)localGDimension.width) && ((float)this.height == (float)localGDimension.height);
  }
  
  public String toString()
  {
    return "(" + (float)this.width + "x" + (float)this.height + ")";
  }
}
