package acm.graphics;

import acm.util.ErrorException;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Rectangle2D;

public class GOval
  extends GObject
  implements GFillable, GResizable
{
  private double frameWidth;
  private double frameHeight;
  private boolean isFilled;
  private Color fillColor;
  static final long serialVersionUID = 21L;
  
  public GOval(double paramDouble1, double paramDouble2)
  {
    this(0.0D, 0.0D, paramDouble1, paramDouble2);
  }
  
  public GOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    this.frameWidth = paramDouble3;
    this.frameHeight = paramDouble4;
    setLocation(paramDouble1, paramDouble2);
  }
  
  public GRectangle getBounds()
  {
    Object localObject = new Ellipse2D.Double(0.0D, 0.0D, this.frameWidth, this.frameHeight);
    AffineTransform localAffineTransform = getMatrix();
    if (localAffineTransform != null) {
      localObject = localAffineTransform.createTransformedShape((Shape)localObject);
    }
    Rectangle localRectangle = ((Shape)localObject).getBounds();
    return new GRectangle(localRectangle.getX() + getX(), localRectangle.getY() + getY(), localRectangle.getWidth(), localRectangle.getHeight());
  }
  
  public boolean contains(double paramDouble1, double paramDouble2)
  {
    Object localObject = new Ellipse2D.Double(0.0D, 0.0D, this.frameWidth, this.frameHeight);
    AffineTransform localAffineTransform = getMatrix();
    if (localAffineTransform != null) {
      localObject = localAffineTransform.createTransformedShape((Shape)localObject).getBounds();
    }
    return ((Shape)localObject).contains(paramDouble1 - getX(), paramDouble2 - getY());
  }
  
  protected void paint2d(Graphics2D paramGraphics2D)
  {
    Ellipse2D.Double localDouble = new Ellipse2D.Double(0.0D, 0.0D, this.frameWidth, this.frameHeight);
    if (isFilled())
    {
      paramGraphics2D.setColor(getFillColor());
      paramGraphics2D.fill(localDouble);
      paramGraphics2D.setColor(getColor());
    }
    paramGraphics2D.draw(localDouble);
  }
  
  public void setFilled(boolean paramBoolean)
  {
    this.isFilled = paramBoolean;
    repaint();
  }
  
  public boolean isFilled()
  {
    return this.isFilled;
  }
  
  public void setFillColor(Color paramColor)
  {
    this.fillColor = paramColor;
    repaint();
  }
  
  public Color getFillColor()
  {
    return this.fillColor == null ? getColor() : this.fillColor;
  }
  
  public void setSize(double paramDouble1, double paramDouble2)
  {
    if (getMatrix() != null) {
      throw new ErrorException("setSize: Object has been transformed");
    }
    this.frameWidth = paramDouble1;
    this.frameHeight = paramDouble2;
    repaint();
  }
  
  public final void setSize(GDimension paramGDimension)
  {
    setSize(paramGDimension.getWidth(), paramGDimension.getHeight());
  }
  
  public GDimension getSize()
  {
    return new GDimension(this.frameWidth, this.frameHeight);
  }
  
  public void setBounds(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    if (getMatrix() != null) {
      throw new ErrorException("setBounds: Object has been transformed");
    }
    this.frameWidth = paramDouble3;
    this.frameHeight = paramDouble4;
    setLocation(paramDouble1, paramDouble2);
  }
  
  public final void setBounds(GRectangle paramGRectangle)
  {
    if (getMatrix() != null) {
      throw new ErrorException("setBounds: Object has been transformed");
    }
    setBounds(paramGRectangle.getX(), paramGRectangle.getY(), paramGRectangle.getWidth(), paramGRectangle.getHeight());
  }
}
