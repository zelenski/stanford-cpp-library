package acm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

class EndRegionElement
  extends PathElement
{
  public void paint(Graphics2D paramGraphics2D, PathState paramPathState)
  {
    Color localColor = paramGraphics2D.getColor();
    paramGraphics2D.setColor(paramPathState.fillColor);
    paramGraphics2D.fillPolygon(paramPathState.region.xpoints, paramPathState.region.ypoints, paramPathState.region.npoints);
    
    paramGraphics2D.setColor(localColor);
    paramGraphics2D.drawPolygon(paramPathState.region.xpoints, paramPathState.region.ypoints, paramPathState.region.npoints);
    
    paramPathState.region = null;
  }
}
