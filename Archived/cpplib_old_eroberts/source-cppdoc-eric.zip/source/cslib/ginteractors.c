/*
 * File: ginteractors.c
 * --------------------
 * This file is empty.  The ginteractors.h interface is implemented by the
 * gobjects.c file.
 */
