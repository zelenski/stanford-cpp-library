package stanford.spl;

import acm.graphics.GObject;
import acm.util.ErrorException;
import acm.util.JTFTools;
import acm.util.Platform;
import acm.util.TokenScanner;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class JavaBackEnd
  implements WindowListener, MouseListener, MouseMotionListener, KeyListener, ActionListener, ComponentListener, ChangeListener
{
  public static final int DEFAULT_CONSOLE_X = 10;
  public static final int DEFAULT_CONSOLE_Y = 40;
  public static final int DEFAULT_CONSOLE_WIDTH = 500;
  public static final int DEFAULT_CONSOLE_HEIGHT = 250;
  public static final int DEFAULT_GRAPHICS_X = 10;
  public static final int DEFAULT_GRAPHICS_Y = 10;
  public static final int EVENT_SUBTYPE_MASK = 15;
  public static final int ACTION_EVENT = 16;
  public static final int KEY_EVENT = 32;
  public static final int TIMER_EVENT = 64;
  public static final int WINDOW_EVENT = 128;
  public static final int MOUSE_EVENT = 256;
  public static final int CLICK_EVENT = 512;
  public static final int ANY_EVENT = 1008;
  public static final int WINDOW_CLOSED = 129;
  public static final int WINDOW_RESIZED = 130;
  public static final int ACTION_PERFORMED = 17;
  public static final int MOUSE_CLICKED = 257;
  public static final int MOUSE_PRESSED = 258;
  public static final int MOUSE_RELEASED = 259;
  public static final int MOUSE_MOVED = 260;
  public static final int MOUSE_DRAGGED = 261;
  public static final int KEY_PRESSED = 33;
  public static final int KEY_RELEASED = 34;
  public static final int KEY_TYPED = 35;
  public static final int TIMER_TICKED = 65;
  public static final int SHIFT_DOWN = 1;
  public static final int CTRL_DOWN = 2;
  public static final int META_DOWN = 4;
  public static final int ALT_DOWN = 8;
  public static final int ALT_GRAPH_DOWN = 16;
  public static final int BUTTON1_DOWN = 32;
  public static final int BUTTON2_DOWN = 64;
  public static final int BUTTON3_DOWN = 128;
  private String appName;
  private String exec;
  private JBEMenuBar menuBar;
  private JBEConsole console;
  private JFrame consoleFrame;
  
  public static void main(String[] paramArrayOfString)
  {
    new JavaBackEnd().run(paramArrayOfString);
  }
  
  public void run(String[] paramArrayOfString)
  {
    processArguments(paramArrayOfString);
    initSystemProperties();
    this.cmdTable = JBECommand.createCommandTable();
    this.imageTable = new HashMap();
    this.windowTable = new HashMap();
    this.gobjTable = new HashMap();
    this.timerTable = new HashMap();
    this.clipTable = new HashMap();
    this.clipIdTable = new HashMap();
    this.sourceTable = new HashMap();
    this.eventMask = 0;
    this.eventAcknowledged = false;
    this.eventPending = false;
    this.activeWindowCount = 0;
    this.console = new JBEConsole();
    this.menuBar = new JBEMenuBar(this, this.console);
    this.console.setMenuBar(this.menuBar);
    if (this.exec != null) {
      try
      {
        Process localProcess = Runtime.getRuntime().exec(this.exec);
        System.setIn(localProcess.getInputStream());
        System.setOut(new PrintStream(localProcess.getOutputStream(), true));
      }
      catch (IOException localIOException)
      {
        System.err.println("Can't exec process");
      }
    }
    commandLoop();
  }
  
  protected void createWindow(String paramString, int paramInt1, int paramInt2, TopCompound paramTopCompound)
  {
    JBEWindow localJBEWindow = new JBEWindow(this, paramString, this.appName, paramInt1, paramInt2);
    this.windowTable.put(paramString, localJBEWindow);
    this.consoleWidth = paramInt1;
    this.consoleY = (50 + paramInt2);
    localJBEWindow.pack();
    localJBEWindow.setLocation(10, 10);
    localJBEWindow.getCanvas().initOffscreenImage();
    localJBEWindow.getCanvas().setTopCompound(paramTopCompound);
    this.activeWindowCount += 1;
    localJBEWindow.setResizable(false);
    localJBEWindow.setVisible(true);
    waitForWindowActive(localJBEWindow);
  }
  
  protected void deleteWindow(String paramString)
  {
    this.windowTable.remove(paramString);
  }
  
  protected void defineGObject(String paramString, GObject paramGObject)
  {
    this.gobjTable.put(paramString, paramGObject);
  }
  
  protected void defineSource(JComponent paramJComponent, String paramString)
  {
    this.sourceTable.put(paramJComponent, paramString);
  }
  
  protected void deleteGObject(String paramString)
  {
    this.gobjTable.remove(paramString);
  }
  
  protected String getSourceId(JComponent paramJComponent)
  {
    return (String)this.sourceTable.get(paramJComponent);
  }
  
  protected GObject getGObject(String paramString)
  {
    return (GObject)this.gobjTable.get(paramString);
  }
  
  protected JComponent getInteractor(GObject paramGObject)
  {
    if ((paramGObject instanceof GInteractor)) {
      return ((GInteractor)paramGObject).getInteractor();
    }
    if ((paramGObject instanceof JBELabel)) {
      return ((JBELabel)paramGObject).getInteractor();
    }
    return null;
  }
  
  protected JBEWindow getWindow(String paramString)
  {
    return (JBEWindow)this.windowTable.get(paramString);
  }
  
  protected void clearConsole()
  {
    this.console.clear();
  }
  
  protected void setConsoleFont(String paramString)
  {
    this.console.setFont(JTFTools.decodeFont(paramString));
  }
  
  protected void setConsoleSize(int paramInt1, int paramInt2)
  {
    this.consoleWidth = paramInt1;
    this.consoleHeight = paramInt2;
  }
  
  protected String getConsole()
  {
    if (this.consoleFrame == null) {
      showConsole();
    }
    return this.console.readLine();
  }
  
  protected void putConsole(String paramString)
  {
    if (this.consoleFrame == null) {
      showConsole();
    }
    this.console.print(paramString);
  }
  
  protected void endLineConsole()
  {
    if (this.consoleFrame == null) {
      showConsole();
    }
    this.console.println();
  }
  
  protected double getEventTime()
  {
    return new Date().getTime();
  }
  
  protected void println(String paramString)
  {
    synchronized (this.eventLock)
    {
      System.out.println(paramString);
      System.out.flush();
    }
  }
  
  protected void acknowledgeEvent()
  {
    synchronized (this.eventLock)
    {
      if (!this.eventAcknowledged)
      {
        System.out.println("result:ack");
        System.out.flush();
        this.eventAcknowledged = true;
        this.eventPending = false;
      }
      else
      {
        this.eventPending = true;
      }
    }
  }
  
  protected void getNextEvent(int paramInt)
  {
    synchronized (this.eventLock)
    {
      this.eventAcknowledged = false;
      this.eventPending = false;
      acknowledgeEvent();
      this.eventMask = paramInt;
    }
  }
  
  protected void waitForEvent(int paramInt)
  {
    synchronized (this.eventLock)
    {
      this.eventAcknowledged = false;
      if (this.eventPending) {
        acknowledgeEvent();
      }
      this.eventMask = paramInt;
    }
  }
  
  private void showConsole()
  {
    this.console.setPreferredSize(this.consoleWidth, this.consoleHeight);
    this.consoleFrame = new JFrame("Console");
    this.consoleFrame.setLayout(new BorderLayout());
    this.consoleFrame.add(this.console);
    this.consoleFrame.pack();
    this.consoleFrame.setLocation(this.consoleX, this.consoleY);
    this.consoleFrame.addWindowListener(this);
    if (Platform.isMac()) {
      this.menuBar.install(this.consoleFrame);
    } else {
      this.consoleFrame.setJMenuBar(this.menuBar);
    }
    this.consoleFrame.setVisible(true);
    waitForWindowActive(this.consoleFrame);
    this.activeWindowCount += 1;
  }
  
  protected void createSound(String paramString1, String paramString2)
  {
    Clip localClip = getClip(paramString2);
    this.clipIdTable.put(paramString1, localClip);
  }
  
  protected void deleteSound(String paramString)
  {
    this.clipIdTable.remove(paramString);
  }
  
  protected void playSound(String paramString)
  {
    Clip localClip = (Clip)this.clipIdTable.get(paramString);
    if (localClip != null)
    {
      localClip.stop();
      localClip.setFramePosition(0);
      localClip.start();
    }
  }
  
  protected void createTimer(String paramString, double paramDouble)
  {
    GTimer localGTimer = new GTimer(paramString, paramDouble);
    localGTimer.addActionListener(this);
    this.timerTable.put(paramString, localGTimer);
  }
  
  protected void deleteTimer(String paramString)
  {
    GTimer localGTimer = (GTimer)this.timerTable.get(paramString);
    if (localGTimer != null) {
      localGTimer.stop();
    }
    this.timerTable.remove(paramString);
  }
  
  protected void startTimer(String paramString)
  {
    GTimer localGTimer = (GTimer)this.timerTable.get(paramString);
    if (localGTimer != null) {
      localGTimer.start();
    }
  }
  
  protected void stopTimer(String paramString)
  {
    GTimer localGTimer = (GTimer)this.timerTable.get(paramString);
    if (localGTimer != null) {
      localGTimer.stop();
    }
  }
  
  private int convertModifiers(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x40) != 0) {
      i |= 0x1;
    }
    if ((paramInt & 0x80) != 0) {
      i |= 0x2;
    }
    if ((paramInt & 0x100) != 0) {
      i |= 0x4;
    }
    if ((paramInt & 0x200) != 0) {
      i |= 0x8;
    }
    if ((paramInt & 0x2000) != 0) {
      i |= 0x10;
    }
    if ((paramInt & 0x400) != 0) {
      i |= 0x20;
    }
    if ((paramInt & 0x800) != 0) {
      i |= 0x40;
    }
    if ((paramInt & 0x1000) != 0) {
      i |= 0x80;
    }
    return i;
  }
  
  protected String openFileDialog(String paramString1, String paramString2, String paramString3)
  {
    JBEFileFilter localJBEFileFilter = new JBEFileFilter(paramString3);
    JFileChooser localJFileChooser = new JFileChooser(localJBEFileFilter.getDirectory());
    localJFileChooser.setFileFilter(localJBEFileFilter);
    localJFileChooser.setDialogTitle(paramString1);
    int i = 0;
    if (paramString2.equalsIgnoreCase("load")) {
      i = localJFileChooser.showOpenDialog(null);
    } else if (paramString2.equalsIgnoreCase("save")) {
      i = localJFileChooser.showSaveDialog(null);
    } else {
      return "";
    }
    if (i == 0) {
      return localJFileChooser.getSelectedFile().getAbsolutePath();
    }
    return "";
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    Object localObject1 = paramActionEvent.getSource();
    synchronized (this.eventLock)
    {
      Object localObject2;
      if ((localObject1 instanceof GTimer))
      {
        if ((this.eventMask & 0x40) != 0)
        {
          localObject2 = (GTimer)paramActionEvent.getSource();
          System.out.print("event:timerTicked");
          System.out.print("(\"" + ((GTimer)localObject2).getId() + "\", " + getEventTime());
          
          System.out.println(")");
          System.out.flush();
          acknowledgeEvent();
        }
      }
      else if ((this.eventMask & 0x10) != 0)
      {
        localObject2 = getSourceId((JComponent)localObject1);
        GInteractor localGInteractor = (GInteractor)getGObject((String)localObject2);
        String str = localGInteractor.getActionCommand();
        if (!str.isEmpty())
        {
          System.out.print("event:actionPerformed");
          System.out.print("(\"" + (String)localObject2 + "\", \"" + str + "\", " + getEventTime());
          
          System.out.println(")");
          System.out.flush();
          acknowledgeEvent();
        }
      }
    }
  }
  
  public void keyPressed(KeyEvent paramKeyEvent)
  {
    if ((this.eventMask & 0x20) != 0)
    {
      printEvent("keyPressed", paramKeyEvent);
      acknowledgeEvent();
    }
  }
  
  public void keyReleased(KeyEvent paramKeyEvent)
  {
    if ((this.eventMask & 0x20) != 0)
    {
      printEvent("keyReleased", paramKeyEvent);
      acknowledgeEvent();
    }
  }
  
  public void keyTyped(KeyEvent paramKeyEvent)
  {
    if ((this.eventMask & 0x20) != 0)
    {
      printEvent("keyTyped", paramKeyEvent);
      acknowledgeEvent();
    }
  }
  
  private void printEvent(String paramString, KeyEvent paramKeyEvent)
  {
    JBECanvas localJBECanvas = (JBECanvas)paramKeyEvent.getSource();
    synchronized (this.eventLock)
    {
      System.out.print("event:" + paramString);
      System.out.print("(\"" + localJBECanvas.getWindowId() + "\", " + getEventTime());
      System.out.print(", " + convertModifiers(paramKeyEvent.getModifiersEx()));
      System.out.print(", " + paramKeyEvent.getKeyChar());
      System.out.println(", " + paramKeyEvent.getKeyCode() + ")");
      System.out.flush();
    }
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    ((Component)paramMouseEvent.getSource()).requestFocus();
    if ((this.eventMask & 0x300) != 0)
    {
      printEvent("mouseClicked", paramMouseEvent);
      acknowledgeEvent();
    }
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    if ((this.eventMask & 0x100) != 0)
    {
      printEvent("mousePressed", paramMouseEvent);
      acknowledgeEvent();
    }
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    if ((this.eventMask & 0x100) != 0)
    {
      printEvent("mouseReleased", paramMouseEvent);
      acknowledgeEvent();
    }
  }
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    if ((this.eventMask & 0x100) != 0)
    {
      printEvent("mouseMoved", paramMouseEvent);
      acknowledgeEvent();
    }
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    if ((this.eventMask & 0x100) != 0)
    {
      printEvent("mouseDragged", paramMouseEvent);
      acknowledgeEvent();
    }
  }
  
  private void printEvent(String paramString, MouseEvent paramMouseEvent)
  {
    JBECanvas localJBECanvas = (JBECanvas)paramMouseEvent.getSource();
    synchronized (this.eventLock)
    {
      System.out.print("event:" + paramString);
      System.out.print("(\"" + localJBECanvas.getWindowId() + "\", " + getEventTime());
      System.out.print(", " + convertModifiers(paramMouseEvent.getModifiersEx()));
      System.out.println(", " + paramMouseEvent.getX() + ", " + paramMouseEvent.getY() + ")");
      System.out.flush();
    }
  }
  
  public void windowActivated(WindowEvent paramWindowEvent) {}
  
  public void windowClosed(WindowEvent paramWindowEvent)
  {
    windowClosing(paramWindowEvent);
  }
  
  public void windowClosing(WindowEvent paramWindowEvent)
  {
    if (paramWindowEvent.getSource() != this.consoleFrame)
    {
      JBEWindow localJBEWindow = (JBEWindow)paramWindowEvent.getSource();
      synchronized (this.eventLock)
      {
        System.out.print("event:windowClosed");
        System.out.print("(\"" + localJBEWindow.getWindowId());
        System.out.print("\", " + getEventTime());
        System.out.println(")");
        System.out.flush();
        acknowledgeEvent();
      }
      this.windowTable.remove(localJBEWindow.getWindowId());
    }
    this.activeWindowCount -= 1;
    if (this.activeWindowCount == 0)
    {
      synchronized (this.eventLock)
      {
        System.out.println("event:lastWindowGWindow_closed()");
        System.out.flush();
        acknowledgeEvent();
      }
      System.exit(0);
    }
  }
  
  public void windowDeactivated(WindowEvent paramWindowEvent) {}
  
  public void windowDeiconified(WindowEvent paramWindowEvent) {}
  
  public void windowIconified(WindowEvent paramWindowEvent) {}
  
  public void windowOpened(WindowEvent paramWindowEvent)
  {
    JFrame localJFrame = (JFrame)paramWindowEvent.getSource();
    synchronized (localJFrame)
    {
      localJFrame.notifyAll();
    }
  }
  
  private void waitForWindowActive(JFrame paramJFrame)
  {
    synchronized (paramJFrame)
    {
      while (!paramJFrame.isShowing()) {
        try
        {
          paramJFrame.wait();
          Thread.sleep(100L);
        }
        catch (InterruptedException localInterruptedException) {}
      }
    }
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    Object localObject1 = paramChangeEvent.getSource();
    synchronized (this.eventLock)
    {
      if ((this.eventMask & 0x10) != 0)
      {
        String str1 = getSourceId((JComponent)localObject1);
        GInteractor localGInteractor = (GInteractor)getGObject(str1);
        String str2 = localGInteractor.getActionCommand();
        if (!str2.isEmpty())
        {
          System.out.print("event:actionPerformed");
          System.out.print("(\"" + str1 + "\", \"" + str2 + "\", " + getEventTime());
          
          System.out.println(")");
          System.out.flush();
          acknowledgeEvent();
        }
      }
    }
  }
  
  public void componentHidden(ComponentEvent paramComponentEvent) {}
  
  public void componentMoved(ComponentEvent paramComponentEvent) {}
  
  public void componentResized(ComponentEvent paramComponentEvent)
  {
    if ((this.eventMask & 0x80) != 0)
    {
      JBECanvas localJBECanvas = (JBECanvas)paramComponentEvent.getSource();
      synchronized (this.eventLock)
      {
        System.out.print("event:windowResized");
        System.out.print("(\"" + localJBECanvas.getWindowId());
        System.out.print("\", " + getEventTime());
        System.out.println(")");
        System.out.flush();
        acknowledgeEvent();
      }
    }
  }
  
  public void componentShown(ComponentEvent paramComponentEvent) {}
  
  private void commandLoop()
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(System.in));
    TokenScanner localTokenScanner = new TokenScanner();
    localTokenScanner.ignoreWhitespace();
    localTokenScanner.scanNumbers();
    localTokenScanner.scanStrings();
    localTokenScanner.addWordCharacters(".");
    try
    {
      for (;;)
      {
        String str1 = localBufferedReader.readLine();
        if (str1 == null) {
          break;
        }
        localTokenScanner.setInput(str1);
        String str2 = localTokenScanner.nextToken();
        JBECommand localJBECommand = (JBECommand)this.cmdTable.get(str2);
        if (localJBECommand != null) {
          localJBECommand.execute(localTokenScanner, this);
        }
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace(System.err);
      System.err.println("Unexpected error: " + localException.getMessage());
    }
  }
  
  private void processArguments(String[] paramArrayOfString)
  {
    this.appName = "JBE";
    this.exec = null;
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      String str = paramArrayOfString[i];
      if (str.startsWith("-"))
      {
        if (str.equals("-exec")) {
          this.exec = paramArrayOfString[(++i)];
        } else {
          System.err.println("Error: Unrecognized option " + str);
        }
      }
      else {
        this.appName = str;
      }
    }
  }
  
  private void initSystemProperties()
  {
    System.setProperty("com.apple.mrj.application.apple.menu.about.name", this.appName);
    
    System.setProperty("apple.laf.useScreenMenuBar", "true");
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception localException) {}
  }
  
  protected Image getImage(String paramString)
  {
    Image localImage = (Image)this.imageTable.get(paramString);
    if (localImage != null) {
      return localImage;
    }
    Toolkit localToolkit = Toolkit.getDefaultToolkit();
    if (paramString.startsWith("http:"))
    {
      try
      {
        localImage = localToolkit.getImage(new URL(paramString));
      }
      catch (MalformedURLException localMalformedURLException)
      {
        throw new ErrorException("loadImage: Malformed URL");
      }
    }
    else
    {
      localObject = new File(paramString);
      if ((!((File)localObject).exists()) && 
        (!paramString.startsWith("/")) && (!paramString.startsWith("."))) {
        localObject = new File("images/" + paramString);
      }
      if (!((File)localObject).exists()) {
        throw new ErrorException("loadImage: File not found");
      }
      localImage = localToolkit.getImage(((File)localObject).getAbsolutePath());
    }
    if (localImage == null) {
      throw new ErrorException("loadImage: File not found");
    }
    Object localObject = new MediaTracker(this.empty);
    ((MediaTracker)localObject).addImage(localImage, 0);
    try
    {
      ((MediaTracker)localObject).waitForID(0);
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new ErrorException("loadImage: Loading interrupted");
    }
    this.imageTable.put(paramString, localImage);
    return localImage;
  }
  
  protected Clip getClip(String paramString)
  {
    Clip localClip = (Clip)this.clipTable.get(paramString);
    if (localClip != null) {
      return localClip;
    }
    try
    {
      localClip = AudioSystem.getClip();
      File localFile = new File(paramString);
      if ((!localFile.exists()) && 
        (!paramString.startsWith("/")) && (!paramString.startsWith("."))) {
        localFile = new File("sounds/" + paramString);
      }
      if (!localFile.exists()) {
        throw new ErrorException("createClip: File not found");
      }
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      AudioInputStream localAudioInputStream = AudioSystem.getAudioInputStream(localFileInputStream);
      localClip.open(localAudioInputStream);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("getClip: File not found");
    }
    catch (Exception localException)
    {
      throw new ErrorException("getClip: " + localException);
    }
    this.clipTable.put(paramString, localClip);
    return localClip;
  }
  
  private int consoleX = 10;
  private int consoleY = 40;
  private int consoleWidth = 500;
  private int consoleHeight = 250;
  private HashMap<String, JBECommand> cmdTable;
  private HashMap<String, JBEWindow> windowTable;
  private HashMap<String, GObject> gobjTable;
  private HashMap<String, GTimer> timerTable;
  private HashMap<String, Image> imageTable;
  private HashMap<String, Clip> clipTable;
  private HashMap<String, Clip> clipIdTable;
  private HashMap<JComponent, String> sourceTable;
  private Container empty = JTFTools.createEmptyContainer();
  private int activeWindowCount;
  private int eventMask;
  private Object eventLock = new Object();
  private boolean eventAcknowledged;
  private boolean eventPending;
}
