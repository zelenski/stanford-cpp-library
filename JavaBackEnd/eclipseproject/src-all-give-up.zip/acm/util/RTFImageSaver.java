package acm.util;

import java.awt.Image;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.PrintStream;

class RTFImageSaver
  extends PICTImageSaver
{
  public void saveImage(Image paramImage)
  {
    int i = paramImage.getWidth(null);
    int j = paramImage.getHeight(null);
    PrintStream localPrintStream = new PrintStream(new BufferedOutputStream(getOutputStream()));
    setOutputStream(JTFTools.openHexByteOutputStream(localPrintStream));
    for (int k = 0; k < RTF_HEADER.length; k++) {
      localPrintStream.println(RTF_HEADER[k]);
    }
    localPrintStream.println("{{\\pict\\macpict\\picw" + i + "\\pich" + j);
    setPaddingFlag(false);
    super.saveImage(paramImage);
    localPrintStream.println("}}\\par");
    localPrintStream.println("}");
    localPrintStream.close();
  }
  
  public void updateFileType(File paramFile)
  {
    Platform.setFileTypeAndCreator(paramFile, "TEXT", "MSWD");
  }
  
  private static final String[] RTF_HEADER = { "{\\rtf1\\mac\\deff2", "{\\fonttbl{\\f20\\froman Times;} {\\f22\\fmodern Courier;}}", "{\\colortbl\\red0\\green0\\blue0;\\red0\\green0\\blue255;", "\\red0\\green255\\blue255;\\red0\\green255\\blue0;", "\\red255\\green0\\blue255;\\red255\\green0\\blue0;", "\\red255\\green255\\blue0;\\red255\\green255\\blue255;}", "{\\stylesheet{\\f20 \\sbasedon222\\snext0 Normal;}}", "\\widowctrl\\ftnbj \\sectd \\sbknone\\linemod0\\linex0\\cols1\\endnhere", "\\pard\\plain \\s0\\qc\\f20" };
}
