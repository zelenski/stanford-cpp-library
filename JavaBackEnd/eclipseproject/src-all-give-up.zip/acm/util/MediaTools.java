package acm.util;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.AlphaComposite;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.ImageProducer;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.StringTokenizer;

public class MediaTools
{
  public static final String DEFAULT_IMAGE_PATH = ".:images";
  public static final String DEFAULT_AUDIO_PATH = ".:sounds";
  public static final String DEFAULT_DATAFILE_PATH = ".:datafiles";
  
  public static Image loadImage(String paramString)
  {
    return loadImage(paramString, ".:images");
  }
  
  public static Image loadImage(String paramString1, String paramString2)
  {
    Image localImage = (Image)imageTable.get(paramString1);
    if (localImage != null) {
      return localImage;
    }
    if (paramString1.startsWith("http:")) {
      try
      {
        localImage = loadImage(new URL(paramString1));
        if (cachingEnabled) {
          imageTable.put(paramString1, localImage);
        }
        return localImage;
      }
      catch (MalformedURLException localMalformedURLException1)
      {
        throw new ErrorException("loadImage: Malformed URL");
      }
    }
    Toolkit localToolkit = Toolkit.getDefaultToolkit();
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString2, ":");
    while ((localImage == null) && (localStringTokenizer.hasMoreTokens()))
    {
      String str = localStringTokenizer.nextToken();
      str = str + "/";
      URL localURL1 = null;
      try
      {
        localURL1 = RESOURCE_CLASS.getResource("/" + str + paramString1);
        URLConnection localURLConnection = localURL1.openConnection();
        if ((localURLConnection == null) || (localURLConnection.getContentLength() <= 0)) {
          localURL1 = null;
        }
      }
      catch (Exception localException) {}
      if (localURL1 == null)
      {
        Applet localApplet = JTFTools.getApplet();
        if (localApplet != null)
        {
          URL localURL2 = localApplet.getCodeBase();
          if (localURL2 != null) {
            try
            {
              localURL1 = new URL(localURL2, str + paramString1);
            }
            catch (MalformedURLException localMalformedURLException2) {}
          }
        }
      }
      if (localURL1 == null) {
        try
        {
          if (new File(str + paramString1).canRead()) {
            localImage = localToolkit.getImage(str + paramString1);
          }
        }
        catch (SecurityException localSecurityException) {}
      } else {
        localImage = loadImage(localURL1, false);
      }
    }
    if (localImage == null) {
      throw new ErrorException("Cannot find an image named " + paramString1);
    }
    loadImage(localImage);
    if (cachingEnabled) {
      imageTable.put(paramString1, localImage);
    }
    return localImage;
  }
  
  public static Image loadImage(URL paramURL)
  {
    return loadImage(paramURL, true);
  }
  
  public static Image loadImage(Image paramImage)
  {
    MediaTracker localMediaTracker = new MediaTracker(JTFTools.createEmptyContainer());
    localMediaTracker.addImage(paramImage, 0);
    try
    {
      localMediaTracker.waitForID(0);
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new ErrorException("Image loading process interrupted");
    }
    return paramImage;
  }
  
  public static void defineImage(String paramString, Image paramImage)
  {
    imageTable.put(paramString, paramImage);
  }
  
  public static void flushImage(String paramString)
  {
    imageTable.remove(paramString);
  }
  
  public static Image createImage(int[][] paramArrayOfInt)
  {
    int i = paramArrayOfInt.length;
    int j = paramArrayOfInt[0].length;
    int[] arrayOfInt = new int[j * i];
    for (int k = 0; k < i; k++) {
      System.arraycopy(paramArrayOfInt[k], 0, arrayOfInt, k * j, j);
    }
    return createImage(arrayOfInt, j, i);
  }
  
  public static Image createImage(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    Image localImage = Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(paramInt1, paramInt2, paramArrayOfInt, 0, paramInt1));
    loadImage(localImage);
    return localImage;
  }
  
  public static Image createImage(InputStream paramInputStream)
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      for (int i = paramInputStream.read(); i != -1; i = paramInputStream.read()) {
        localByteArrayOutputStream.write(i);
      }
      Image localImage = Toolkit.getDefaultToolkit().createImage(localByteArrayOutputStream.toByteArray());
      loadImage(localImage);
      return localImage;
    }
    catch (Exception localException)
    {
      throw new ErrorException("Exception: " + localException);
    }
  }
  
  public static Image createImage(String[] paramArrayOfString)
  {
    return createImage(new HexInputStream(paramArrayOfString));
  }
  
  public static int[][] getPixelArray(Image paramImage)
  {
    Component localComponent = getImageObserver();
    int i = paramImage.getWidth(localComponent);
    int j = paramImage.getHeight(localComponent);
    int[] arrayOfInt = new int[i * j];
    int[][] arrayOfInt1 = new int[j][i];
    PixelGrabber localPixelGrabber = new PixelGrabber(paramImage.getSource(), 0, 0, i, j, arrayOfInt, 0, i);
    try
    {
      localPixelGrabber.grabPixels();
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new ErrorException("Transfer interrupted");
    }
    if ((localPixelGrabber.getStatus() & 0x80) != 0) {
      throw new ErrorException("Transfer aborted");
    }
    for (int k = 0; k < j; k++) {
      System.arraycopy(arrayOfInt, k * i, arrayOfInt1[k], 0, i);
    }
    return arrayOfInt1;
  }
  
  public static void saveImage(Image paramImage, String paramString)
  {
    saveImage(paramImage, new File(paramString));
  }
  
  public static void saveImage(Image paramImage, File paramFile)
  {
    String str1 = paramFile.getName();
    int i = str1.lastIndexOf('.');
    if (i <= 0) {
      throw new ErrorException("saveImage: No image suffix in file name");
    }
    String str2 = str1.substring(i + 1);
    ImageSaver localImageSaver = findImageSaver(str2);
    if (localImageSaver == null) {
      throw new ErrorException("saveImage: No support for ." + str2 + " format");
    }
    if ((paramFile.exists()) && 
      (!paramFile.delete())) {
      throw new ErrorException("saveImage: Cannot replace " + str1);
    }
    try
    {
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramFile));
      localImageSaver.setOutputStream(localBufferedOutputStream);
      localImageSaver.saveImage(paramImage);
      localImageSaver.updateFileType(paramFile);
      localBufferedOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public static AudioClip loadAudioClip(String paramString)
  {
    return loadAudioClip(paramString, ".:sounds");
  }
  
  public static AudioClip loadAudioClip(String paramString1, String paramString2)
  {
    AudioClip localAudioClip = (AudioClip)audioClipTable.get(paramString1);
    if (localAudioClip != null) {
      return localAudioClip;
    }
    if (paramString1.startsWith("http:")) {
      try
      {
        localAudioClip = loadAudioClip(new URL(paramString1));
        if ((localAudioClip instanceof SoundClip)) {
          ((SoundClip)localAudioClip).setName(paramString1);
        }
        if (cachingEnabled) {
          audioClipTable.put(paramString1, localAudioClip);
        }
        return localAudioClip;
      }
      catch (MalformedURLException localMalformedURLException1)
      {
        throw new ErrorException("loadAudioClip: Malformed URL");
      }
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString2, ":");
    while ((localAudioClip == null) && (localStringTokenizer.hasMoreTokens()))
    {
      String str = localStringTokenizer.nextToken();
      str = str + "/";
      URL localURL1 = null;
      try
      {
        localURL1 = RESOURCE_CLASS.getResource("/" + str + paramString1);
        URLConnection localURLConnection = localURL1.openConnection();
        if ((localURLConnection == null) || (localURLConnection.getContentLength() <= 0)) {
          localURL1 = null;
        }
      }
      catch (Exception localException1) {}
      Object localObject;
      if (localURL1 == null)
      {
        localObject = JTFTools.getApplet();
        if (localObject != null)
        {
          URL localURL2 = ((Applet)localObject).getCodeBase();
          if (localURL2 != null) {
            try
            {
              localURL1 = new URL(localURL2, str + paramString1);
            }
            catch (MalformedURLException localMalformedURLException2) {}
          }
        }
      }
      if (localURL1 == null) {
        try
        {
          localObject = new File(str + paramString1);
          if (((File)localObject).canRead()) {
            localAudioClip = createAudioClip(new FileInputStream((File)localObject));
          }
        }
        catch (Exception localException2) {}
      } else {
        localAudioClip = loadAudioClip(localURL1, false);
      }
    }
    if (localAudioClip == null) {
      throw new ErrorException("Cannot find an audio clip named " + paramString1);
    }
    if ((localAudioClip instanceof SoundClip)) {
      ((SoundClip)localAudioClip).setName(paramString1);
    }
    if (cachingEnabled) {
      audioClipTable.put(paramString1, localAudioClip);
    }
    return localAudioClip;
  }
  
  public static AudioClip loadAudioClip(URL paramURL)
  {
    return loadAudioClip(paramURL, true);
  }
  
  public static void defineAudioClip(String paramString, AudioClip paramAudioClip)
  {
    audioClipTable.put(paramString, paramAudioClip);
  }
  
  public static void flushAudioClip(String paramString)
  {
    audioClipTable.remove(paramString);
  }
  
  public static AudioClip createAudioClip(InputStream paramInputStream)
  {
    try
    {
      return new SunAudioClip(paramInputStream);
    }
    catch (Exception localException) {}
    return new NullAudioClip();
  }
  
  public static AudioClip createAudioClip(String[] paramArrayOfString)
  {
    return createAudioClip(new HexInputStream(paramArrayOfString));
  }
  
  public static InputStream openDataFile(String paramString)
  {
    return openDataFile(paramString, ".:datafiles");
  }
  
  public static InputStream openDataFile(String paramString1, String paramString2)
  {
    Object localObject1 = null;
    if (paramString1.startsWith("http:")) {
      try
      {
        return openDataFile(new URL(paramString1));
      }
      catch (MalformedURLException localMalformedURLException1)
      {
        throw new ErrorException("openDataFile: Malformed URL");
      }
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString2, ":");
    while ((localObject1 == null) && (localStringTokenizer.hasMoreTokens()))
    {
      String str = localStringTokenizer.nextToken();
      str = str + "/";
      URL localURL1 = null;
      try
      {
        localURL1 = RESOURCE_CLASS.getResource("/" + str + paramString1);
        URLConnection localURLConnection = localURL1.openConnection();
        if ((localURLConnection == null) || (localURLConnection.getContentLength() <= 0)) {
          localURL1 = null;
        }
      }
      catch (Exception localException1) {}
      Object localObject2;
      if (localURL1 == null)
      {
        localObject2 = JTFTools.getApplet();
        if (localObject2 != null)
        {
          URL localURL2 = ((Applet)localObject2).getCodeBase();
          if (localURL2 != null) {
            try
            {
              localURL1 = new URL(localURL2, str + paramString1);
            }
            catch (MalformedURLException localMalformedURLException2) {}
          }
        }
      }
      if (localURL1 == null) {
        try
        {
          localObject2 = new File(str + paramString1);
          if (((File)localObject2).canRead()) {
            localObject1 = new FileInputStream((File)localObject2);
          }
        }
        catch (Exception localException2) {}
      } else {
        localObject1 = openDataFile(localURL1, false);
      }
    }
    if (localObject1 == null) {
      throw new ErrorException("Cannot find a file named " + paramString1);
    }
    return localObject1;
  }
  
  public static InputStream openDataFile(URL paramURL)
  {
    return openDataFile(paramURL, true);
  }
  
  public static BufferedImage createBufferedImage(Image paramImage, int paramInt)
  {
    int i = paramImage.getWidth(null);
    int j = paramImage.getHeight(null);
    BufferedImage localBufferedImage = new BufferedImage(i, j, paramInt);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    switch (paramInt)
    {
    case 2: 
    case 3: 
    case 6: 
    case 7: 
      localGraphics2D.setComposite(AlphaComposite.Src);
    }
    localGraphics2D.drawImage(paramImage, 0, 0, null);
    localGraphics2D.dispose();
    return localBufferedImage;
  }
  
  public static InputStream getHexInputStream(String[] paramArrayOfString)
  {
    return new HexInputStream(paramArrayOfString);
  }
  
  public static void setCachingEnabled(boolean paramBoolean)
  {
    cachingEnabled = paramBoolean;
  }
  
  public static boolean isCachingEnabled()
  {
    return cachingEnabled;
  }
  
  public static Component getImageObserver()
  {
    return JTFTools.createEmptyContainer();
  }
  
  public static void beep()
  {
    Toolkit.getDefaultToolkit().beep();
  }
  
  public static Image loadImage(URL paramURL, boolean paramBoolean)
  {
    Image localImage = null;
    Toolkit localToolkit = Toolkit.getDefaultToolkit();
    try
    {
      URLConnection localURLConnection = paramURL.openConnection();
      if ((isResource(paramURL)) || (localURLConnection.getContentLength() > 0))
      {
        Object localObject = localURLConnection.getContent();
        if ((localObject instanceof ImageProducer)) {
          localImage = localToolkit.createImage((ImageProducer)localObject);
        } else if (localObject != null) {
          localImage = localToolkit.getImage(paramURL);
        }
      }
    }
    catch (IOException localIOException) {}
    if (paramBoolean)
    {
      if (localImage == null) {
        throw new ErrorException("Cannot load image from " + paramURL);
      }
      loadImage(localImage);
    }
    return localImage;
  }
  
  private static ImageSaver findImageSaver(String paramString)
  {
    paramString = paramString.toUpperCase();
    synchronized (suffixTable)
    {
      ImageSaver localImageSaver = (ImageSaver)suffixTable.get(paramString);
      if (localImageSaver == null)
      {
        try
        {
          Class localClass = Class.forName("acm.util." + paramString + "ImageSaver");
          localImageSaver = (ImageSaver)localClass.newInstance();
        }
        catch (Exception localException)
        {
          return null;
        }
        suffixTable.put(paramString, localImageSaver);
      }
      return localImageSaver;
    }
  }
  
  public static AudioClip loadAudioClip(URL paramURL, boolean paramBoolean)
  {
    AudioClip localAudioClip = null;
    try
    {
      URLConnection localURLConnection = paramURL.openConnection();
      if ((isResource(paramURL)) || (localURLConnection.getContentLength() > 0)) {
        localAudioClip = createAudioClip(localURLConnection.getInputStream());
      }
    }
    catch (IOException localIOException) {}
    if ((paramBoolean) && (localAudioClip == null)) {
      throw new ErrorException("Cannot load audio clip from " + paramURL);
    }
    return localAudioClip;
  }
  
  public static InputStream openDataFile(URL paramURL, boolean paramBoolean)
  {
    InputStream localInputStream = null;
    try
    {
      URLConnection localURLConnection = paramURL.openConnection();
      if ((isResource(paramURL)) || (localURLConnection.getContentLength() > 0)) {
        localInputStream = localURLConnection.getInputStream();
      }
    }
    catch (IOException localIOException) {}
    if ((paramBoolean) && (localInputStream == null)) {
      throw new ErrorException("Cannot read data from " + paramURL);
    }
    return localInputStream;
  }
  
  private static boolean isResource(URL paramURL)
  {
    String str = paramURL.toString().toLowerCase();
    return (str.startsWith("jar:")) || (str.startsWith("file:"));
  }
  
  private static boolean cachingEnabled = false;
  private static HashMap<String, Image> imageTable = new HashMap();
  private static HashMap<String, AudioClip> audioClipTable = new HashMap();
  private static HashMap<String, ImageSaver> suffixTable = new HashMap();
  private static final Class<?> RESOURCE_CLASS = new MediaTools().getClass();
}
