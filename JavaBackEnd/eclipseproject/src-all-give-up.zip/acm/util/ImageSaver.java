package acm.util;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.imageio.stream.MemoryCacheImageOutputStream;

class ImageSaver
{
  private OutputStream out;
  private String formatName;
  private int bufferType;
  
  public ImageSaver() {}
  
  public ImageSaver(String paramString, int paramInt)
  {
    this.formatName = paramString;
    this.bufferType = paramInt;
  }
  
  public void setOutputStream(OutputStream paramOutputStream)
  {
    this.out = paramOutputStream;
  }
  
  public OutputStream getOutputStream()
  {
    return this.out;
  }
  
  public void saveImage(Image paramImage)
  {
    BufferedImage localBufferedImage = MediaTools.createBufferedImage(paramImage, this.bufferType);
    MemoryCacheImageOutputStream localMemoryCacheImageOutputStream = new MemoryCacheImageOutputStream(getOutputStream());
    try
    {
      if (!ImageIO.write(localBufferedImage, this.formatName, localMemoryCacheImageOutputStream)) {
        throw new IOException("ImageIO.write failed");
      }
      localMemoryCacheImageOutputStream.close();
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public void updateFileType(File paramFile) {}
  
  public void dumpByte(int paramInt)
  {
    try
    {
      this.out.write(paramInt);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public void dumpShort(int paramInt)
  {
    try
    {
      this.out.write(paramInt >> 8);
      this.out.write(paramInt);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public void dumpLong(int paramInt)
  {
    try
    {
      this.out.write(paramInt >> 24);
      this.out.write(paramInt >> 16);
      this.out.write(paramInt >> 8);
      this.out.write(paramInt);
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public int getPixelComponent(int paramInt, char paramChar)
  {
    int i = paramInt >> 24 & 0xFF;
    switch (paramChar)
    {
    case 'R': 
      paramInt >>= 16; break;
    case 'G': 
      paramInt >>= 8; break;
    case 'B': 
      break;
    default: 
      throw new ErrorException("getPixelComponent: Illegal color");
    }
    paramInt &= 0xFF;
    return (i * paramInt + (255 - i) * 255) / 255;
  }
}
