package acm.util;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

class Gif89Encoder
{
  private Dimension dispDim = new Dimension(0, 0);
  private GifColorTable colorTable;
  private int bgIndex = 0;
  private int loopCount = 1;
  private String theComments;
  private Vector<Gif89Frame> vFrames = new Vector();
  
  public Gif89Encoder()
  {
    this.colorTable = new GifColorTable();
  }
  
  public Gif89Encoder(Image paramImage)
    throws IOException
  {
    this();
    addFrame(paramImage);
  }
  
  public Gif89Encoder(Color[] paramArrayOfColor)
  {
    this.colorTable = new GifColorTable(paramArrayOfColor);
  }
  
  public Gif89Encoder(Color[] paramArrayOfColor, int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws IOException
  {
    this(paramArrayOfColor);
    addFrame(paramInt1, paramInt2, paramArrayOfByte);
  }
  
  public int getFrameCount()
  {
    return this.vFrames.size();
  }
  
  public Gif89Frame getFrameAt(int paramInt)
  {
    return isOk(paramInt) ? (Gif89Frame)this.vFrames.elementAt(paramInt) : null;
  }
  
  public void addFrame(Gif89Frame paramGif89Frame)
    throws IOException
  {
    accommodateFrame(paramGif89Frame);
    this.vFrames.addElement(paramGif89Frame);
  }
  
  public void addFrame(Image paramImage)
    throws IOException
  {
    addFrame(new DirectGif89Frame(paramImage));
  }
  
  public void addFrame(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws IOException
  {
    addFrame(new IndexGif89Frame(paramInt1, paramInt2, paramArrayOfByte));
  }
  
  public void insertFrame(int paramInt, Gif89Frame paramGif89Frame)
    throws IOException
  {
    accommodateFrame(paramGif89Frame);
    this.vFrames.insertElementAt(paramGif89Frame, paramInt);
  }
  
  public void setTransparentIndex(int paramInt)
  {
    this.colorTable.setTransparent(paramInt);
  }
  
  public void setLogicalDisplay(Dimension paramDimension, int paramInt)
  {
    this.dispDim = new Dimension(paramDimension);
    this.bgIndex = paramInt;
  }
  
  public void setLoopCount(int paramInt)
  {
    this.loopCount = paramInt;
  }
  
  public void setComments(String paramString)
  {
    this.theComments = paramString;
  }
  
  public void setUniformDelay(int paramInt)
  {
    for (int i = 0; i < this.vFrames.size(); i++) {
      ((Gif89Frame)this.vFrames.elementAt(i)).setDelay(paramInt);
    }
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    int i = getFrameCount();
    boolean bool = i > 1;
    

    this.colorTable.closePixelProcessing();
    

    Gif89Put.ascii("GIF89a", paramOutputStream);
    

    writeLogicalScreenDescriptor(paramOutputStream);
    this.colorTable.encode(paramOutputStream);
    if ((bool) && (this.loopCount != 1)) {
      writeNetscapeExtension(paramOutputStream);
    }
    if ((this.theComments != null) && (this.theComments.length() > 0)) {
      writeCommentExtension(paramOutputStream);
    }
    for (int j = 0; j < i; j++) {
      ((Gif89Frame)this.vFrames.elementAt(j)).encode(paramOutputStream, bool, this.colorTable.getDepth(), this.colorTable.getTransparent());
    }
    paramOutputStream.write(59);
    
    paramOutputStream.flush();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    try
    {
      Toolkit localToolkit = Toolkit.getDefaultToolkit();
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream("gif89out.gif"));
      if (paramArrayOfString[0].toUpperCase().endsWith(".JPG"))
      {
        new Gif89Encoder(localToolkit.getImage(paramArrayOfString[0])).encode(localBufferedOutputStream);
      }
      else
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramArrayOfString[0]));
        Gif89Encoder localGif89Encoder = new Gif89Encoder();
        String str;
        while ((str = localBufferedReader.readLine()) != null) {
          localGif89Encoder.addFrame(localToolkit.getImage(str.trim()));
        }
        localGif89Encoder.setLoopCount(0);
        localGif89Encoder.encode(localBufferedOutputStream);
        
        localBufferedReader.close();
      }
      localBufferedOutputStream.close();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    finally
    {
      System.exit(0);
    }
  }
  
  private void accommodateFrame(Gif89Frame paramGif89Frame)
    throws IOException
  {
    this.dispDim.width = Math.max(this.dispDim.width, paramGif89Frame.getWidth());
    this.dispDim.height = Math.max(this.dispDim.height, paramGif89Frame.getHeight());
    this.colorTable.processPixels(paramGif89Frame);
  }
  
  private void writeLogicalScreenDescriptor(OutputStream paramOutputStream)
    throws IOException
  {
    Gif89Put.leShort(this.dispDim.width, paramOutputStream);
    Gif89Put.leShort(this.dispDim.height, paramOutputStream);
    





    paramOutputStream.write(0xF0 | this.colorTable.getDepth() - 1);
    

    paramOutputStream.write(this.bgIndex);
    









    paramOutputStream.write(0);
  }
  
  private void writeNetscapeExtension(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(33);
    paramOutputStream.write(255);
    
    paramOutputStream.write(11);
    Gif89Put.ascii("NETSCAPE2.0", paramOutputStream);
    
    paramOutputStream.write(3);
    paramOutputStream.write(1);
    

    Gif89Put.leShort(this.loopCount > 1 ? this.loopCount - 1 : 0, paramOutputStream);
    
    paramOutputStream.write(0);
  }
  
  private void writeCommentExtension(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(33);
    paramOutputStream.write(254);
    
    int i = this.theComments.length() % 255;
    int j = this.theComments.length() / 255;
    int k = j + (i > 0 ? 1 : 0);
    int m = 0;
    for (int n = 0; n < k; n++)
    {
      int i1 = n < j ? 255 : i;
      
      paramOutputStream.write(i1);
      Gif89Put.ascii(this.theComments.substring(m, m + i1), paramOutputStream);
      m += i1;
    }
    paramOutputStream.write(0);
  }
  
  private boolean isOk(int paramInt)
  {
    return (paramInt >= 0) && (paramInt < this.vFrames.size());
  }
}
