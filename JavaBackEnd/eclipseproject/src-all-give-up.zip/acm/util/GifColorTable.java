package acm.util;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;

class GifColorTable
{
  private int[] theColors = new int[256];
  private int colorDepth;
  private int transparentIndex = -1;
  private int ciCount = 0;
  private ReverseColorMap ciLookup;
  
  GifColorTable()
  {
    this.ciLookup = new ReverseColorMap();
  }
  
  GifColorTable(Color[] paramArrayOfColor)
  {
    int i = Math.min(this.theColors.length, paramArrayOfColor.length);
    for (int j = 0; j < i; j++) {
      this.theColors[j] = paramArrayOfColor[j].getRGB();
    }
  }
  
  int getDepth()
  {
    return this.colorDepth;
  }
  
  int getTransparent()
  {
    return this.transparentIndex;
  }
  
  void setTransparent(int paramInt)
  {
    this.transparentIndex = paramInt;
  }
  
  void processPixels(Gif89Frame paramGif89Frame)
    throws IOException
  {
    if ((paramGif89Frame instanceof DirectGif89Frame)) {
      filterPixels((DirectGif89Frame)paramGif89Frame);
    } else {
      trackPixelUsage((IndexGif89Frame)paramGif89Frame);
    }
  }
  
  void closePixelProcessing()
  {
    this.colorDepth = computeColorDepth(this.ciCount);
  }
  
  void encode(OutputStream paramOutputStream)
    throws IOException
  {
    int i = 1 << this.colorDepth;
    for (int j = 0; j < i; j++)
    {
      paramOutputStream.write(this.theColors[j] >> 16 & 0xFF);
      paramOutputStream.write(this.theColors[j] >> 8 & 0xFF);
      paramOutputStream.write(this.theColors[j] & 0xFF);
    }
  }
  
  private void filterPixels(DirectGif89Frame paramDirectGif89Frame)
    throws IOException
  {
    if (this.ciLookup == null) {
      throw new IOException("RGB frames require palette autodetection");
    }
    int[] arrayOfInt = (int[])paramDirectGif89Frame.getPixelSource();
    byte[] arrayOfByte = paramDirectGif89Frame.getPixelSink();
    int i = arrayOfInt.length;
    for (int j = 0; j < i; j++)
    {
      int k = arrayOfInt[j];
      if (k >>> 24 < 128) {
        if (this.transparentIndex == -1)
        {
          this.transparentIndex = this.ciCount;
        }
        else if (k != this.theColors[this.transparentIndex])
        {
          arrayOfByte[j] = ((byte)this.transparentIndex);
          continue;
        }
      }
      int m = this.ciLookup.getPaletteIndex(k & 0xFFFFFF);
      if (m == -1)
      {
        if (this.ciCount == 256) {
          throw new IOException("can't encode as GIF (> 256 colors)");
        }
        this.theColors[this.ciCount] = k;
        

        this.ciLookup.put(k & 0xFFFFFF, this.ciCount);
        

        arrayOfByte[j] = ((byte)this.ciCount);
        

        this.ciCount += 1;
      }
      else
      {
        arrayOfByte[j] = ((byte)m);
      }
    }
  }
  
  private void trackPixelUsage(IndexGif89Frame paramIndexGif89Frame)
  {
    byte[] arrayOfByte = (byte[])paramIndexGif89Frame.getPixelSource();
    int i = arrayOfByte.length;
    for (int j = 0; j < i; j++) {
      if (arrayOfByte[j] >= this.ciCount) {
        this.ciCount = (arrayOfByte[j] + 1);
      }
    }
  }
  
  private int computeColorDepth(int paramInt)
  {
    if (paramInt <= 2) {
      return 1;
    }
    if (paramInt <= 4) {
      return 2;
    }
    if (paramInt <= 16) {
      return 4;
    }
    return 8;
  }
}
