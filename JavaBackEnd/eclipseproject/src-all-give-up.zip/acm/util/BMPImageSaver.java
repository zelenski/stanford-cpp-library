package acm.util;

class BMPImageSaver
  extends ImageSaver
{
  public BMPImageSaver()
  {
    super("BMP", 1);
  }
}
