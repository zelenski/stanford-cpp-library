package acm.util;

import java.io.File;
import java.util.StringTokenizer;
import javax.swing.filechooser.FileFilter;

public class FileChooserFilter
  extends FileFilter
{
  private String filenamePattern;
  private String filenameDescription;
  private String dir;
  
  public FileChooserFilter(String paramString)
  {
    this(paramString, (paramString.isEmpty() ? "All" : paramString) + " files");
  }
  
  public FileChooserFilter(String paramString1, String paramString2)
  {
    this.filenameDescription = paramString2;
    int i = Math.max(paramString1.lastIndexOf("/"), paramString1.lastIndexOf('\\'));
    this.filenamePattern = paramString1.substring(i + 1);
    this.dir = (i == -1 ? "" : paramString1.substring(0, i));
    if (this.dir.isEmpty()) {
      this.dir = System.getProperty("user.dir");
    } else if (!this.dir.startsWith("/")) {
      this.dir = (System.getProperty("user.dir") + "/" + this.dir);
    }
  }
  
  public String getDirectory()
  {
    return this.dir;
  }
  
  public String getPattern()
  {
    return this.filenamePattern;
  }
  
  public String getDescription()
  {
    return this.filenameDescription;
  }
  
  public boolean accept(File paramFile)
  {
    if ((paramFile.isDirectory()) || (this.filenamePattern.isEmpty())) {
      return true;
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(this.filenamePattern, ";");
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      if ((str.length() > 0) && (JTFTools.matchFilenamePattern(paramFile.getName(), str))) {
        return true;
      }
    }
    return false;
  }
}
