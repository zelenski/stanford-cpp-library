package acm.util;

class JPGImageSaver
  extends JPEGImageSaver
{}
