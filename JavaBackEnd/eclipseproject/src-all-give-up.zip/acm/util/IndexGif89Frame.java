package acm.util;

class IndexGif89Frame
  extends Gif89Frame
{
  public IndexGif89Frame(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    this.theWidth = paramInt1;
    this.theHeight = paramInt2;
    this.ciPixels = new byte[this.theWidth * this.theHeight];
    System.arraycopy(paramArrayOfByte, 0, this.ciPixels, 0, this.ciPixels.length);
  }
  
  Object getPixelSource()
  {
    return this.ciPixels;
  }
}
