package acm.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

class HexByteOutputStream
  extends OutputStream
{
  private static final int COLUMNS = 76;
  private int columnCount;
  private PrintStream out;
  
  public HexByteOutputStream(PrintStream paramPrintStream)
  {
    this.out = paramPrintStream;
    this.out.flush();
    this.columnCount = 0;
  }
  
  public void write(int paramInt)
    throws IOException
  {
    String str = Integer.toHexString(256 + (paramInt & 0xFF)).toUpperCase();
    this.out.write(str.charAt(1));
    this.out.write(str.charAt(2));
    this.columnCount += 2;
    if (this.columnCount >= 76)
    {
      this.columnCount = 0;
      this.out.println();
    }
  }
  
  public void flush()
  {
    this.out.flush();
  }
  
  public void close()
  {
    this.out.close();
  }
}
