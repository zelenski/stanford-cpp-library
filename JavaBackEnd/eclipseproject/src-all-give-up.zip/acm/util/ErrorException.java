package acm.util;

public class ErrorException
  extends RuntimeException
{
  public ErrorException(String paramString)
  {
    super(paramString);
  }
  
  public ErrorException(Exception paramException)
  {
    super(paramException.getClass().getName() + ": " + paramException.getMessage());
  }
}
