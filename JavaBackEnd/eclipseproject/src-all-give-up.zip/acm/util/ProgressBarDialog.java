package acm.util;

import acm.gui.TableLayout;
import acm.program.Program;
import java.awt.Component;
import java.awt.Container;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JProgressBar;

class ProgressBarDialog
  extends JDialog
  implements ActionListener
{
  private static final int DIALOG_WIDTH = 250;
  private static final int DIALOG_HEIGHT = 90;
  private static final int PROGRESS_BAR_HEIGHT = 25;
  private JProgressBar progressBar;
  
  public ProgressBarDialog(Program paramProgram)
  {
    super(JTFTools.getEnclosingFrame(paramProgram), "Progress", false);
    Container localContainer = getContentPane();
    localContainer.setLayout(new TableLayout(2, 1));
    this.progressBar = new JProgressBar();
    localContainer.add(this.progressBar, "weightx=1 left=5 right=5 height=25");
    JButton localJButton = new JButton("Cancel");
    localJButton.addActionListener(this);
    localContainer.add(localJButton, "top=10 fill=NONE");
    Rectangle localRectangle = paramProgram.getBounds();
    int i = localRectangle.x + (localRectangle.width - 250) / 2;
    int j = localRectangle.y + (localRectangle.height - 90) / 2;
    setBounds(i, j, 250, 90);
  }
  
  public JProgressBar getProgressBar()
  {
    return this.progressBar;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.progressBar.setString("Cancel");
    setVisible(false);
  }
  
  public static boolean hasBeenCancelled(JProgressBar paramJProgressBar)
  {
    if (paramJProgressBar == null) {
      return false;
    }
    String str = paramJProgressBar.getString();
    return (str != null) && (str.equals("Cancel"));
  }
  
  public static void popup(JProgressBar paramJProgressBar)
  {
    Object localObject = paramJProgressBar;
    while (localObject != null)
    {
      if ((localObject instanceof ProgressBarDialog))
      {
        ((Component)localObject).setVisible(true);
        ((Component)localObject).repaint();
        return;
      }
      localObject = ((Component)localObject).getParent();
    }
  }
  
  public static void dismiss(JProgressBar paramJProgressBar)
  {
    Object localObject = paramJProgressBar;
    while (localObject != null)
    {
      if ((localObject instanceof ProgressBarDialog))
      {
        ((Component)localObject).setVisible(false);
        return;
      }
      localObject = ((Component)localObject).getParent();
    }
  }
}
