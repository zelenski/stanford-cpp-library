package acm.util;

class PNGImageSaver
  extends ImageSaver
{
  public PNGImageSaver()
  {
    super("PNG", 2);
  }
}
