package acm.util;

class ReverseColorMap
{
  private static final int HCAPACITY = 2053;
  
  private static class ColorRecord
  {
    int rgb;
    int ipalette;
    
    ColorRecord(int paramInt1, int paramInt2)
    {
      this.rgb = paramInt1;
      this.ipalette = paramInt2;
    }
  }
  
  private ColorRecord[] hTable = new ColorRecord[2053];
  
  int getPaletteIndex(int paramInt)
  {
    int i = paramInt % this.hTable.length;
    ColorRecord localColorRecord;
    for (; ((localColorRecord = this.hTable[i]) != null) && (localColorRecord.rgb != paramInt); i %= this.hTable.length) {
      i++;
    }
    if (localColorRecord != null) {
      return localColorRecord.ipalette;
    }
    return -1;
  }
  
  void put(int paramInt1, int paramInt2)
  {
    int i = paramInt1 % this.hTable.length;
    for (; this.hTable[i] != null; i %= this.hTable.length) {
      i++;
    }
    this.hTable[i] = new ColorRecord(paramInt1, paramInt2);
  }
}
