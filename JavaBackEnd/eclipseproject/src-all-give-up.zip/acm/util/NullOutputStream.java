package acm.util;

import java.io.OutputStream;

class NullOutputStream
  extends OutputStream
{
  public void write(int paramInt) {}
  
  public void write(byte[] paramArrayOfByte) {}
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {}
  
  public void flush() {}
  
  public void close() {}
}
