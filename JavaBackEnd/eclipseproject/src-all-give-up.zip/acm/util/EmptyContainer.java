package acm.util;

import java.awt.Container;
import java.awt.Graphics;

class EmptyContainer
  extends Container
{
  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }
}
