package acm.util;

class PICImageSaver
  extends PICTImageSaver
{}
