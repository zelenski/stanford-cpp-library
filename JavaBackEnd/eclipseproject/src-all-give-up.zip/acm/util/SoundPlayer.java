package acm.util;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.FloatControl.Type;
import javax.sound.sampled.SourceDataLine;

class SoundPlayer
  implements Runnable
{
  private static final int PADDING = 400;
  private static final int BYTES_PER_SAMPLE = 2;
  private static final int MAX_BUFFER_SIZE = 4096;
  private static final double EPSILON = 1.0E-006D;
  private SoundClip soundClip;
  private Thread thread;
  private boolean looping;
  private double oldVolume;
  
  public SoundPlayer(SoundClip paramSoundClip)
  {
    this.soundClip = paramSoundClip;
    this.oldVolume = 1.0D;
  }
  
  public void play()
  {
    if (this.thread != null) {
      return;
    }
    this.looping = false;
    this.thread = new Thread(this);
    this.thread.start();
  }
  
  public void loop()
  {
    if (this.thread != null) {
      return;
    }
    this.looping = true;
    this.thread = new Thread(this);
    this.thread.start();
  }
  
  public void stop()
  {
    if (this.thread == null) {
      return;
    }
    this.looping = false;
    this.thread = null;
  }
  
  public void run()
  {
    byte[] arrayOfByte = this.soundClip.getData();
    int i = this.soundClip.getChannelCount();
    int j = this.soundClip.getFrameIndex() * i * 2;
    int k = this.soundClip.getFrameCount() * i * 2;
    SourceDataLine localSourceDataLine = openSourceDataLine(Math.min(4096, k));
    localSourceDataLine.start();
    while (this.thread != null)
    {
      int m = k - j;
      while ((this.thread != null) && (m > 0))
      {
        setLineVolume(localSourceDataLine, this.soundClip.getVolume());
        int n = Math.min(4096, m);
        int i1 = localSourceDataLine.write(arrayOfByte, j, n);
        j += i1;
        m -= i1;
      }
      if (!this.looping) {
        break;
      }
      j = 0;
    }
    if (this.thread == null) {
      this.soundClip.setFrameIndex(j / i / 2);
    }
    arrayOfByte = new byte[400];
    localSourceDataLine.write(arrayOfByte, 0, arrayOfByte.length);
    localSourceDataLine.drain();
    localSourceDataLine.stop();
    localSourceDataLine.close();
    this.thread = null;
  }
  
  private SourceDataLine openSourceDataLine(int paramInt)
  {
    try
    {
      AudioFormat localAudioFormat = this.soundClip.getFormat();
      Class localClass = Class.forName("javax.sound.sampled.SourceDataLine");
      DataLine.Info localInfo = new DataLine.Info(localClass, localAudioFormat);
      if (!AudioSystem.isLineSupported(localInfo)) {
        throw new ErrorException("SoundClip: Unsupported data line format");
      }
      SourceDataLine localSourceDataLine = (SourceDataLine)AudioSystem.getLine(localInfo);
      localSourceDataLine.open(localAudioFormat, paramInt);
      return localSourceDataLine;
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  private void setLineVolume(SourceDataLine paramSourceDataLine, double paramDouble)
  {
    if (this.oldVolume == paramDouble) {
      return;
    }
    this.oldVolume = paramDouble;
    FloatControl localFloatControl;
    if (paramSourceDataLine.isControlSupported(FloatControl.Type.VOLUME))
    {
      localFloatControl = (FloatControl)paramSourceDataLine.getControl(FloatControl.Type.VOLUME);
      localFloatControl.setValue((float)paramDouble);
    }
    else if (paramSourceDataLine.isControlSupported(FloatControl.Type.MASTER_GAIN))
    {
      localFloatControl = (FloatControl)paramSourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
      double d = 20.0D * Math.log(Math.max(paramDouble, 1.0E-006D)) / Math.log(10.0D);
      localFloatControl.setValue((float)d);
    }
  }
}
