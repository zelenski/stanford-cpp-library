package acm.util;

import acm.io.IOConsole;
import acm.io.IOModel;
import acm.program.Program;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

class ThreadedMenuAction
  implements Runnable
{
  private Program targetProgram;
  private String actionCommand;
  
  public ThreadedMenuAction(Program paramProgram, String paramString)
  {
    this.targetProgram = paramProgram;
    this.actionCommand = paramString;
  }
  
  public void run()
  {
    ProgressBarDialog localProgressBarDialog = new ProgressBarDialog(this.targetProgram);
    try
    {
      if (this.actionCommand.equals("Export Applet")) {
        JTFTools.exportApplet(this.targetProgram, localProgressBarDialog.getProgressBar());
      } else if (this.actionCommand.equals("Submit Project")) {
        JTFTools.submitProject(this.targetProgram, localProgressBarDialog.getProgressBar());
      }
    }
    catch (Exception localException)
    {
      localProgressBarDialog.setVisible(false);
      Object localObject = this.targetProgram.getDialog();
      if (localObject == null) {
        localObject = this.targetProgram.getConsole();
      }
      if (localObject == null) {
        localObject = IOConsole.SYSTEM_CONSOLE;
      }
      String str = localException.getMessage();
      if (!(localException instanceof ErrorException))
      {
        str = "" + localException;
        StringWriter localStringWriter = new StringWriter();
        PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
        localException.printStackTrace(localPrintWriter);
        localPrintWriter.close();
        try
        {
          BufferedReader localBufferedReader = new BufferedReader(new StringReader(localStringWriter.toString()));
          localBufferedReader.readLine();
          str = str + localBufferedReader.readLine();
        }
        catch (IOException localIOException) {}
      }
      ((IOModel)localObject).showErrorMessage(str);
    }
  }
}
