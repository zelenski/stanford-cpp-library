package acm.util;

import java.awt.Image;

class EPSImageSaver
  extends ImageSaver
{
  public void saveImage(Image paramImage)
  {
    throw new ErrorException("saveImage: Not yet implemented");
  }
}
