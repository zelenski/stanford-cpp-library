package acm.util;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

class GIF89ImageSaver
  extends ImageSaver
{
  public void saveImage(Image paramImage)
  {
    try
    {
      Gif89Encoder localGif89Encoder = new Gif89Encoder(paramImage);
      localGif89Encoder.setTransparentIndex(0);
      localGif89Encoder.getFrameAt(0).setInterlaced(true);
      localGif89Encoder.encode(getOutputStream());
    }
    catch (IOException localIOException)
    {
      throw new ErrorException("saveImage: " + localIOException.getMessage());
    }
  }
  
  public void updateFileType(File paramFile)
  {
    Platform.setFileTypeAndCreator(paramFile, "GIFf", "prvw");
  }
}
