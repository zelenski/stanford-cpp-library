package acm.util;

public class CancelledException
  extends RuntimeException
{}
