package acm.io;

import acm.util.CancelledException;
import acm.util.ErrorException;
import acm.util.Platform;
import java.awt.Component;
import java.lang.reflect.Constructor;
import javax.swing.JPanel;

public class IODialog
  implements IOModel
{
  private boolean exceptionOnError;
  private boolean allowCancel;
  private DialogModel model;
  private Component myComponent;
  private IOConsole myConsole;
  private String outputLine;
  
  public IODialog()
  {
    this(null);
  }
  
  public IODialog(Component paramComponent)
  {
    this.myComponent = paramComponent;
    this.model = createModel();
    this.outputLine = "";
    this.exceptionOnError = false;
    this.allowCancel = false;
  }
  
  public void print(String paramString)
  {
    this.outputLine += paramString;
  }
  
  public final void print(boolean paramBoolean)
  {
    print("" + paramBoolean);
  }
  
  public final void print(char paramChar)
  {
    print("" + paramChar);
  }
  
  public final void print(double paramDouble)
  {
    print("" + paramDouble);
  }
  
  public final void print(float paramFloat)
  {
    print("" + paramFloat);
  }
  
  public final void print(int paramInt)
  {
    print("" + paramInt);
  }
  
  public final void print(long paramLong)
  {
    print("" + paramLong);
  }
  
  public final void print(Object paramObject)
  {
    print("" + paramObject);
  }
  
  public void println()
  {
    this.model.popupMessage(this.outputLine);
    this.outputLine = "";
  }
  
  public void println(String paramString)
  {
    print(paramString);
    println();
  }
  
  public final void println(boolean paramBoolean)
  {
    println("" + paramBoolean);
  }
  
  public final void println(char paramChar)
  {
    println("" + paramChar);
  }
  
  public final void println(double paramDouble)
  {
    println("" + paramDouble);
  }
  
  public final void println(float paramFloat)
  {
    println("" + paramFloat);
  }
  
  public final void println(int paramInt)
  {
    println("" + paramInt);
  }
  
  public final void println(long paramLong)
  {
    println("" + paramLong);
  }
  
  public final void println(Object paramObject)
  {
    println("" + paramObject);
  }
  
  public void showErrorMessage(String paramString)
  {
    this.model.popupErrorMessage(paramString);
  }
  
  public final String readLine()
  {
    return readLine(null);
  }
  
  public String readLine(String paramString)
  {
    if ((this.myConsole != null) && (this.myConsole.getInputScript() != null)) {
      return this.myConsole.readLine(paramString);
    }
    paramString = this.outputLine + paramString;
    this.outputLine = "";
    String str;
    while ((str = this.model.popupLineInputDialog(paramString, this.allowCancel)) == null) {
      if (this.allowCancel) {
        throw new CancelledException();
      }
    }
    return str;
  }
  
  public final int readInt()
  {
    return readInt(null, -2147483648, 2147483647);
  }
  
  public final int readInt(int paramInt1, int paramInt2)
  {
    return readInt(null, paramInt1, paramInt2);
  }
  
  public final int readInt(String paramString)
  {
    return readInt(paramString, -2147483648, 2147483647);
  }
  
  public int readInt(String paramString, int paramInt1, int paramInt2)
  {
    for (;;)
    {
      String str = readLine(paramString);
      try
      {
        int i = Integer.parseInt(str);
        if ((i < paramInt1) || (i > paramInt2)) {
          signalError("Value is outside the range [" + paramInt1 + ":" + paramInt2 + "]");
        }
        return i;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        signalError("Illegal integer format");
      }
    }
  }
  
  public final double readDouble()
  {
    return readDouble(null, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public final double readDouble(double paramDouble1, double paramDouble2)
  {
    return readDouble(null, paramDouble1, paramDouble2);
  }
  
  public final double readDouble(String paramString)
  {
    return readDouble(paramString, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public double readDouble(String paramString, double paramDouble1, double paramDouble2)
  {
    for (;;)
    {
      String str = readLine(paramString);
      try
      {
        double d = Double.valueOf(str).doubleValue();
        if ((d < paramDouble1) || (d > paramDouble2)) {
          signalError("Value is outside the range [" + paramDouble1 + ":" + paramDouble2 + "]");
        }
        return d;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        signalError("Illegal numeric format");
      }
    }
  }
  
  public final boolean readBoolean()
  {
    return readBoolean(null);
  }
  
  public final boolean readBoolean(String paramString)
  {
    return readBoolean(paramString, "true", "false");
  }
  
  public boolean readBoolean(String paramString1, String paramString2, String paramString3)
  {
    if ((this.myConsole != null) && (this.myConsole.getInputScript() != null)) {
      return this.myConsole.readBoolean(paramString1, paramString2, paramString3);
    }
    paramString1 = this.outputLine + paramString1;
    this.outputLine = "";
    Boolean localBoolean;
    while ((localBoolean = this.model.popupBooleanInputDialog(paramString1, paramString2, paramString3, this.allowCancel)) == null) {
      if (this.allowCancel) {
        throw new CancelledException();
      }
    }
    return localBoolean.booleanValue();
  }
  
  public void setExceptionOnError(boolean paramBoolean)
  {
    this.exceptionOnError = paramBoolean;
  }
  
  public boolean getExceptionOnError()
  {
    return this.exceptionOnError;
  }
  
  public void setAllowCancel(boolean paramBoolean)
  {
    this.allowCancel = paramBoolean;
  }
  
  public boolean getAllowCancel()
  {
    return this.allowCancel;
  }
  
  public void setAssociatedConsole(IOConsole paramIOConsole)
  {
    this.myConsole = paramIOConsole;
  }
  
  public IOConsole getAssociatedConsole()
  {
    return this.myConsole;
  }
  
  protected DialogModel createModel()
  {
    String str = new JPanel().getClass().getName();
    if ((str.startsWith("javax.swing.")) && (Platform.isSwingAvailable())) {
      try
      {
        Class localClass = Class.forName("acm.io.SwingDialogModel");
        Class[] arrayOfClass = { Class.forName("java.awt.Component") };
        Object[] arrayOfObject = { this.myComponent };
        Constructor localConstructor = localClass.getConstructor(arrayOfClass);
        return (DialogModel)localConstructor.newInstance(arrayOfObject);
      }
      catch (Exception localException)
      {
        return new AWTDialogModel(this.myComponent);
      }
    }
    return new AWTDialogModel(this.myComponent);
  }
  
  private void signalError(String paramString)
  {
    if (this.exceptionOnError) {
      throw new ErrorException(paramString);
    }
    this.model.popupErrorMessage(paramString);
  }
}
