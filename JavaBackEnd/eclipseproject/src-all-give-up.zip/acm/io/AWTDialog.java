package acm.io;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

abstract class AWTDialog
  extends Dialog
  implements ActionListener
{
  public static final int WIDTH = 260;
  public static final int HEIGHT = 115;
  private AWTMessageCanvas messageArea;
  
  public AWTDialog(Frame paramFrame, String paramString, Image paramImage, boolean paramBoolean)
  {
    super(paramFrame, paramString, true);
    setLayout(new BorderLayout());
    Panel localPanel1 = new Panel();
    Panel localPanel2 = new Panel();
    Panel localPanel3 = new Panel();
    Panel localPanel4 = new Panel();
    localPanel1.setLayout(new BorderLayout());
    localPanel2.setLayout(new FlowLayout());
    localPanel3.setLayout(new BorderLayout());
    localPanel4.setLayout(new BorderLayout());
    localPanel4.add(new Label(" "));
    this.messageArea = new AWTMessageCanvas();
    localPanel3.add(this.messageArea, "Center");
    initButtonPanel(localPanel2, paramBoolean);
    initDataPanel(localPanel3);
    localPanel1.add(new AWTIconCanvas(paramImage), "West");
    localPanel1.add(localPanel3, "Center");
    add(localPanel1, "Center");
    add(localPanel2, "South");
    add(localPanel4, "East");
    Rectangle localRectangle = paramFrame.getBounds();
    int i = localRectangle.x + localRectangle.width / 2;
    int j = localRectangle.y + localRectangle.height / 2;
    setBounds(i - 130, j - 57, 260, 115);
    validate();
  }
  
  public abstract void initButtonPanel(Panel paramPanel, boolean paramBoolean);
  
  public abstract void initDataPanel(Panel paramPanel);
  
  public abstract void actionPerformed(ActionEvent paramActionEvent);
  
  public void setMessage(String paramString)
  {
    this.messageArea.setMessage(paramString);
  }
}
