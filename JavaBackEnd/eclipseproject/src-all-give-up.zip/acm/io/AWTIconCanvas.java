package acm.io;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

class AWTIconCanvas
  extends Canvas
{
  private Image myIcon;
  
  public AWTIconCanvas(Image paramImage)
  {
    this.myIcon = paramImage;
  }
  
  public Dimension getMinimumSize()
  {
    return new Dimension(48, 48);
  }
  
  public Dimension getPreferredSize()
  {
    return getMinimumSize();
  }
  
  public void paint(Graphics paramGraphics)
  {
    paramGraphics.drawImage(this.myIcon, 8, 8, this);
  }
}
