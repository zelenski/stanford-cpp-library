package acm.io;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;

class AWTMessageDialog
  extends AWTDialog
{
  private Button okButton;
  
  public AWTMessageDialog(Frame paramFrame, String paramString1, Image paramImage, String paramString2)
  {
    super(paramFrame, paramString1, paramImage, false);
    setMessage(paramString2);
  }
  
  public void initButtonPanel(Panel paramPanel, boolean paramBoolean)
  {
    this.okButton = new Button("OK");
    this.okButton.addActionListener(this);
    paramPanel.add(this.okButton);
  }
  
  public void initDataPanel(Panel paramPanel) {}
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.okButton) {
      setVisible(false);
    }
  }
}
