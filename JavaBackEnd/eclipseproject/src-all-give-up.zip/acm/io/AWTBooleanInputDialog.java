package acm.io;

import java.awt.Button;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;

class AWTBooleanInputDialog
  extends AWTDialog
{
  private Button trueButton;
  private Button falseButton;
  private Button cancelButton;
  private Boolean input;
  
  public AWTBooleanInputDialog(Frame paramFrame, String paramString1, Image paramImage, String paramString2, String paramString3, boolean paramBoolean)
  {
    super(paramFrame, "Input", paramImage, paramBoolean);
    setMessage(paramString1);
    this.trueButton.setLabel(paramString2);
    this.falseButton.setLabel(paramString3);
  }
  
  public Boolean getInput()
  {
    return this.input;
  }
  
  public void initButtonPanel(Panel paramPanel, boolean paramBoolean)
  {
    this.trueButton = new Button("True");
    this.trueButton.addActionListener(this);
    paramPanel.add(this.trueButton);
    this.falseButton = new Button("False");
    this.falseButton.addActionListener(this);
    paramPanel.add(this.falseButton);
    if (paramBoolean)
    {
      this.cancelButton = new Button("Cancel");
      this.cancelButton.addActionListener(this);
      paramPanel.add(this.cancelButton);
    }
  }
  
  public void initDataPanel(Panel paramPanel) {}
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    Component localComponent = (Component)paramActionEvent.getSource();
    if (localComponent == this.trueButton)
    {
      this.input = Boolean.TRUE;
      setVisible(false);
    }
    else if (localComponent == this.falseButton)
    {
      this.input = Boolean.FALSE;
      setVisible(false);
    }
    else if (localComponent == this.cancelButton)
    {
      this.input = null;
      setVisible(false);
    }
  }
}
