package acm.io;

class CharacterQueue
{
  private String buffer;
  private boolean isWaiting;
  
  public CharacterQueue()
  {
    this.buffer = "";
  }
  
  public synchronized void enqueue(char paramChar)
  {
    this.buffer += paramChar;
    notifyAll();
  }
  
  public synchronized void enqueue(String paramString)
  {
    this.buffer += paramString;
    notifyAll();
  }
  
  public synchronized char dequeue()
  {
    while (this.buffer.length() == 0) {
      try
      {
        this.isWaiting = true;
        wait();
        this.isWaiting = false;
      }
      catch (InterruptedException localInterruptedException) {}
    }
    char c = this.buffer.charAt(0);
    this.buffer = this.buffer.substring(1);
    return c;
  }
  
  public synchronized void clear()
  {
    this.buffer = "";
    notifyAll();
  }
  
  public boolean isWaiting()
  {
    return this.isWaiting;
  }
}
