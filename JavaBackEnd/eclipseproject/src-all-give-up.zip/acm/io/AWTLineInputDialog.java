package acm.io;

import java.awt.Button;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;

class AWTLineInputDialog
  extends AWTDialog
{
  private Button cancelButton;
  private Button okButton;
  private TextField textLine;
  private String input;
  
  public AWTLineInputDialog(Frame paramFrame, String paramString, Image paramImage, boolean paramBoolean)
  {
    super(paramFrame, "Input", paramImage, paramBoolean);
    setMessage(paramString);
  }
  
  public String getInput()
  {
    return this.input;
  }
  
  public void setVisible(boolean paramBoolean)
  {
    super.setVisible(paramBoolean);
    if (paramBoolean) {
      this.textLine.requestFocus();
    }
  }
  
  public void initButtonPanel(Panel paramPanel, boolean paramBoolean)
  {
    this.okButton = new Button("OK");
    this.okButton.addActionListener(this);
    paramPanel.add(this.okButton);
    if (paramBoolean)
    {
      this.cancelButton = new Button("Cancel");
      this.cancelButton.addActionListener(this);
      paramPanel.add(this.cancelButton);
    }
  }
  
  public void initDataPanel(Panel paramPanel)
  {
    this.textLine = new TextField();
    this.textLine.addActionListener(this);
    paramPanel.add(this.textLine, "South");
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    Component localComponent = (Component)paramActionEvent.getSource();
    if ((localComponent == this.okButton) || (localComponent == this.textLine))
    {
      this.input = this.textLine.getText();
      setVisible(false);
    }
    else if (localComponent == this.cancelButton)
    {
      this.input = null;
      setVisible(false);
    }
  }
}
