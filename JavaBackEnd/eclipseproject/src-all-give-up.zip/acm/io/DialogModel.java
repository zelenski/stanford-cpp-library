package acm.io;

abstract interface DialogModel
{
  public abstract void popupMessage(String paramString);
  
  public abstract void popupErrorMessage(String paramString);
  
  public abstract String popupLineInputDialog(String paramString, boolean paramBoolean);
  
  public abstract Boolean popupBooleanInputDialog(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
}
