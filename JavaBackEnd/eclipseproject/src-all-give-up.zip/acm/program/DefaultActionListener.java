package acm.program;

import acm.io.IODialog;
import acm.util.ErrorException;
import java.awt.Button;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;

class DefaultActionListener
  implements ActionListener
{
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    Component localComponent = (Component)paramActionEvent.getSource();
    Program localProgram = findProgram(localComponent);
    Object localObject;
    if ((localProgram != null) && (countActionListeners(localComponent) > 1)) {
      try
      {
        Class[] arrayOfClass = { Class.forName("java.awt.event.ActionListener") };
        localObject = new Object[] { this };
        Method localMethod = localComponent.getClass().getMethod("removeActionListener", arrayOfClass);
        localMethod.invoke(localComponent, (Object[])localObject);
        return;
      }
      catch (Exception localException1)
      {
        throw new ErrorException(localException1);
      }
    }
    String str = "No ActionListener is attached";
    if ((localComponent instanceof Button)) {
      str = str + " to button " + ((Button)localComponent).getLabel();
    } else {
      try
      {
        localObject = localComponent.getClass().getMethod("getText", new Class[0]);
        str = str + " to button " + (String)((Method)localObject).invoke(localComponent, new Object[0]);
      }
      catch (Exception localException2)
      {
        throw new ErrorException(localException2);
      }
    }
    if (localProgram == null) {
      throw new ErrorException(str);
    }
    localProgram.getDialog().showErrorMessage(str);
  }
  
  protected static int countActionListeners(Component paramComponent)
  {
    try
    {
      Method localMethod = paramComponent.getClass().getMethod("getActionListeners", new Class[0]);
      ActionListener[] arrayOfActionListener = (ActionListener[])localMethod.invoke(paramComponent, new Object[0]);
      return arrayOfActionListener.length;
    }
    catch (Exception localException) {}
    return -1;
  }
  
  private Program findProgram(Component paramComponent)
  {
    if ((paramComponent instanceof Program)) {
      return (Program)paramComponent;
    }
    if (paramComponent != null) {
      return findProgram(paramComponent.getParent());
    }
    return null;
  }
}
