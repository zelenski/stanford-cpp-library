package acm.program;

import acm.gui.TableLayout;
import acm.io.IOConsole;
import acm.io.IODialog;
import acm.io.IOModel;
import acm.util.Animator;
import acm.util.ErrorException;
import acm.util.JTFTools;
import java.applet.AppletStub;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;

public abstract class Program
  extends JApplet
  implements IOModel, Runnable, MouseListener, MouseMotionListener, KeyListener, ActionListener
{
  public static final String NORTH = "North";
  public static final String SOUTH = "South";
  public static final String EAST = "East";
  public static final String WEST = "West";
  public static final String CENTER = "Center";
  private static final int DEFAULT_X = 16;
  private static final int DEFAULT_Y = 40;
  private static final int DEFAULT_WIDTH = 754;
  private static final int DEFAULT_HEIGHT = 492;
  private static final int PRINT_MARGIN = 36;
  private ArrayList<Object> finalizers;
  private HashMap<String, String> parameterTable;
  private JFrame programFrame;
  private AppletStub appletStub;
  private String myTitle;
  private ProgramMenuBar myMenuBar;
  private Component northBorder;
  private Component southBorder;
  private Component eastBorder;
  private Component westBorder;
  private JPanel northPanel;
  private JPanel southPanel;
  private JPanel eastPanel;
  private JPanel westPanel;
  private JPanel centerPanel;
  private IOConsole myConsole;
  private IODialog myDialog;
  private IOModel inputModel;
  private IOModel outputModel;
  private Object startupObject;
  private AppletStarter appletStarter;
  private Rectangle programBounds;
  private boolean started;
  private boolean shown;
  private boolean initFinished;
  private boolean appletMode;
  
  protected Program()
  {
    JTFTools.registerApplet(this);
    this.appletMode = checkForAppletMode();
    this.shown = false;
    this.parameterTable = null;
    this.finalizers = new ArrayList();
    this.myTitle = getClass().getName();
    this.myTitle = this.myTitle.substring(this.myTitle.lastIndexOf(".") + 1);
    this.appletStub = new ProgramAppletStub(this);
    setAppletStub(this.appletStub);
    initContentPane(getContentPane());
    setVisible(false);
    setConsole(createConsole());
    this.myDialog = createDialogIO();
    this.myDialog.setAssociatedConsole(this.myConsole);
    this.myMenuBar = createMenuBar();
    this.myConsole.setMenuBar(this.myMenuBar);
  }
  
  public void run() {}
  
  public void init() {}
  
  public void print(String paramString)
  {
    getOutputModel().print(paramString);
  }
  
  public final void print(boolean paramBoolean)
  {
    print("" + paramBoolean);
  }
  
  public final void print(char paramChar)
  {
    print("" + paramChar);
  }
  
  public final void print(double paramDouble)
  {
    print("" + paramDouble);
  }
  
  public final void print(float paramFloat)
  {
    print("" + paramFloat);
  }
  
  public final void print(int paramInt)
  {
    print("" + paramInt);
  }
  
  public final void print(long paramLong)
  {
    print("" + paramLong);
  }
  
  public final void print(Object paramObject)
  {
    print("" + paramObject);
  }
  
  public void println()
  {
    getOutputModel().println();
  }
  
  public void println(String paramString)
  {
    getOutputModel().println(paramString);
  }
  
  public final void println(boolean paramBoolean)
  {
    println("" + paramBoolean);
  }
  
  public final void println(char paramChar)
  {
    println("" + paramChar);
  }
  
  public final void println(double paramDouble)
  {
    println("" + paramDouble);
  }
  
  public final void println(float paramFloat)
  {
    println("" + paramFloat);
  }
  
  public final void println(int paramInt)
  {
    println("" + paramInt);
  }
  
  public final void println(long paramLong)
  {
    println("" + paramLong);
  }
  
  public final void println(Object paramObject)
  {
    println("" + paramObject);
  }
  
  public void showErrorMessage(String paramString)
  {
    getOutputModel().showErrorMessage(paramString);
  }
  
  public final String readLine()
  {
    return readLine(null);
  }
  
  public String readLine(String paramString)
  {
    return getInputModel().readLine(paramString);
  }
  
  public final int readInt()
  {
    return readInt(null, -2147483648, 2147483647);
  }
  
  public final int readInt(int paramInt1, int paramInt2)
  {
    return readInt(null, paramInt1, paramInt2);
  }
  
  public final int readInt(String paramString)
  {
    return readInt(paramString, -2147483648, 2147483647);
  }
  
  public int readInt(String paramString, int paramInt1, int paramInt2)
  {
    return getInputModel().readInt(paramString, paramInt1, paramInt2);
  }
  
  public final double readDouble()
  {
    return readDouble(null, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public final double readDouble(double paramDouble1, double paramDouble2)
  {
    return readDouble(null, paramDouble1, paramDouble2);
  }
  
  public final double readDouble(String paramString)
  {
    return readDouble(paramString, (-1.0D / 0.0D), (1.0D / 0.0D));
  }
  
  public double readDouble(String paramString, double paramDouble1, double paramDouble2)
  {
    return getInputModel().readDouble(paramString, paramDouble1, paramDouble2);
  }
  
  public final boolean readBoolean()
  {
    return readBoolean(null);
  }
  
  public final boolean readBoolean(String paramString)
  {
    return readBoolean(paramString, "true", "false");
  }
  
  public boolean readBoolean(String paramString1, String paramString2, String paramString3)
  {
    return getInputModel().readBoolean(paramString1, paramString2, paramString3);
  }
  
  public boolean isAppletMode()
  {
    return this.appletMode;
  }
  
  public void setConsole(IOConsole paramIOConsole)
  {
    this.myConsole = paramIOConsole;
  }
  
  public IOConsole getConsole()
  {
    return this.myConsole;
  }
  
  public void setDialog(IODialog paramIODialog)
  {
    this.myDialog = paramIODialog;
  }
  
  public IODialog getDialog()
  {
    return this.myDialog;
  }
  
  public void setInputModel(IOModel paramIOModel)
  {
    this.inputModel = paramIOModel;
  }
  
  public void setOutputModel(IOModel paramIOModel)
  {
    this.outputModel = paramIOModel;
  }
  
  public IOModel getInputModel()
  {
    return this.inputModel == null ? this.myConsole : this.inputModel;
  }
  
  public IOModel getOutputModel()
  {
    return this.outputModel == null ? this.myConsole : this.outputModel;
  }
  
  public BufferedReader getReader()
  {
    return getConsole().getReader();
  }
  
  public PrintWriter getWriter()
  {
    return getConsole().getWriter();
  }
  
  public JPanel getRegionPanel(String paramString)
  {
    if (paramString.equals("North")) {
      return this.northPanel;
    }
    if (paramString.equals("South")) {
      return this.southPanel;
    }
    if (paramString.equals("West")) {
      return this.westPanel;
    }
    if (paramString.equals("East")) {
      return this.eastPanel;
    }
    if (paramString.equals("Center")) {
      return this.centerPanel;
    }
    throw new ErrorException("getRegionPanel: Illegal region " + paramString);
  }
  
  public void add(Component paramComponent, String paramString, Object paramObject)
  {
    if (paramString.equals("North")) {
      this.northPanel.add(paramComponent, paramObject);
    } else if (paramString.equals("South")) {
      this.southPanel.add(paramComponent, paramObject);
    } else if (paramString.equals("West")) {
      this.westPanel.add(paramComponent, paramObject);
    } else if (paramString.equals("East")) {
      this.eastPanel.add(paramComponent, paramObject);
    } else if (paramString.equals("Center")) {
      this.centerPanel.add(paramComponent, paramObject);
    } else {
      throw new ErrorException("add: Illegal region " + paramString);
    }
  }
  
  public void addActionListeners()
  {
    addActionListeners(this);
  }
  
  public void addActionListeners(ActionListener paramActionListener)
  {
    addActionListeners(getContentPane(), paramActionListener);
  }
  
  public void setTitle(String paramString)
  {
    this.myTitle = paramString;
    if (this.programFrame != null) {
      this.programFrame.setTitle(paramString);
    }
  }
  
  public String getTitle()
  {
    return this.myTitle;
  }
  
  public ProgramMenuBar getMenuBar()
  {
    return this.myMenuBar;
  }
  
  public void start(String[] paramArrayOfString)
  {
    if (this.parameterTable == null) {
      this.parameterTable = createParameterTable(paramArrayOfString);
    }
    if (getParent() == null) {
      initApplicationFrame();
    }
    validate();
    setVisible(true);
    if (this.programFrame != null)
    {
      this.programFrame.validate();
      int i = this.centerPanel.getComponentCount();
      i += this.northPanel.getComponentCount();
      i += this.southPanel.getComponentCount();
      i += this.westPanel.getComponentCount();
      i += this.eastPanel.getComponentCount();
      if (i > 0)
      {
        this.programFrame.setVisible(true);
        this.shown = true;
      }
    }
    this.started = true;
    init();
    if ((this.programFrame != null) && (this.myMenuBar != null))
    {
      this.myMenuBar.install(this.programFrame);
      circumventFrameSizeBug(this.programFrame, this.programBounds.getSize());
    }
    validate();
    startRun();
  }
  
  public void exit()
  {
    int i = this.finalizers.size();
    for (int j = 0; j < i; j++)
    {
      Object localObject = this.finalizers.get(j);
      try
      {
        Class localClass = localObject.getClass();
        Method localMethod = localClass.getMethod("exit", new Class[0]);
        localMethod.invoke(localObject, new Object[0]);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
    JTFTools.terminateAppletThreads(this);
    if (!this.appletMode) {
      System.exit(0);
    }
  }
  
  public void addExitHook(Object paramObject)
  {
    this.finalizers.add(paramObject);
  }
  
  public void setParameter(String paramString1, String paramString2)
  {
    if (this.parameterTable == null) {
      this.parameterTable = new HashMap();
    }
    this.parameterTable.put(paramString1.toLowerCase(), paramString2);
  }
  
  public Thread getMainThread()
  {
    return this.appletStarter == null ? null : this.appletStarter.getMainThread();
  }
  
  public void pause(double paramDouble)
  {
    JTFTools.pause(paramDouble);
  }
  
  public Dimension getCentralRegionSize()
  {
    if (this.centerPanel == null) {
      return super.getSize();
    }
    if (this.initFinished) {
      return this.centerPanel.getSize();
    }
    Dimension localDimension = this.programFrame == null ? super.getSize() : this.programFrame.getSize();
    Insets localInsets = this.programFrame == null ? super.getInsets() : this.programFrame.getInsets();
    localDimension.width -= this.westPanel.getPreferredSize().width + this.eastPanel.getPreferredSize().width;
    localDimension.width -= localInsets.left + localInsets.right;
    localDimension.height -= this.northPanel.getPreferredSize().height + this.southPanel.getPreferredSize().height;
    localDimension.height -= localInsets.top + localInsets.bottom;
    return localDimension;
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent) {}
  
  public void mousePressed(MouseEvent paramMouseEvent) {}
  
  public void mouseReleased(MouseEvent paramMouseEvent) {}
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public void mouseMoved(MouseEvent paramMouseEvent) {}
  
  public void mouseDragged(MouseEvent paramMouseEvent) {}
  
  public void keyTyped(KeyEvent paramKeyEvent) {}
  
  public void keyPressed(KeyEvent paramKeyEvent) {}
  
  public void keyReleased(KeyEvent paramKeyEvent) {}
  
  public void actionPerformed(ActionEvent paramActionEvent) {}
  
  protected JFrame createProgramFrame()
  {
    return new ProgramFrame(getTitle());
  }
  
  protected IOConsole createConsole()
  {
    return IOConsole.SYSTEM_CONSOLE;
  }
  
  protected IODialog createDialogIO()
  {
    return new IODialog(getContentPane());
  }
  
  protected ProgramMenuBar createMenuBar()
  {
    return new ProgramMenuBar(this);
  }
  
  public Dimension getPreferredSize()
  {
    return computeProgramBounds().getSize();
  }
  
  public int getWidth()
  {
    String str = getMyCaller();
    if ((str.startsWith("java.")) || (str.startsWith("javax."))) {
      return super.getWidth();
    }
    return getCentralRegionSize().width;
  }
  
  public int getHeight()
  {
    String str = getMyCaller();
    if ((str.startsWith("java.")) || (str.startsWith("javax."))) {
      return super.getHeight();
    }
    return getCentralRegionSize().height;
  }
  
  public String getParameter(String paramString)
  {
    String str = null;
    if (this.parameterTable != null) {
      str = (String)this.parameterTable.get(paramString.toLowerCase());
    }
    if (str != null) {
      return str;
    }
    return super.getParameter(paramString);
  }
  
  public void setLayout(LayoutManager paramLayoutManager)
  {
    if (isRootPaneCheckingEnabled()) {
      this.centerPanel.setLayout(paramLayoutManager);
    } else {
      super.setLayout(paramLayoutManager);
    }
  }
  
  public LayoutManager getLayout()
  {
    if (isRootPaneCheckingEnabled()) {
      return this.centerPanel.getLayout();
    }
    return super.getLayout();
  }
  
  public void setBackground(Color paramColor)
  {
    if (isRootPaneCheckingEnabled()) {
      this.centerPanel.setBackground(paramColor);
    }
    super.setBackground(paramColor);
  }
  
  protected void addImpl(Component paramComponent, Object paramObject, int paramInt)
  {
    if (isRootPaneCheckingEnabled())
    {
      if (paramObject == null) {
        this.centerPanel.add(paramComponent, paramInt);
      } else if (paramObject.equals("North")) {
        this.northPanel.add(paramComponent, paramInt);
      } else if (paramObject.equals("South")) {
        this.southPanel.add(paramComponent, paramInt);
      } else if (paramObject.equals("West")) {
        this.westPanel.add(paramComponent, paramInt);
      } else if (paramObject.equals("East")) {
        this.eastPanel.add(paramComponent, paramInt);
      } else if (paramObject.equals("Center")) {
        this.centerPanel.add(paramComponent, paramInt);
      } else {
        this.centerPanel.add(paramComponent, paramObject, paramInt);
      }
      if ((!this.shown) && (this.programFrame != null))
      {
        this.programFrame.setVisible(true);
        this.shown = true;
      }
    }
    else
    {
      super.addImpl(paramComponent, paramObject, paramInt);
    }
  }
  
  public void remove(int paramInt)
  {
    if (isRootPaneCheckingEnabled()) {
      this.centerPanel.remove(paramInt);
    } else {
      super.remove(paramInt);
    }
  }
  
  public void remove(Component paramComponent)
  {
    if (isRootPaneCheckingEnabled()) {
      this.centerPanel.remove(paramComponent);
    } else {
      super.remove(paramComponent);
    }
  }
  
  public void removeAll()
  {
    if (isRootPaneCheckingEnabled()) {
      this.centerPanel.removeAll();
    } else {
      super.removeAll();
    }
  }
  
  public void validate()
  {
    if (isRootPaneCheckingEnabled()) {
      getContentPane().validate();
    }
    super.validate();
  }
  
  public void repaint()
  {
    if (isRootPaneCheckingEnabled()) {
      getContentPane().repaint();
    }
    super.repaint();
  }
  
  public final void start()
  {
    this.appletMode = (getParent() != null);
    if (this.appletMode)
    {
      if (!this.started)
      {
        this.started = true;
        validate();
        setVisible(true);
        this.appletStarter = new AppletStarter(this);
        this.appletStarter.start();
      }
    }
    else {
      start(null);
    }
  }
  
  public void destroy()
  {
    Animator.shutdown(this);
    if (this.appletStarter != null) {
      this.appletStarter.stop();
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    HashMap localHashMap = createParameterTable(paramArrayOfString);
    JTFTools.setDebugOptions((String)localHashMap.get("debug"));
    String str = (String)localHashMap.get("code");
    if (str == null) {
      str = JTFTools.getMainClass();
    }
    Class localClass = null;
    Program localProgram = null;
    if (str != null)
    {
      if (str.endsWith(".class")) {
        str = str.substring(0, str.length() - 6);
      }
      str = str.replace('/', '.');
      CommandLineProgram.checkIfHeadless(str);
      try
      {
        localClass = Class.forName(str);
      }
      catch (ClassNotFoundException localClassNotFoundException1) {}
    }
    if (localClass != null) {
      try
      {
        Object localObject = localClass.newInstance();
        if ((localObject instanceof Program))
        {
          localProgram = (Program)localObject;
          localProgram.setStartupObject(null);
        }
        else
        {
          str = (String)localHashMap.get("program");
          if (str == null) {
            throw new ErrorException("Main class does not specify a program");
          }
          localProgram = (Program)Class.forName(str).newInstance();
          localProgram.setStartupObject(localObject);
        }
      }
      catch (IllegalAccessException localIllegalAccessException) {}catch (InstantiationException localInstantiationException) {}catch (ClassNotFoundException localClassNotFoundException2) {}
    }
    if (localProgram == null) {
      throw new ErrorException("Cannot determine the main class.");
    }
    localProgram.setParameterTable(localHashMap);
    localProgram.start();
  }
  
  public boolean menuAction(ActionEvent paramActionEvent)
  {
    String str = paramActionEvent.getActionCommand();
    if (str.equals("Quit"))
    {
      exit();
    }
    else
    {
      if (str.equals("Print"))
      {
        Frame localFrame = JTFTools.getEnclosingFrame(this);
        if (localFrame == null) {
          return true;
        }
        PrintJob localPrintJob = localFrame.getToolkit().getPrintJob(localFrame, this.myTitle, null);
        if (localPrintJob == null) {
          return true;
        }
        Graphics localGraphics = localPrintJob.getGraphics();
        localGraphics.translate(36, 36);
        localFrame.printAll(localGraphics);
        localPrintJob.end();
        return true;
      }
      if ((str.equals("Export Applet")) || (str.equals("Submit Project")))
      {
        JTFTools.executeExportAction(this, str);
        return true;
      }
    }
    return getConsole().menuAction(paramActionEvent);
  }
  
  protected Component getBorder(String paramString)
  {
    if (paramString.equals("North")) {
      return this.northBorder;
    }
    if (paramString.equals("South")) {
      return this.southBorder;
    }
    if (paramString.equals("East")) {
      return this.eastBorder;
    }
    if (paramString.equals("West")) {
      return this.westBorder;
    }
    throw new ErrorException("Illegal border specification - " + paramString);
  }
  
  protected String[] getArgumentArray()
  {
    if (this.parameterTable == null) {
      return null;
    }
    StringTokenizer localStringTokenizer = new StringTokenizer((String)this.parameterTable.get("ARGS"), "\t", false);
    String[] arrayOfString = new String[localStringTokenizer.countTokens()];
    for (int i = 0; localStringTokenizer.hasMoreTokens(); i++) {
      arrayOfString[i] = localStringTokenizer.nextToken();
    }
    return arrayOfString;
  }
  
  protected boolean isStarted()
  {
    IOConsole localIOConsole = getConsole();
    if (localIOConsole == null) {
      return false;
    }
    if (localIOConsole.getParent() == null) {
      return true;
    }
    Dimension localDimension = localIOConsole.getSize();
    return (localIOConsole.isShowing()) && (localDimension.width != 0) && (localDimension.height != 0);
  }
  
  protected void startHook() {}
  
  protected void endHook() {}
  
  protected void setAppletStub(AppletStub paramAppletStub)
  {
    this.appletStub = paramAppletStub;
    setStub(paramAppletStub);
  }
  
  protected AppletStub getAppletStub()
  {
    return this.appletStub;
  }
  
  protected void setParameterTable(HashMap<String, String> paramHashMap)
  {
    this.parameterTable = paramHashMap;
  }
  
  protected HashMap<String, String> getParameterTable()
  {
    return this.parameterTable;
  }
  
  protected void setStartupObject(Object paramObject)
  {
    this.startupObject = paramObject;
  }
  
  protected Object getStartupObject()
  {
    return this.startupObject;
  }
  
  protected void startRun()
  {
    ProgramStartupListener localProgramStartupListener = new ProgramStartupListener();
    JRootPane localJRootPane = getRootPane();
    if (localJRootPane.isShowing())
    {
      localJRootPane.addComponentListener(localProgramStartupListener);
      localJRootPane.validate();
      localProgramStartupListener.waitForStartup(this);
      localJRootPane.update(localJRootPane.getGraphics());
    }
    localJRootPane.setCursor(Cursor.getDefaultCursor());
    this.initFinished = true;
    startHook();
    runHook();
    endHook();
    if ((!localJRootPane.isShowing()) && (!getContentPane().isShowing())) {
      exit();
    }
  }
  
  protected void runHook()
  {
    run();
  }
  
  protected String getMyCaller()
  {
    StackTraceElement[] arrayOfStackTraceElement = new Throwable().getStackTrace();
    return arrayOfStackTraceElement[2].getClassName() + "." + arrayOfStackTraceElement[2].getMethodName();
  }
  
  protected static HashMap<String, String> createParameterTable(String[] paramArrayOfString)
  {
    if (paramArrayOfString == null) {
      return null;
    }
    HashMap localHashMap = new HashMap();
    String str1 = "";
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      String str2 = paramArrayOfString[i];
      int j = str2.indexOf('=');
      if (j > 0)
      {
        String str3 = str2.substring(0, j).toLowerCase();
        String str4 = str2.substring(j + 1);
        localHashMap.put(str3, str4);
      }
      else
      {
        if (str1.length() > 0) {
          str1 = str1 + '\t';
        }
        str1 = str1 + str2;
      }
    }
    localHashMap.put("ARGS", str1);
    return localHashMap;
  }
  
  private void initContentPane(Container paramContainer)
  {
    paramContainer.setLayout(new ProgramContentPaneLayout(this));
    this.northPanel = new JPanel();
    this.southPanel = new JPanel();
    this.eastPanel = new JPanel();
    this.westPanel = new JPanel();
    this.centerPanel = new JPanel();
    this.northPanel.setLayout(new TableLayout(1, 0, 5, 5));
    this.southPanel.setLayout(new TableLayout(1, 0, 5, 5));
    this.westPanel.setLayout(new TableLayout(0, 1, 5, 5));
    this.eastPanel.setLayout(new TableLayout(0, 1, 5, 5));
    this.centerPanel.setLayout(new GridLayout(1, 0));
    paramContainer.add(this.northPanel, "North");
    paramContainer.add(this.southPanel, "South");
    paramContainer.add(this.eastPanel, "East");
    paramContainer.add(this.westPanel, "West");
    paramContainer.add(this.centerPanel, "Center");
  }
  
  private void addActionListeners(Component paramComponent, ActionListener paramActionListener)
  {
    if (isButton(paramComponent))
    {
      if (!hasActionListener(paramComponent)) {
        try
        {
          Class[] arrayOfClass = { Class.forName("java.awt.event.ActionListener") };
          Object[] arrayOfObject = { paramActionListener };
          Method localMethod = paramComponent.getClass().getMethod("addActionListener", arrayOfClass);
          localMethod.invoke(paramComponent, arrayOfObject);
        }
        catch (Exception localException)
        {
          throw new ErrorException(localException);
        }
      }
    }
    else if ((paramComponent instanceof Container))
    {
      Container localContainer = (Container)paramComponent;
      int i = localContainer.getComponentCount();
      for (int j = 0; j < i; j++) {
        addActionListeners(localContainer.getComponent(j), paramActionListener);
      }
    }
  }
  
  private boolean isButton(Component paramComponent)
  {
    return ((paramComponent instanceof Button)) || ((paramComponent instanceof JButton));
  }
  
  private boolean hasActionListener(Component paramComponent)
  {
    try
    {
      Method localMethod = paramComponent.getClass().getMethod("getActionListeners", new Class[0]);
      ActionListener[] arrayOfActionListener = (ActionListener[])localMethod.invoke(paramComponent, new Object[0]);
      return arrayOfActionListener.length > 0;
    }
    catch (Exception localException) {}
    return false;
  }
  
  private void initApplicationFrame()
  {
    this.programFrame = createProgramFrame();
    ((ProgramAppletStub)this.appletStub).setFrame(this.programFrame);
    Container localContainer = this.programFrame.getContentPane();
    localContainer.setLayout(new BorderLayout());
    localContainer.add(getContentPane(), "Center");
    this.programFrame.addWindowListener(new ProgramWindowListener(this));
    this.programBounds = computeProgramBounds();
    Insets localInsets = this.programFrame.getInsets();
    int i = this.programBounds.width + localInsets.left + localInsets.right;
    int j = this.programBounds.height + localInsets.top + localInsets.bottom;
    this.programFrame.setBounds(this.programBounds.x, this.programBounds.y, i, j);
  }
  
  private int decodeSizeParameter(String paramString, int paramInt1, int paramInt2)
  {
    String str = getParameter(paramString);
    if (str == null) {
      try
      {
        Class localClass = getClass();
        Field localField = localClass.getField("APPLICATION_" + paramString);
        Object localObject = localField.get(null);
        if ((localObject instanceof Integer)) {
          return ((Integer)localObject).intValue();
        }
        if ((localObject instanceof String)) {
          str = (String)localObject;
        } else {
          return paramInt1;
        }
      }
      catch (Exception localException)
      {
        return paramInt1;
      }
    }
    if (str.equals("*")) {
      str = "100%";
    }
    if (str.endsWith("%"))
    {
      int i = Integer.parseInt(str.substring(0, str.length() - 1));
      return (int)Math.round(i / 100.0D * paramInt2);
    }
    return Integer.parseInt(str);
  }
  
  private Rectangle computeProgramBounds()
  {
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    int i = decodeSizeParameter("WIDTH", 754, localDimension.width);
    int j = decodeSizeParameter("HEIGHT", 492, localDimension.height);
    int k = decodeSizeParameter("X", i >= localDimension.width ? 0 : 16, localDimension.width);
    int m = decodeSizeParameter("Y", j >= localDimension.height ? 0 : 40, localDimension.height);
    return new Rectangle(k, m, i, j);
  }
  
  private boolean checkForAppletMode()
  {
    StackTraceElement[] arrayOfStackTraceElement = new Throwable().getStackTrace();
    for (int i = 1; i < arrayOfStackTraceElement.length; i++) {
      if (arrayOfStackTraceElement[i].getMethodName().indexOf("Applet") >= 0) {
        return true;
      }
    }
    return false;
  }
  
  private void circumventFrameSizeBug(Frame paramFrame, Dimension paramDimension)
  {
    Container localContainer = getContentPane();
    Dimension localDimension1 = localContainer.getSize();
    if ((paramDimension.equals(localDimension1)) || (localDimension1.width == 0) || (localDimension1.height == 0)) {
      return;
    }
    Dimension localDimension2 = paramFrame.getSize();
    localDimension2.width += paramDimension.width - localDimension1.width;
    localDimension2.height += paramDimension.height - localDimension1.height;
    paramFrame.setSize(localDimension2.width, localDimension2.height);
    paramFrame.validate();
  }
}
