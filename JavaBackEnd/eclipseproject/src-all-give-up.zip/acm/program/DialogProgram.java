package acm.program;

import acm.io.IODialog;

public abstract class DialogProgram
  extends Program
{
  public DialogProgram()
  {
    IODialog localIODialog = getDialog();
    setInputModel(localIODialog);
    setOutputModel(localIODialog);
  }
  
  public void run() {}
  
  public void init() {}
}
