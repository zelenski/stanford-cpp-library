package acm.program;

import acm.graphics.GCanvas;
import acm.graphics.GMath;
import acm.graphics.GObject;
import acm.graphics.GPoint;
import acm.util.ErrorException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.EventListener;
import java.util.Iterator;

public abstract class GraphicsProgram
  extends Program
{
  private GCanvas gc;
  private GProgramListener eventListener;
  
  protected GraphicsProgram()
  {
    this.eventListener = new GProgramListener(this);
    setGCanvas(createGCanvas());
    add(this.gc, "Center");
    validate();
  }
  
  public void run() {}
  
  public void init() {}
  
  public GCanvas getGCanvas()
  {
    return this.gc;
  }
  
  public void add(GObject paramGObject)
  {
    this.gc.add(paramGObject);
  }
  
  public final void add(GObject paramGObject, double paramDouble1, double paramDouble2)
  {
    paramGObject.setLocation(paramDouble1, paramDouble2);
    add(paramGObject);
  }
  
  public final void add(GObject paramGObject, GPoint paramGPoint)
  {
    paramGObject.setLocation(paramGPoint);
    add(paramGObject);
  }
  
  public final void add(Component paramComponent, double paramDouble1, double paramDouble2)
  {
    paramComponent.setLocation(GMath.round(paramDouble1), GMath.round(paramDouble2));
    this.gc.add(paramComponent);
  }
  
  public final void add(Component paramComponent, GPoint paramGPoint)
  {
    add(paramComponent, paramGPoint.getX(), paramGPoint.getY());
  }
  
  public void remove(GObject paramGObject)
  {
    this.gc.remove(paramGObject);
  }
  
  public void removeAll()
  {
    this.gc.removeAll();
  }
  
  public int getElementCount()
  {
    return this.gc.getElementCount();
  }
  
  public GObject getElement(int paramInt)
  {
    return this.gc.getElement(paramInt);
  }
  
  public GObject getElementAt(double paramDouble1, double paramDouble2)
  {
    return this.gc.getElementAt(paramDouble1, paramDouble2);
  }
  
  public final GObject getElementAt(GPoint paramGPoint)
  {
    return getElementAt(paramGPoint.getX(), paramGPoint.getY());
  }
  
  public void setGCanvas(GCanvas paramGCanvas)
  {
    this.gc = paramGCanvas;
    paramGCanvas.addMouseListener(this.eventListener);
    if (this.eventListener.needsMouseMotionListeners()) {
      paramGCanvas.addMouseMotionListener(this.eventListener);
    }
  }
  
  public Iterator<GObject> iterator()
  {
    return this.gc.iterator();
  }
  
  public Iterator<GObject> iterator(int paramInt)
  {
    return this.gc.iterator(paramInt);
  }
  
  public void addMouseListeners()
  {
    this.gc.addMouseListener(this);
    this.gc.addMouseMotionListener(this);
  }
  
  public void addMouseListeners(EventListener paramEventListener)
  {
    int i = 0;
    if ((paramEventListener instanceof MouseListener))
    {
      this.gc.addMouseListener((MouseListener)paramEventListener);
      i = 1;
    }
    if ((paramEventListener instanceof MouseMotionListener))
    {
      this.gc.addMouseMotionListener((MouseMotionListener)paramEventListener);
      i = 1;
    }
    if (i == 0) {
      throw new ErrorException("addMouseListeners: Illegal listener");
    }
  }
  
  public void addKeyListeners()
  {
    this.gc.addKeyListener(this);
  }
  
  public void addKeyListeners(KeyListener paramKeyListener)
  {
    this.gc.addKeyListener(paramKeyListener);
  }
  
  public void waitForClick()
  {
    this.eventListener.waitForClick();
  }
  
  public void repaint()
  {
    this.gc.repaint();
    super.repaint();
  }
  
  public void removeAllComponents()
  {
    super.removeAll();
  }
  
  public Dimension getCentralRegionSize()
  {
    if (this.gc.isShowing()) {
      return this.gc.getSize();
    }
    return super.getCentralRegionSize();
  }
  
  public void setBackground(Color paramColor)
  {
    super.setBackground(paramColor);
    if (this.gc != null) {
      this.gc.setBackground(paramColor);
    }
  }
  
  public static void startGraphicsProgram(GObject paramGObject, String[] paramArrayOfString)
  {
    GObjectProgram localGObjectProgram = new GObjectProgram();
    localGObjectProgram.setStartupObject(paramGObject);
    localGObjectProgram.start(paramArrayOfString);
  }
  
  protected GCanvas createGCanvas()
  {
    return new GCanvas();
  }
  
  protected void endHook()
  {
    this.gc.repaint();
  }
  
  protected boolean isStarted()
  {
    if ((this.gc == null) || (!super.isStarted())) {
      return false;
    }
    Dimension localDimension = this.gc.getSize();
    return (localDimension != null) && (localDimension.width != 0) && (localDimension.height != 0);
  }
}
