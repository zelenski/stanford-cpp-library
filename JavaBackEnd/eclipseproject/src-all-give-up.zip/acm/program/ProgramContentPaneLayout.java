package acm.program;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;

class ProgramContentPaneLayout
  extends BorderLayout
{
  private Program myProgram;
  
  public ProgramContentPaneLayout(Program paramProgram)
  {
    this.myProgram = paramProgram;
  }
  
  public void layoutContainer(Container paramContainer)
  {
    super.layoutContainer(paramContainer);
    if (!this.myProgram.isAncestorOf(paramContainer))
    {
      Dimension localDimension = paramContainer.getSize();
      Insets localInsets = paramContainer.getInsets();
      int i = localInsets.left;
      int j = localInsets.top;
      int k = localDimension.width - localInsets.left - localInsets.right;
      int m = localDimension.height - localInsets.top - localInsets.bottom;
      this.myProgram.setBounds(i, j, k, m);
      ComponentEvent localComponentEvent = new ComponentEvent(this.myProgram, 101);
      Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(localComponentEvent);
    }
  }
}
