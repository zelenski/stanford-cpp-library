package acm.program;

import acm.util.ErrorException;
import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.applet.AudioClip;
import java.awt.Frame;
import java.awt.Image;
import java.awt.image.ImageProducer;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

class ProgramAppletStub
  implements AppletContext, AppletStub
{
  private Applet applet;
  private Frame enclosure;
  private boolean recursiveResizeCheck;
  
  public ProgramAppletStub(Program paramProgram)
  {
    this.applet = paramProgram;
  }
  
  public void setFrame(Frame paramFrame)
  {
    this.enclosure = paramFrame;
  }
  
  public boolean isActive()
  {
    return true;
  }
  
  public URL getDocumentBase()
  {
    return getCodeBase();
  }
  
  public URL getCodeBase()
  {
    try
    {
      return new URL("file:" + getCanonicalPath("."));
    }
    catch (MalformedURLException localMalformedURLException)
    {
      throw new ErrorException("Error: Illegal document base URL");
    }
  }
  
  public String getParameter(String paramString)
  {
    return null;
  }
  
  public AppletContext getAppletContext()
  {
    return this;
  }
  
  public void appletResize(int paramInt1, int paramInt2)
  {
    if (this.enclosure == null)
    {
      if (!this.recursiveResizeCheck)
      {
        this.recursiveResizeCheck = true;
        this.applet.resize(paramInt1, paramInt2);
        this.applet.validate();
        this.recursiveResizeCheck = false;
      }
    }
    else
    {
      this.enclosure.setSize(paramInt1, paramInt2);
      this.enclosure.validate();
    }
  }
  
  public AudioClip getAudioClip(URL paramURL)
  {
    AudioClip localAudioClip = null;
    if (localAudioClip == null) {
      localAudioClip = getNewAudioClip(paramURL);
    }
    return localAudioClip;
  }
  
  public Image getImage(URL paramURL)
  {
    try
    {
      Object localObject = paramURL.getContent();
      if ((localObject instanceof ImageProducer)) {
        return this.applet.createImage((ImageProducer)localObject);
      }
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public Applet getApplet(String paramString)
  {
    return null;
  }
  
  public Enumeration<Applet> getApplets()
  {
    return new Vector().elements();
  }
  
  public void showDocument(URL paramURL)
  {
    if (this.applet != null) {
      this.applet.getAppletContext().showDocument(paramURL);
    }
  }
  
  public void showDocument(URL paramURL, String paramString)
  {
    if (this.applet != null) {
      this.applet.getAppletContext().showDocument(paramURL, paramString);
    }
  }
  
  public void showStatus(String paramString)
  {
    if (this.applet == null) {
      System.out.println(paramString);
    } else {
      this.applet.showStatus(paramString);
    }
  }
  
  public void setStream(String paramString, InputStream paramInputStream)
  {
    throw new ErrorException("setStream: unimplemented operation");
  }
  
  public InputStream getStream(String paramString)
  {
    throw new ErrorException("getStream: unimplemented operation");
  }
  
  public Iterator<String> getStreamKeys()
  {
    throw new ErrorException("getStreamKeys: unimplemented operation");
  }
  
  private String getCanonicalPath(String paramString)
  {
    String str = new File(paramString).getAbsolutePath();
    int i;
    while ((i = str.indexOf(' ')) != -1) {
      str = str.substring(0, i) + "%20" + str.substring(i + 1);
    }
    return str;
  }
  
  private synchronized AudioClip getNewAudioClip(URL paramURL)
  {
    try
    {
      Class localClass = Class.forName("java.applet.Applet");
      Class[] arrayOfClass = { Class.forName("java.net.URL") };
      Object[] arrayOfObject = { paramURL };
      Method localMethod = localClass.getMethod("newAudioClip", arrayOfClass);
      return (AudioClip)localMethod.invoke(null, arrayOfObject);
    }
    catch (Exception localException) {}
    return null;
  }
}
