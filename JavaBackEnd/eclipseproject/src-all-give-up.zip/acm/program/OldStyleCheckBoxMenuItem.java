package acm.program;

import java.awt.CheckboxMenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class OldStyleCheckBoxMenuItem
  extends CheckboxMenuItem
  implements ActionListener, ChangeListener
{
  private JCheckBoxMenuItem twin;
  
  public OldStyleCheckBoxMenuItem(JCheckBoxMenuItem paramJCheckBoxMenuItem)
  {
    super(paramJCheckBoxMenuItem.getText());
    this.twin = paramJCheckBoxMenuItem;
    addActionListener(this);
    this.twin.addChangeListener(this);
    setState(this.twin.getState());
    setEnabled(this.twin.isEnabled());
    KeyStroke localKeyStroke = this.twin.getAccelerator();
    if (localKeyStroke != null) {
      setShortcut(createShortcut(localKeyStroke));
    }
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.twin.doClick(0);
  }
  
  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    setState(this.twin.getState());
    setEnabled(this.twin.isEnabled());
  }
  
  private MenuShortcut createShortcut(KeyStroke paramKeyStroke)
  {
    boolean bool = (paramKeyStroke.getModifiers() & 0x1) != 0;
    return new MenuShortcut(paramKeyStroke.getKeyCode(), bool);
  }
}
