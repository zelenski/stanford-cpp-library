package acm.program;

import acm.util.JTFTools;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

class ProgramStartupListener
  implements ComponentListener
{
  private static final int STARTUP_DELAY = 1000;
  private static final int STARTUP_CYCLE = 300;
  
  public synchronized void waitForStartup(Program paramProgram)
  {
    JTFTools.pause(1000.0D);
    while (!paramProgram.isStarted()) {
      try
      {
        wait(300L);
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public void componentHidden(ComponentEvent paramComponentEvent) {}
  
  public void componentMoved(ComponentEvent paramComponentEvent) {}
  
  public void componentResized(ComponentEvent paramComponentEvent)
  {
    componentShown(paramComponentEvent);
  }
  
  public synchronized void componentShown(ComponentEvent paramComponentEvent)
  {
    notifyAll();
  }
}
