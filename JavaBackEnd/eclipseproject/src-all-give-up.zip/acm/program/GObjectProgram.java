package acm.program;

import acm.graphics.GDimension;
import acm.graphics.GObject;
import acm.util.ErrorException;
import java.lang.reflect.Method;

class GObjectProgram
  extends GraphicsProgram
{
  protected void runHook()
  {
    GObject localGObject = (GObject)getStartupObject();
    GDimension localGDimension = localGObject.getSize();
    add(localGObject, (getWidth() - localGDimension.getWidth()) / 2.0D, (getHeight() - localGDimension.getHeight()) / 2.0D);
    try
    {
      Class localClass = localGObject.getClass();
      String str = localClass.getName();
      str = str.substring(str.lastIndexOf(".") + 1);
      setTitle(str);
      Method localMethod = localClass.getMethod("run", new Class[0]);
      if (localMethod == null) {
        throw new ErrorException(str + " has no run method");
      }
      localMethod.invoke(localGObject, new Object[0]);
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
}
