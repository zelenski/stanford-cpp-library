package acm.program;

import java.awt.Graphics;
import javax.swing.JFrame;

class ProgramFrame
  extends JFrame
{
  public ProgramFrame(String paramString)
  {
    super(paramString);
  }
  
  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }
}
