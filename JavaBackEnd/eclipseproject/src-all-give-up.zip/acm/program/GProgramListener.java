package acm.program;

import acm.graphics.GPoint;
import acm.util.ErrorException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.lang.reflect.Method;

class GProgramListener
  implements MouseListener, MouseMotionListener
{
  private GraphicsProgram myProgram;
  private Method mousePressedHook;
  private Method mouseReleasedHook;
  private Method mouseClickedHook;
  private Method mouseMovedHook;
  private Method mouseDraggedHook;
  private boolean clickFlag;
  
  public GProgramListener(GraphicsProgram paramGraphicsProgram)
  {
    this.myProgram = paramGraphicsProgram;
    try
    {
      Class localClass = paramGraphicsProgram.getClass();
      Class[] arrayOfClass = { Class.forName("acm.graphics.GPoint") };
      try
      {
        this.mousePressedHook = localClass.getMethod("mousePressed", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException1) {}
      try
      {
        this.mouseReleasedHook = localClass.getMethod("mouseReleased", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException2) {}
      try
      {
        this.mouseClickedHook = localClass.getMethod("mouseClicked", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException3) {}
      try
      {
        this.mouseMovedHook = localClass.getMethod("mouseMoved", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException4) {}
      try
      {
        this.mouseDraggedHook = localClass.getMethod("mouseDragged", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException5) {}
    }
    catch (Exception localException)
    {
      throw new ErrorException(localException);
    }
  }
  
  public boolean needsMouseMotionListeners()
  {
    return (this.mouseMovedHook != null) || (this.mouseDraggedHook != null);
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    if (this.mouseClickedHook != null)
    {
      Object[] arrayOfObject = { new GPoint(paramMouseEvent.getX(), paramMouseEvent.getY()) };
      try
      {
        this.mouseClickedHook.invoke(this.myProgram, arrayOfObject);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
    signalClickOccurred();
  }
  
  public void mousePressed(MouseEvent paramMouseEvent)
  {
    if (this.mousePressedHook != null)
    {
      Object[] arrayOfObject = { new GPoint(paramMouseEvent.getX(), paramMouseEvent.getY()) };
      try
      {
        this.mousePressedHook.invoke(this.myProgram, arrayOfObject);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
  }
  
  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    if (this.mouseReleasedHook != null)
    {
      Object[] arrayOfObject = { new GPoint(paramMouseEvent.getX(), paramMouseEvent.getY()) };
      try
      {
        this.mouseReleasedHook.invoke(this.myProgram, arrayOfObject);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
  }
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    if (this.mouseMovedHook != null)
    {
      Object[] arrayOfObject = { new GPoint(paramMouseEvent.getX(), paramMouseEvent.getY()) };
      try
      {
        this.mouseMovedHook.invoke(this.myProgram, arrayOfObject);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
  }
  
  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    if (this.mouseDraggedHook != null)
    {
      Object[] arrayOfObject = { new GPoint(paramMouseEvent.getX(), paramMouseEvent.getY()) };
      try
      {
        this.mouseDraggedHook.invoke(this.myProgram, arrayOfObject);
      }
      catch (Exception localException)
      {
        throw new ErrorException(localException);
      }
    }
  }
  
  public synchronized void waitForClick()
  {
    this.clickFlag = false;
    while (!this.clickFlag) {
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  private synchronized void signalClickOccurred()
  {
    this.clickFlag = true;
    notifyAll();
  }
}
