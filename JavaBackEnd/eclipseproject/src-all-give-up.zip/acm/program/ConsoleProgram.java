package acm.program;

import acm.io.IOConsole;
import acm.util.JTFTools;
import java.awt.Font;

public abstract class ConsoleProgram
  extends Program
{
  public ConsoleProgram()
  {
    add(getConsole(), "Center");
    validate();
  }
  
  public void run() {}
  
  public void init() {}
  
  public void setFont(String paramString)
  {
    IOConsole localIOConsole = getConsole();
    if (localIOConsole != null)
    {
      localIOConsole.setFont(paramString);
      super.setFont(localIOConsole.getFont());
    }
  }
  
  public void setFont(Font paramFont)
  {
    IOConsole localIOConsole = getConsole();
    paramFont = JTFTools.getStandardFont(paramFont);
    if (localIOConsole != null) {
      localIOConsole.setFont(paramFont);
    }
    super.setFont(paramFont);
  }
  
  protected IOConsole createConsole()
  {
    return new IOConsole();
  }
}
