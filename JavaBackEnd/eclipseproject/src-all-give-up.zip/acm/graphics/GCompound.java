package acm.graphics;

import acm.util.ErrorException;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;

public class GCompound extends GObject implements GContainer {
	private boolean complete;
	private GObjectList contents;
	private transient GObject lastObject;
	private transient GObject dragObject;
	static final long serialVersionUID = 21L;

	public GCompound() {
		this.contents = new GObjectList(this);
		this.complete = false;
	}

	public void add(GObject paramGObject) {
		if (this.complete) {
			throw new ErrorException(
					"You can't add objects to a GCompound that has been marked as complete.");
		}
		this.contents.add(paramGObject);
		repaint();
	}

	public final void add(GObject paramGObject, double paramDouble1, double paramDouble2) {
		paramGObject.setLocation(paramDouble1, paramDouble2);
		add(paramGObject);
	}

	public final void add(GObject paramGObject, GPoint paramGPoint) {
		add(paramGObject, paramGPoint.getX(), paramGPoint.getY());
	}

	public void remove(GObject paramGObject) {
		if (this.complete) {
			throw new ErrorException(
					"You can't remove objects from a GCompound that has been marked as complete.");
		}
		this.contents.remove(paramGObject);
		repaint();
	}

	public void removeAll() {
		if (this.complete) {
			throw new ErrorException(
					"You can't remove objects from a GCompound that has been marked as complete.");
		}
		this.contents.removeAll();
		repaint();
	}

	public int getElementCount() {
		return this.contents.getElementCount();
	}

	public GObject getElement(int paramInt) {
		return this.contents.getElement(paramInt);
	}

	public GObject getElementAt(double paramDouble1, double paramDouble2) {
		return this.contents.getElementAt(paramDouble1, paramDouble2, false);
	}

	public final GObject getElementAt(GPoint paramGPoint) {
		return getElementAt(paramGPoint.getX(), paramGPoint.getY());
	}

	public Iterator<GObject> iterator() {
		return new GIterator(this, 0);
	}

	public Iterator<GObject> iterator(int paramInt) {
		return new GIterator(this, paramInt);
	}

	public Object clone() {
		try {
			GCompound localGCompound = (GCompound) super.clone();
			localGCompound.contents = new GObjectList(localGCompound, this.contents);
			for (int i = 0; i < this.contents.getElementCount(); i++) {
				System.err.println("original = " + this.contents.getElement(i).hashCode());
				System.err
						.println("clone    = " + localGCompound.contents.getElement(i).hashCode());
			}
			return localGCompound;
		} catch (Exception localException) {
			throw new ErrorException("Impossible exception");
		}
	}

	protected void paint2d(Graphics2D paramGraphics2D) {
		this.contents.mapPaint(paramGraphics2D);
	}

	public GRectangle getBounds() {
		GRectangle localGRectangle = this.contents.getBounds();
		Object localObject = new Rectangle2D.Double(localGRectangle.getX(), localGRectangle.getY(),
				localGRectangle.getWidth(), localGRectangle.getHeight());

		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			localObject = localAffineTransform.createTransformedShape((Shape) localObject);
		}
		Rectangle localRectangle = ((Shape) localObject).getBounds();
		return new GRectangle(getX() + localRectangle.getX(), getY() + localRectangle.getY(),
				localRectangle.getWidth(), localRectangle.getHeight());
	}

	public boolean contains(double paramDouble1, double paramDouble2) {
		paramDouble1 -= getX();
		paramDouble2 -= getY();
		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			try {
				localAffineTransform = localAffineTransform.createInverse();
				Point2D.Double localDouble = new Point2D.Double(paramDouble1, paramDouble2);
				localAffineTransform.transform(localDouble, localDouble);
				paramDouble1 = localDouble.getX();
				paramDouble2 = localDouble.getY();
			} catch (NoninvertibleTransformException localNoninvertibleTransformException) {
				throw new ErrorException(localNoninvertibleTransformException);
			}
		}
		return this.contents.contains(paramDouble1, paramDouble2);
	}

	public final GPoint getCanvasPoint(GPoint paramGPoint) {
		return getCanvasPoint(paramGPoint.getX(), paramGPoint.getY());
	}

	public GPoint getCanvasPoint(double paramDouble1, double paramDouble2) {
		for (Object localObject = this; (localObject instanceof GCompound);) {
			GCompound localGCompound = (GCompound) localObject;
			paramDouble1 += localGCompound.getX();
			paramDouble2 += localGCompound.getY();
			localObject = localGCompound.getParent();
		}
		return new GPoint(paramDouble1, paramDouble2);
	}

	public final GPoint getLocalPoint(GPoint paramGPoint) {
		return getLocalPoint(paramGPoint.getX(), paramGPoint.getY());
	}

	public GPoint getLocalPoint(double paramDouble1, double paramDouble2) {
		for (Object localObject = this; (localObject instanceof GCompound);) {
			GCompound localGCompound = (GCompound) localObject;
			paramDouble1 -= localGCompound.getX();
			paramDouble2 -= localGCompound.getY();
			localObject = localGCompound.getParent();
		}
		return new GPoint(paramDouble1, paramDouble2);
	}

	public void markAsComplete() {
		this.complete = true;
	}

	protected void sendToFront(GObject paramGObject) {
		this.contents.sendToFront(paramGObject);
		repaint();
	}

	protected void sendToBack(GObject paramGObject) {
		this.contents.sendToBack(paramGObject);
		repaint();
	}

	protected void sendForward(GObject paramGObject) {
		this.contents.sendForward(paramGObject);
		repaint();
	}

	protected void sendBackward(GObject paramGObject) {
		this.contents.sendBackward(paramGObject);
		repaint();
	}

	protected void fireMouseListeners(MouseEvent paramMouseEvent) {
		if (super.areMouseListenersEnabled()) {
			super.fireMouseListeners(paramMouseEvent);
			return;
		}
		GPoint localGPoint = new GPoint(paramMouseEvent.getX() - getX(), paramMouseEvent.getY()
				- getY());
		GObject localGObject = getElementAt(localGPoint);
		MouseEvent localMouseEvent = null;
		if (localGObject != this.lastObject) {
			if (this.lastObject != null) {
				localMouseEvent = GCanvas.createMouseEvent(this.lastObject, 505, paramMouseEvent);

				this.lastObject.fireMouseListeners(localMouseEvent);
			}
			if (localGObject != null) {
				localMouseEvent = GCanvas.createMouseEvent(localGObject, 504, paramMouseEvent);

				localGObject.fireMouseListeners(localMouseEvent);
			}
		}
		this.lastObject = localGObject;
		if (this.dragObject != null) {
			localGObject = this.dragObject;
		}
		if (localGObject != null) {
			int i = paramMouseEvent.getID();
			if ((i != 505) && (i != 504)) {
				if (i == 501) {
					this.dragObject = localGObject;
				} else if (i == 502) {
					this.dragObject = null;
				}
				localMouseEvent = GCanvas.createMouseEvent(localGObject, i, paramMouseEvent);
				localGObject.fireMouseListeners(localMouseEvent);
			}
		}
		if ((localMouseEvent != null) && (localMouseEvent.isConsumed())) {
			paramMouseEvent.consume();
		}
	}

	protected boolean areMouseListenersEnabled() {
		if (super.areMouseListenersEnabled()) {
			return true;
		}
		return this.contents.areMouseListenersEnabled();
	}
}
