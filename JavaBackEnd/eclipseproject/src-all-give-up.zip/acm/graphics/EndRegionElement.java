package acm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;

class EndRegionElement extends PathElement {
	private static final long serialVersionUID = 1L;

	public void paint(Graphics2D paramGraphics2D, PathState paramPathState) {
		Color localColor = paramGraphics2D.getColor();
		paramGraphics2D.setColor(paramPathState.fillColor);
		paramGraphics2D.fillPolygon(paramPathState.region.xpoints, paramPathState.region.ypoints,
				paramPathState.region.npoints);

		paramGraphics2D.setColor(localColor);
		paramGraphics2D.drawPolygon(paramPathState.region.xpoints, paramPathState.region.ypoints,
				paramPathState.region.npoints);

		paramPathState.region = null;
	}
}
