package acm.graphics;

import java.awt.Graphics;
import java.io.Serializable;
import java.util.ArrayList;

class GObjectList implements Serializable {
	private transient GContainer parent;
	private ArrayList<GObject> contents;
	private ArrayList<GObject> enabledList;

	public GObjectList(GContainer paramGContainer) {
		this.parent = paramGContainer;
		this.contents = new ArrayList();
		if ((this.parent instanceof GCanvas)) {
			this.enabledList = new ArrayList();
		}
	}

	public GObjectList(GContainer paramGContainer, GObjectList paramGObjectList) {
		this.parent = paramGContainer;
		this.contents = new ArrayList();
		this.enabledList = new ArrayList();
		int i = paramGObjectList.contents.size();
		for (int j = 0; j < i; j++) {
			this.contents.add((GObject) ((GObject) paramGObjectList.contents.get(j)).clone());
		}
	}

	public synchronized void add(GObject paramGObject) {
		if (paramGObject.getParent() != null) {
			paramGObject.getParent().remove(paramGObject);
		}
		paramGObject.setParent(this.parent);
		this.contents.add(paramGObject);
		if ((this.enabledList != null) && (paramGObject.areMouseListenersEnabled())) {
			this.enabledList.add(paramGObject);
		}
	}

	public synchronized void remove(GObject paramGObject) {
		this.contents.remove(paramGObject);
		paramGObject.setParent(null);
		if (this.enabledList != null) {
			this.enabledList.remove(paramGObject);
		}
	}

	public synchronized void removeAll() {
		this.contents.clear();
		if (this.enabledList != null) {
			this.enabledList.clear();
		}
	}

	public int getElementCount() {
		return this.contents.size();
	}

	public GObject getElement(int paramInt) {
		return (GObject) this.contents.get(paramInt);
	}

	public synchronized GObject getElementAt(double paramDouble1, double paramDouble2,
			boolean paramBoolean) {
		ArrayList localArrayList = paramBoolean ? this.enabledList : this.contents;
		for (int i = localArrayList.size() - 1; i >= 0; i--) {
			GObject localGObject = (GObject) localArrayList.get(i);
			if (localGObject.contains(paramDouble1, paramDouble2)) {
				return localGObject;
			}
		}
		return null;
	}

	public synchronized void sendToFront(GObject paramGObject) {
		int i = this.contents.indexOf(paramGObject);
		if (i >= 0) {
			this.contents.remove(i);
			this.contents.add(paramGObject);
		}
	}

	public synchronized void sendToBack(GObject paramGObject) {
		int i = this.contents.indexOf(paramGObject);
		if (i >= 0) {
			this.contents.remove(i);
			this.contents.add(0, paramGObject);
		}
	}

	public synchronized void sendForward(GObject paramGObject) {
		int i = this.contents.indexOf(paramGObject);
		if (i >= 0) {
			this.contents.remove(i);
			this.contents.add(Math.min(this.contents.size(), i + 1), paramGObject);
		}
	}

	public synchronized void sendBackward(GObject paramGObject) {
		int i = this.contents.indexOf(paramGObject);
		if (i >= 0) {
			this.contents.remove(i);
			this.contents.add(Math.max(0, i - 1), paramGObject);
		}
	}

	public synchronized GRectangle getBounds() {
		GRectangle localGRectangle = new GRectangle();
		int i = this.contents.size();
		for (int j = 0; j < i; j++) {
			if (j == 0) {
				localGRectangle = new GRectangle(((GObject) this.contents.get(j)).getBounds());
			} else {
				localGRectangle.add(((GObject) this.contents.get(j)).getBounds());
			}
		}
		return localGRectangle;
	}

	public synchronized boolean contains(double paramDouble1, double paramDouble2) {
		int i = this.contents.size();
		for (int j = 0; j < i; j++) {
			if (((GObject) this.contents.get(j)).contains(paramDouble1, paramDouble2)) {
				return true;
			}
		}
		return false;
	}

	public synchronized void mapPaint(Graphics paramGraphics) {
		int i = this.contents.size();
		for (int j = 0; j < i; j++) {
			((GObject) this.contents.get(j)).paint(paramGraphics);
		}
	}

	public synchronized boolean areMouseListenersEnabled() {
		int i = this.contents.size();
		for (int j = 0; j < i; j++) {
			GObject localGObject = (GObject) this.contents.get(j);
			if (localGObject.areMouseListenersEnabled()) {
				return true;
			}
		}
		return false;
	}

	public synchronized void updateEnabledList() {
		this.enabledList.clear();
		int i = this.contents.size();
		for (int j = 0; j < i; j++) {
			GObject localGObject = (GObject) this.contents.get(j);
			if (localGObject.areMouseListenersEnabled()) {
				this.enabledList.add(localGObject);
			}
		}
	}
}
