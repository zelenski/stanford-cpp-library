package acm.graphics;

import java.awt.Color;

public abstract interface GFillable {
	public abstract void setFilled(boolean paramBoolean);

	public abstract boolean isFilled();

	public abstract void setFillColor(Color paramColor);

	public abstract Color getFillColor();
}
