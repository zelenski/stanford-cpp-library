package acm.graphics;

import java.awt.Graphics2D;
import java.awt.geom.RoundRectangle2D;

public class GRoundRect extends GRect {
	public static final double DEFAULT_ARC = 10.0D;
	private double aWidth;
	private double aHeight;
	static final long serialVersionUID = 21L;

	public GRoundRect(double paramDouble1, double paramDouble2) {
		this(0.0D, 0.0D, paramDouble1, paramDouble2, 10.0D);
	}

	public GRoundRect(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		this(paramDouble1, paramDouble2, paramDouble3, paramDouble4, 10.0D);
	}

	public GRoundRect(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4, double paramDouble5) {
		this(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble5);
	}

	public GRoundRect(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4, double paramDouble5, double paramDouble6) {
		super(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
		this.aWidth = paramDouble5;
		this.aHeight = paramDouble6;
	}

	public double getArcWidth() {
		return this.aWidth;
	}

	public double getArcHeight() {
		return this.aHeight;
	}

	protected void paint2d(Graphics2D paramGraphics2D) {
		RoundRectangle2D.Double localDouble = new RoundRectangle2D.Double(0.0D, 0.0D,
				getFrameWidth(), getFrameHeight(), this.aWidth, this.aHeight);
		if (isFilled()) {
			paramGraphics2D.setColor(getFillColor());
			paramGraphics2D.fill(localDouble);
			paramGraphics2D.setColor(getColor());
		}
		paramGraphics2D.draw(localDouble);
	}
}
