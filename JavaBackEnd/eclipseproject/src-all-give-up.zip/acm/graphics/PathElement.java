package acm.graphics;

import java.awt.Graphics2D;
import java.io.Serializable;

abstract class PathElement implements Serializable {
	private static final long serialVersionUID = 1L;

	public void paint(Graphics2D paramGraphics2D, PathState paramPathState) {
	}

	public void updateBounds(GRectangle paramGRectangle, PathState paramPathState) {
	}
}
