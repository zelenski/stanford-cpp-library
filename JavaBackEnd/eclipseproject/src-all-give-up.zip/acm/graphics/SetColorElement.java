package acm.graphics;

import java.awt.Color;
import java.awt.Graphics2D;

class SetColorElement extends PathElement {
	private static final long serialVersionUID = 1L;
	private Color color;

	public SetColorElement(Color paramColor) {
		this.color = paramColor;
	}

	public void paint(Graphics2D paramGraphics2D, PathState paramPathState) {
		paramGraphics2D.setColor(this.color);
	}
}
