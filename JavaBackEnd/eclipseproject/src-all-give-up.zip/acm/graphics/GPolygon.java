package acm.graphics;

import acm.util.ErrorException;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Path2D;

public class GPolygon extends GObject implements GFillable {
	private VertexList vertices;
	private boolean complete;
	private boolean isFilled;
	private Color fillColor;
	static final long serialVersionUID = 21L;

	public GPolygon() {
		this.vertices = new VertexList();
		clear();
	}

	public GPolygon(double paramDouble1, double paramDouble2) {
		this();
		setLocation(paramDouble1, paramDouble2);
	}

	public GPolygon(GPoint[] paramArrayOfGPoint) {
		this();
		this.vertices.add(paramArrayOfGPoint);
		markAsComplete();
	}

	public void addVertex(double paramDouble1, double paramDouble2) {
		if (this.complete) {
			throw new ErrorException(
					"You can't add vertices to a GPolygon that has been marked as complete.");
		}
		this.vertices.addVertex(paramDouble1, paramDouble2);
	}

	public void addEdge(double paramDouble1, double paramDouble2) {
		if (this.complete) {
			throw new ErrorException(
					"You can't add edges to a GPolygon that has been marked as complete.");
		}
		this.vertices.addEdge(paramDouble1, paramDouble2);
	}

	public final void addPolarEdge(double paramDouble1, double paramDouble2) {
		if (this.complete) {
			throw new ErrorException(
					"You can't add edges to a GPolygon that has been marked as complete.");
		}
		this.vertices.addEdge(paramDouble1 * GMath.cosDegrees(paramDouble2),
				-paramDouble1 * GMath.sinDegrees(paramDouble2));
	}

	public void addArc(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		if (this.complete) {
			throw new ErrorException(
					"You can't add edges to a GPolygon that has been marked as complete.");
		}
		this.vertices.addArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
	}

	public GPoint getCurrentPoint() {
		return this.vertices.getCurrentPoint();
	}

	public void setFilled(boolean paramBoolean) {
		this.isFilled = paramBoolean;
		repaint();
	}

	public boolean isFilled() {
		return this.isFilled;
	}

	public void setFillColor(Color paramColor) {
		this.fillColor = paramColor;
		repaint();
	}

	public Color getFillColor() {
		return this.fillColor == null ? getColor() : this.fillColor;
	}

	public GRectangle getBounds() {
		GRectangle localGRectangle = this.vertices.getBounds(getMatrix());
		return new GRectangle(localGRectangle.getX() + getX(), localGRectangle.getY() + getY(),
				localGRectangle.getWidth(), localGRectangle.getHeight());
	}

	public boolean contains(double paramDouble1, double paramDouble2) {
		return this.vertices.contains(paramDouble1 - getX(), paramDouble2 - getY(), getMatrix());
	}

	protected void paint2d(Graphics2D paramGraphics2D) {
		int i = this.vertices.size();
		Path2D.Double localDouble = new Path2D.Double(0);
		localDouble.moveTo(this.vertices.get(0).getX(), this.vertices.get(0).getY());
		for (int j = 0; j < i; j++) {
			localDouble.lineTo(this.vertices.get(j).getX(), this.vertices.get(j).getY());
		}
		localDouble.lineTo(this.vertices.get(0).getX(), this.vertices.get(0).getY());
		if (isFilled()) {
			paramGraphics2D.setColor(getFillColor());
			paramGraphics2D.fill(localDouble);
			paramGraphics2D.setColor(getColor());
		}
		paramGraphics2D.draw(localDouble);
	}

	public void recenter() {
		this.vertices.recenter();
	}

	public Object clone() {
		try {
			GPolygon localGPolygon = (GPolygon) super.clone();
			localGPolygon.vertices = new VertexList(localGPolygon.vertices);
			return localGPolygon;
		} catch (Exception localException) {
			throw new ErrorException("Impossible exception");
		}
	}

	protected void markAsComplete() {
		this.complete = true;
	}

	protected void clear() {
		if (this.complete) {
			throw new ErrorException("You can't clear a GPolygon that has been marked as complete.");
		}
		this.vertices.clear();
	}
}
