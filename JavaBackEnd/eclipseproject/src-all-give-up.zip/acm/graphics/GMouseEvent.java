package acm.graphics;

import java.awt.Component;
import java.awt.event.MouseEvent;

class GMouseEvent extends MouseEvent {
	private static final long serialVersionUID = 1L;
	private Object effectiveSource;

	public GMouseEvent(Object paramObject, int paramInt, MouseEvent paramMouseEvent) {
		super(paramMouseEvent.getComponent(), paramInt, paramMouseEvent.getWhen(), paramMouseEvent
				.getModifiers(), paramMouseEvent.getX(), paramMouseEvent.getY(), paramMouseEvent
				.getClickCount(), paramMouseEvent.isPopupTrigger());

		this.effectiveSource = paramObject;
	}

	public Object getSource() {
		return this.effectiveSource;
	}

	public Component getComponent() {
		return (Component) super.getSource();
	}

	public String toString() {
		return getClass().getName() + "[" + paramString() + "] on " + getSource();
	}
}
