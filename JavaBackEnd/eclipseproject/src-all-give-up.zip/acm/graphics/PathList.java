package acm.graphics;

import java.awt.Graphics2D;
import java.io.Serializable;
import java.util.ArrayList;

class PathList implements Serializable {
	private static final long serialVersionUID = 1L;
	public PathList() {
		this.path = new ArrayList();
	}

	public synchronized void add(PathElement paramPathElement) {
		this.path.add(paramPathElement);
	}

	public synchronized void add(PathElement paramPathElement1, PathElement paramPathElement2) {
		this.path.add(paramPathElement1);
		this.path.add(paramPathElement2);
	}

	public synchronized void remove(PathElement paramPathElement) {
		this.path.remove(paramPathElement);
	}

	public synchronized void clear() {
		this.path.clear();
	}

	public int getElementCount() {
		return this.path.size();
	}

	public PathElement getElement(int paramInt) {
		return (PathElement) this.path.get(paramInt);
	}

	public synchronized GRectangle getBounds(PathState paramPathState) {
		GRectangle localGRectangle = new GRectangle(-1.0D, -1.0D, -1.0D, -1.0D);
		int i = this.path.size();
		for (int j = 0; j < i; j++) {
			PathElement localPathElement = (PathElement) this.path.get(j);
			localPathElement.updateBounds(localGRectangle, paramPathState);
		}
		return localGRectangle;
	}

	public synchronized void mapPaint(Graphics2D paramGraphics2D, PathState paramPathState) {
		int i = this.path.size();
		for (int j = 0; j < i; j++) {
			PathElement localPathElement = (PathElement) this.path.get(j);
			localPathElement.paint(paramGraphics2D, paramPathState);
		}
		FINAL_PATH_ELEMENT.paint(paramGraphics2D, paramPathState);
	}

	private static final PathElement FINAL_PATH_ELEMENT = new FinalPathElement();
	private ArrayList<PathElement> path;
}
