package acm.graphics;

import java.awt.Graphics2D;

class FinalPathElement extends PathElement {
	private static final long serialVersionUID = 1L;

	public void paint(Graphics2D paramGraphics2D, PathState paramPathState) {
		if (paramPathState.region != null) {
			paramGraphics2D.drawPolyline(paramPathState.region.xpoints,
					paramPathState.region.ypoints, paramPathState.region.npoints);
		}
	}
}
