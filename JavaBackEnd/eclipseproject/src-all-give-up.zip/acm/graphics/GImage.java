package acm.graphics;

import acm.util.ErrorException;
import acm.util.MediaTools;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.File;

public class GImage extends GObject implements GResizable {
	private Image image;
	private double width;
	private double height;
	private boolean sizeDetermined;
	static final long serialVersionUID = 21L;

	public GImage(Image paramImage) {
		this(paramImage, 0.0D, 0.0D);
	}

	public GImage(String paramString) {
		this(paramString, 0.0D, 0.0D);
	}

	public GImage(int[][] paramArrayOfInt) {
		this(paramArrayOfInt, 0.0D, 0.0D);
	}

	public GImage(Image paramImage, double paramDouble1, double paramDouble2) {
		setImage(paramImage);
		setLocation(paramDouble1, paramDouble2);
	}

	public GImage(String paramString, double paramDouble1, double paramDouble2) {
		this(MediaTools.loadImage(paramString), paramDouble1, paramDouble2);
	}

	public GImage(int[][] paramArrayOfInt, double paramDouble1, double paramDouble2) {
		this(MediaTools.createImage(paramArrayOfInt), paramDouble1, paramDouble2);
	}

	public void setImage(Image paramImage) {
		this.image = MediaTools.loadImage(paramImage);
		this.sizeDetermined = false;
		determineSize();
		repaint();
	}

	public void setImage(String paramString) {
		setImage(MediaTools.loadImage(paramString));
	}

	public Image getImage() {
		return this.image;
	}

	public void saveImage(String paramString) {
		MediaTools.saveImage(this.image, paramString);
	}

	public void saveImage(File paramFile) {
		MediaTools.saveImage(this.image, paramFile);
	}

	protected void paint2d(Graphics2D paramGraphics2D) {
		Component localComponent = getComponent();
		if (localComponent == null) {
			localComponent = MediaTools.getImageObserver();
		}
		if ((this.image != null) && (localComponent != null)) {
			determineSize();
			Color localColor = getObjectColor();
			if (localColor == null) {
				paramGraphics2D.drawImage(this.image, 0, 0, GMath.round(this.width),
						GMath.round(this.height), localComponent);
			} else {
				paramGraphics2D.drawImage(this.image, 0, 0, GMath.round(this.width),
						GMath.round(this.height), localColor, localComponent);
			}
		}
	}

	public void setSize(double paramDouble1, double paramDouble2) {
		if (getMatrix() != null) {
			throw new ErrorException("setSize: Object has been transformed");
		}
		this.width = paramDouble1;
		this.height = paramDouble2;
		repaint();
	}

	public final void setSize(GDimension paramGDimension) {
		setSize(paramGDimension.getWidth(), paramGDimension.getHeight());
	}

	public GDimension getSize() {
		return new GDimension(this.width, this.height);
	}

	public void setBounds(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		if (getMatrix() != null) {
			throw new ErrorException("setBounds: Object has been transformed");
		}
		this.width = paramDouble3;
		this.height = paramDouble4;
		setLocation(paramDouble1, paramDouble2);
	}

	public final void setBounds(GRectangle paramGRectangle) {
		if (getMatrix() != null) {
			throw new ErrorException("setBounds: Object has been transformed");
		}
		setBounds(paramGRectangle.getX(), paramGRectangle.getY(), paramGRectangle.getWidth(),
				paramGRectangle.getHeight());
	}

	public GRectangle getBounds() {
		determineSize();
		Object localObject = new Rectangle2D.Double(0.0D, 0.0D, this.width, this.height);
		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			localObject = localAffineTransform.createTransformedShape((Shape) localObject);
		}
		Rectangle localRectangle = ((Shape) localObject).getBounds();
		return new GRectangle(getX() + localRectangle.getX(), getY() + localRectangle.getY(),
				localRectangle.getWidth(), localRectangle.getHeight());
	}

	public boolean contains(double paramDouble1, double paramDouble2) {
		determineSize();
		Object localObject = new Rectangle2D.Double(0.0D, 0.0D, this.width, this.height);
		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			localObject = localAffineTransform.createTransformedShape((Shape) localObject);
		}
		return ((Shape) localObject).contains(paramDouble1 - getX(), paramDouble2 - getY());
	}

	public int[][] getPixelArray() {
		return MediaTools.getPixelArray(this.image);
	}

	public static int getAlpha(int paramInt) {
		return paramInt >> 24 & 0xFF;
	}

	public static int getRed(int paramInt) {
		return paramInt >> 16 & 0xFF;
	}

	public static int getGreen(int paramInt) {
		return paramInt >> 8 & 0xFF;
	}

	public static int getBlue(int paramInt) {
		return paramInt & 0xFF;
	}

	public static int createRGBPixel(int paramInt1, int paramInt2, int paramInt3) {
		return createRGBPixel(paramInt1, paramInt2, paramInt3, 255);
	}

	public static int createRGBPixel(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
		return paramInt4 << 24 | paramInt1 << 16 | paramInt2 << 8 | paramInt3;
	}

	private void determineSize() {
		if (this.sizeDetermined) {
			return;
		}
		Component localComponent = getComponent();
		if (localComponent == null) {
			localComponent = MediaTools.getImageObserver();
		}
		this.width = this.image.getWidth(localComponent);
		this.height = this.image.getHeight(localComponent);
		this.sizeDetermined = true;
	}
}
