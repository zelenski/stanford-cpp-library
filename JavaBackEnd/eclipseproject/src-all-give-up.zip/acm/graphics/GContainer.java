package acm.graphics;

public abstract interface GContainer {
	public static final int BACK_TO_FRONT = 0;
	public static final int FRONT_TO_BACK = 1;

	public abstract void add(GObject paramGObject);

	public abstract void add(GObject paramGObject, double paramDouble1, double paramDouble2);

	public abstract void add(GObject paramGObject, GPoint paramGPoint);

	public abstract void remove(GObject paramGObject);

	public abstract void removeAll();

	public abstract int getElementCount();

	public abstract GObject getElement(int paramInt);

	public abstract GObject getElementAt(double paramDouble1, double paramDouble2);

	public abstract GObject getElementAt(GPoint paramGPoint);
}
