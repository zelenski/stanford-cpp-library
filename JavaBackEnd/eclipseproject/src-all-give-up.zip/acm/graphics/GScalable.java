package acm.graphics;

public abstract interface GScalable {
	public abstract void scale(double paramDouble1, double paramDouble2);

	public abstract void scale(double paramDouble);
}
