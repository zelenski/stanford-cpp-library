package acm.graphics;

import java.awt.Rectangle;
import java.io.Serializable;

public class GRectangle implements Serializable {
	private double xc;
	private double yc;
	private double width;
	private double height;
	static final long serialVersionUID = 21L;

	public GRectangle() {
		this(0.0D, 0.0D, 0.0D, 0.0D);
	}

	public GRectangle(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		this.xc = paramDouble1;
		this.yc = paramDouble2;
		this.width = paramDouble3;
		this.height = paramDouble4;
	}

	public GRectangle(double paramDouble1, double paramDouble2) {
		this(0.0D, 0.0D, paramDouble1, paramDouble2);
	}

	public GRectangle(GPoint paramGPoint, GDimension paramGDimension) {
		this(paramGPoint.getX(), paramGPoint.getY(), paramGDimension.getWidth(), paramGDimension
				.getHeight());
	}

	public GRectangle(GPoint paramGPoint) {
		this(paramGPoint.getX(), paramGPoint.getY(), 0.0D, 0.0D);
	}

	public GRectangle(GDimension paramGDimension) {
		this(0.0D, 0.0D, paramGDimension.getWidth(), paramGDimension.getHeight());
	}

	public GRectangle(GRectangle paramGRectangle) {
		this(paramGRectangle.xc, paramGRectangle.yc, paramGRectangle.width, paramGRectangle.height);
	}

	public double getX() {
		return this.xc;
	}

	public double getY() {
		return this.yc;
	}

	public double getWidth() {
		return this.width;
	}

	public double getHeight() {
		return this.height;
	}

	public void setBounds(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		this.xc = paramDouble1;
		this.yc = paramDouble2;
		this.width = paramDouble3;
		this.height = paramDouble4;
	}

	public void setBounds(GPoint paramGPoint, GDimension paramGDimension) {
		setBounds(paramGPoint.getX(), paramGPoint.getY(), paramGDimension.getWidth(),
				paramGDimension.getHeight());
	}

	public void setBounds(GRectangle paramGRectangle) {
		setBounds(paramGRectangle.xc, paramGRectangle.yc, paramGRectangle.width,
				paramGRectangle.height);
	}

	public GRectangle getBounds() {
		return new GRectangle(this);
	}

	public void setLocation(double paramDouble1, double paramDouble2) {
		this.xc = paramDouble1;
		this.yc = paramDouble2;
	}

	public void setLocation(GPoint paramGPoint) {
		setLocation(paramGPoint.getX(), paramGPoint.getY());
	}

	public GPoint getLocation() {
		return new GPoint(this.xc, this.yc);
	}

	public void translate(double paramDouble1, double paramDouble2) {
		this.xc += paramDouble1;
		this.yc += paramDouble2;
	}

	public void setSize(double paramDouble1, double paramDouble2) {
		this.width = paramDouble1;
		this.height = paramDouble2;
	}

	public void setSize(GDimension paramGDimension) {
		setSize(paramGDimension.getWidth(), paramGDimension.getHeight());
	}

	public GDimension getSize() {
		return new GDimension(this.width, this.height);
	}

	public void grow(double paramDouble1, double paramDouble2) {
		this.xc -= paramDouble1;
		this.yc -= paramDouble2;
		this.width += 2.0D * paramDouble1;
		this.height += 2.0D * paramDouble2;
	}

	public boolean isEmpty() {
		return (this.width <= 0.0D) || (this.height <= 0.0D);
	}

	public boolean contains(double paramDouble1, double paramDouble2) {
		return (paramDouble1 >= this.xc) && (paramDouble2 >= this.yc)
				&& (paramDouble1 < this.xc + this.width) && (paramDouble2 < this.yc + this.height);
	}

	public boolean contains(GPoint paramGPoint) {
		return contains(paramGPoint.getX(), paramGPoint.getY());
	}

	public boolean intersects(GRectangle paramGRectangle) {
		GRectangle localGRectangle = this;
		if (localGRectangle.xc > paramGRectangle.xc + paramGRectangle.width) {
			return false;
		}
		if (localGRectangle.yc > paramGRectangle.yc + paramGRectangle.height) {
			return false;
		}
		if (paramGRectangle.xc > localGRectangle.xc + localGRectangle.width) {
			return false;
		}
		if (paramGRectangle.yc > localGRectangle.yc + localGRectangle.height) {
			return false;
		}
		return true;
	}

	public GRectangle intersection(GRectangle paramGRectangle) {
		GRectangle localGRectangle = this;
		double d1 = Math.max(localGRectangle.xc, paramGRectangle.xc);
		double d2 = Math.max(localGRectangle.yc, paramGRectangle.yc);
		double d3 = Math.min(localGRectangle.xc + localGRectangle.width, paramGRectangle.xc
				+ paramGRectangle.width);
		double d4 = Math.min(localGRectangle.yc + localGRectangle.height, paramGRectangle.yc
				+ paramGRectangle.height);
		return new GRectangle(d1, d2, d3 - d1, d4 - d2);
	}

	public GRectangle union(GRectangle paramGRectangle) {
		if (isEmpty()) {
			return new GRectangle(paramGRectangle);
		}
		if (paramGRectangle.isEmpty()) {
			return new GRectangle(this);
		}
		GRectangle localGRectangle = this;
		double d1 = Math.min(localGRectangle.xc, paramGRectangle.xc);
		double d2 = Math.min(localGRectangle.yc, paramGRectangle.yc);
		double d3 = Math.max(localGRectangle.xc + localGRectangle.width, paramGRectangle.xc
				+ paramGRectangle.width);
		double d4 = Math.max(localGRectangle.yc + localGRectangle.height, paramGRectangle.yc
				+ paramGRectangle.height);
		return new GRectangle(d1, d2, d3 - d1, d4 - d2);
	}

	public void add(GRectangle paramGRectangle) {
		if (paramGRectangle.isEmpty()) {
			return;
		}
		if (isEmpty()) {
			setBounds(paramGRectangle);
			return;
		}
		double d1 = Math.max(this.xc + this.width, paramGRectangle.xc + paramGRectangle.width);
		double d2 = Math.max(this.yc + this.height, paramGRectangle.yc + paramGRectangle.height);
		this.xc = Math.min(paramGRectangle.xc, this.xc);
		this.yc = Math.min(paramGRectangle.yc, this.yc);
		this.width = (d1 - this.xc);
		this.height = (d2 - this.yc);
	}

	public void add(double paramDouble1, double paramDouble2) {
		if (isEmpty()) {
			setBounds(paramDouble1, paramDouble2, 0.0D, 0.0D);
			return;
		}
		double d1 = Math.max(paramDouble1 + this.width, paramDouble1);
		double d2 = Math.max(paramDouble2 + this.height, paramDouble2);
		this.xc = Math.min(paramDouble1, this.xc);
		this.yc = Math.min(paramDouble2, this.yc);
		this.width = (d1 - this.xc);
		this.height = (d2 - this.yc);
	}

	public Rectangle toRectangle() {
		return new Rectangle(GMath.round(this.xc), GMath.round(this.yc), GMath.round(this.width),
				GMath.round(this.height));
	}

	public int hashCode() {
		int i = new Float((float) this.xc).hashCode();
		i = 37 * i ^ new Float((float) this.yc).hashCode();
		i = 37 * i ^ new Float((float) this.width).hashCode();
		i = 37 * i ^ new Float((float) this.height).hashCode();
		return i;
	}

	public boolean equals(Object paramObject) {
		if (!(paramObject instanceof GRectangle)) {
			return false;
		}
		GRectangle localGRectangle = (GRectangle) paramObject;
		if ((float) this.xc != (float) localGRectangle.xc) {
			return false;
		}
		if ((float) this.yc != (float) localGRectangle.yc) {
			return false;
		}
		if ((float) this.width != (float) localGRectangle.width) {
			return false;
		}
		if ((float) this.height != (float) localGRectangle.height) {
			return false;
		}
		return true;
	}

	public String toString() {
		return "[" + (float) this.xc + ", " + (float) this.yc + ", " + (float) this.width + "x"
				+ (float) this.height + "]";
	}
}
