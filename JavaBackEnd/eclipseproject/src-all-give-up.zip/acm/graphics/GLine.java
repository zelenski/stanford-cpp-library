package acm.graphics;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

public class GLine extends GObject {
	public static final double LINE_TOLERANCE = 1.5D;
	private double dx;
	private double dy;
	static final long serialVersionUID = 21L;

	public GLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
		setLocation(paramDouble1, paramDouble2);
		this.dx = (paramDouble3 - paramDouble1);
		this.dy = (paramDouble4 - paramDouble2);
	}

	protected void paint2d(Graphics2D paramGraphics2D) {
		Line2D.Double localDouble = new Line2D.Double(0.0D, 0.0D, GMath.round(this.dx),
				GMath.round(this.dy));
		paramGraphics2D.draw(localDouble);
	}

	public GRectangle getBounds() {
		double d1 = getX();
		double d2 = getY();
		double d3 = d1 + this.dx;
		double d4 = d2 + this.dy;
		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			Point2D.Double localDouble = new Point2D.Double(d1, d2);
			localAffineTransform.transform(localDouble, localDouble);
			d1 = localDouble.getX();
			d2 = localDouble.getY();
			localDouble = new Point2D.Double(d3, d4);
			localAffineTransform.transform(localDouble, localDouble);
			d3 = localDouble.getX();
			d4 = localDouble.getY();
		}
		double d5 = Math.min(d1, d3);
		double d6 = Math.min(d2, d4);
		return new GRectangle(d5, d6, Math.abs(d3 - d1) + 1.0D, Math.abs(d4 - d2) + 1.0D);
	}

	public void setStartPoint(double paramDouble1, double paramDouble2) {
		this.dx += getX() - paramDouble1;
		this.dy += getY() - paramDouble2;
		setLocation(paramDouble1, paramDouble2);
	}

	public GPoint getStartPoint() {
		return getLocation();
	}

	public void setEndPoint(double paramDouble1, double paramDouble2) {
		this.dx = (paramDouble1 - getX());
		this.dy = (paramDouble2 - getY());
		repaint();
	}

	public GPoint getEndPoint() {
		return new GPoint(getX() + this.dx, getY() + this.dy);
	}

	public boolean contains(double paramDouble1, double paramDouble2) {
		double d1 = getX();
		double d2 = getY();
		double d3 = d1 + this.dx;
		double d4 = d2 + this.dy;
		AffineTransform localAffineTransform = getMatrix();
		if (localAffineTransform != null) {
			Point2D.Double localDouble = new Point2D.Double(d1, d2);
			localAffineTransform.transform(localDouble, localDouble);
			d1 = localDouble.getX();
			d2 = localDouble.getY();
			localDouble = new Point2D.Double(d3, d4);
			localAffineTransform.transform(localDouble, localDouble);
			d3 = localDouble.getX();
			d4 = localDouble.getY();
		}
		double d5 = 2.25D;
		if (distanceSquared(paramDouble1, paramDouble2, d1, d2) < d5) {
			return true;
		}
		if (distanceSquared(paramDouble1, paramDouble2, d3, d4) < d5) {
			return true;
		}
		if (paramDouble1 < Math.min(d1, d3) - 1.5D) {
			return false;
		}
		if (paramDouble1 > Math.max(d1, d3) + 1.5D) {
			return false;
		}
		if (paramDouble2 < Math.min(d2, d4) - 1.5D) {
			return false;
		}
		if (paramDouble2 > Math.max(d2, d4) + 1.5D) {
			return false;
		}
		if (((float) d1 - (float) d3 == 0.0F) && ((float) d2 - (float) d4 == 0.0F)) {
			return false;
		}
		double d6 = ((paramDouble1 - d1) * (d3 - d1) + (paramDouble2 - d2) * (d4 - d2))
				/ distanceSquared(d1, d2, d3, d4);

		return distanceSquared(paramDouble1, paramDouble2, d1 + d6 * (d3 - d1), d2 + d6 * (d4 - d2)) < d5;
	}

	public String paramString() {
		String str1 = super.paramString();
		str1 = str1.substring(str1.indexOf(')') + 1);
		GPoint localGPoint = getStartPoint();
		String str2 = "start=(" + localGPoint.getX() + ", " + localGPoint.getY() + ")";
		localGPoint = getEndPoint();
		str2 = str2 + ", end=(" + localGPoint.getX() + ", " + localGPoint.getY() + ")";
		return str2 + str1;
	}

	private double distanceSquared(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		return (paramDouble3 - paramDouble1) * (paramDouble3 - paramDouble1)
				+ (paramDouble4 - paramDouble2) * (paramDouble4 - paramDouble2);
	}
}
