package acm.graphics;

import java.awt.Graphics2D;

class DrawLineElement extends PathElement {
	private static final long serialVersionUID = 1L;
	private double deltaX;
	private double deltaY;

	public DrawLineElement(double paramDouble1, double paramDouble2) {
		this.deltaX = paramDouble1;
		this.deltaY = paramDouble2;
	}

	public void paint(Graphics2D paramGraphics2D, PathState paramPathState) {
		int i = GMath.round(paramPathState.sx * paramPathState.cx);
		int j = GMath.round(paramPathState.sy * paramPathState.cy);
		paramPathState.cx += this.deltaX;
		paramPathState.cy += this.deltaY;
		int k = GMath.round(paramPathState.sx * paramPathState.cx);
		int m = GMath.round(paramPathState.sy * paramPathState.cy);
		if (paramPathState.region == null) {
			paramGraphics2D.drawLine(i, j, k, m);
		} else {
			paramPathState.region.addPoint(k, m);
		}
	}

	public void updateBounds(GRectangle paramGRectangle, PathState paramPathState) {
		if (paramGRectangle.getWidth() < 0.0D) {
			paramGRectangle.setBounds(paramPathState.sx * paramPathState.cx, paramPathState.sy
					* paramPathState.cy, 0.0D, 0.0D);
		} else {
			paramGRectangle.add(paramPathState.sx * paramPathState.cx, paramPathState.sy
					* paramPathState.cy);
		}
		paramPathState.cx += this.deltaX;
		paramPathState.cy += this.deltaY;
		paramGRectangle.add(paramPathState.sx * paramPathState.cx, paramPathState.sy
				* paramPathState.cy);
	}
}
