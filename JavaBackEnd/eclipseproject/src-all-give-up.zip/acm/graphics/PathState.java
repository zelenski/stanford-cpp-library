package acm.graphics;

import java.awt.Color;
import java.awt.Polygon;
import java.io.Serializable;

class PathState implements Serializable {
	private static final long serialVersionUID = 1L;
	double cx;
	double cy;
	double sx;
	double sy;
	Polygon region;
	Color fillColor;
}
