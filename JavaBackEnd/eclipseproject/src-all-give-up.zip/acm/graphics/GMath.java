package acm.graphics;

public class GMath {
	public static int round(double paramDouble) {
		return (int) Math.round(paramDouble);
	}

	public static double sinDegrees(double paramDouble) {
		return Math.sin(toRadians(paramDouble));
	}

	public static double cosDegrees(double paramDouble) {
		return Math.cos(toRadians(paramDouble));
	}

	public static double tanDegrees(double paramDouble) {
		return sinDegrees(paramDouble) / cosDegrees(paramDouble);
	}

	public static double toDegrees(double paramDouble) {
		return paramDouble * 180.0D / 3.141592653589793D;
	}

	public static double toRadians(double paramDouble) {
		return paramDouble * 3.141592653589793D / 180.0D;
	}

	public static double distance(double paramDouble1, double paramDouble2) {
		return Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2);
	}

	public static double distance(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		return distance(paramDouble3 - paramDouble1, paramDouble4 - paramDouble2);
	}

	public static double angle(double paramDouble1, double paramDouble2) {
		if ((paramDouble1 == 0.0D) && (paramDouble2 == 0.0D)) {
			return 0.0D;
		}
		return toDegrees(Math.atan2(-paramDouble2, paramDouble1));
	}

	public static double angle(double paramDouble1, double paramDouble2, double paramDouble3,
			double paramDouble4) {
		return angle(paramDouble3 - paramDouble1, paramDouble4 - paramDouble2);
	}
}
