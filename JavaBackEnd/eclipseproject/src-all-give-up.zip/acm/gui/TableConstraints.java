package acm.gui;

import acm.util.ErrorException;
import acm.util.OptionTable;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.Map;

public class TableConstraints
  extends GridBagConstraints
{
  public int width;
  public int height;
  private static final int MY_PAGE_START = 19;
  private static final int MY_PAGE_END = 20;
  private static final int MY_LINE_START = 21;
  private static final int MY_LINE_END = 22;
  private static final int MY_FIRST_LINE_START = 23;
  private static final int MY_FIRST_LINE_END = 24;
  private static final int MY_LAST_LINE_START = 25;
  private static final int MY_LAST_LINE_END = 26;
  
  public TableConstraints()
  {
    this("");
  }
  
  public TableConstraints(String paramString)
  {
    this(new OptionTable(paramString.toLowerCase(), LEGAL_KEYS).getMap());
  }
  
  public TableConstraints(Map<String, String> paramMap)
  {
    OptionTable localOptionTable = new OptionTable(paramMap);
    this.gridx = parseXYConstraint(localOptionTable.getOption("gridx"));
    this.gridy = parseXYConstraint(localOptionTable.getOption("gridy"));
    String str1 = localOptionTable.getOption("gridwidth");
    if (str1 == null) {
      str1 = localOptionTable.getOption("rowspan");
    }
    String str2 = localOptionTable.getOption("gridheight");
    if (str2 == null) {
      str2 = localOptionTable.getOption("colspan");
    }
    this.gridwidth = parseSpanConstraint(str1);
    this.gridheight = parseSpanConstraint(str2);
    this.fill = parseFillConstraint(localOptionTable.getOption("fill"));
    this.anchor = parseAnchorConstraint(localOptionTable.getOption("anchor"));
    this.ipadx = localOptionTable.getIntOption("ipadx", 0);
    this.ipady = localOptionTable.getIntOption("ipady", 0);
    this.weightx = localOptionTable.getDoubleOption("weightx", 0.0D);
    this.weighty = localOptionTable.getDoubleOption("weighty", 0.0D);
    this.insets.left = localOptionTable.getIntOption("left", 0);
    this.insets.right = localOptionTable.getIntOption("right", 0);
    this.insets.top = localOptionTable.getIntOption("top", 0);
    this.insets.bottom = localOptionTable.getIntOption("bottom", 0);
    this.width = localOptionTable.getIntOption("width", -1);
    if (this.width == -1) {
      this.width = 0;
    } else {
      this.width += this.insets.left + this.insets.right;
    }
    this.height = localOptionTable.getIntOption("height", -1);
    if (this.height == -1) {
      this.height = 0;
    } else {
      this.height += this.insets.top + this.insets.bottom;
    }
    if ((this.gridwidth != 1) && (this.width != 0)) {
      throw new ErrorException("TableConstraints: Cannot specify both width and gridwidth");
    }
    if ((this.gridheight != 1) && (this.height != 0)) {
      throw new ErrorException("TableConstraints: Cannot specify both height and gridheight");
    }
  }
  
  public TableConstraints(GridBagConstraints paramGridBagConstraints)
  {
    this.gridx = paramGridBagConstraints.gridx;
    this.gridy = paramGridBagConstraints.gridy;
    this.gridwidth = paramGridBagConstraints.gridwidth;
    this.gridheight = paramGridBagConstraints.gridheight;
    this.fill = paramGridBagConstraints.fill;
    this.anchor = paramGridBagConstraints.anchor;
    this.ipadx = paramGridBagConstraints.ipadx;
    this.ipady = paramGridBagConstraints.ipady;
    this.weightx = paramGridBagConstraints.weightx;
    this.weighty = paramGridBagConstraints.weighty;
    this.insets.left = paramGridBagConstraints.insets.left;
    this.insets.right = paramGridBagConstraints.insets.right;
    this.insets.top = paramGridBagConstraints.insets.top;
    this.insets.bottom = paramGridBagConstraints.insets.bottom;
    if ((paramGridBagConstraints instanceof TableConstraints))
    {
      TableConstraints localTableConstraints = (TableConstraints)paramGridBagConstraints;
      this.width = localTableConstraints.width;
      this.height = localTableConstraints.height;
    }
  }
  
  public int getAnchor()
  {
    return this.anchor;
  }
  
  public int getFill()
  {
    return this.fill;
  }
  
  public int getGridX()
  {
    return this.gridx;
  }
  
  public int getGridY()
  {
    return this.gridy;
  }
  
  public int getGridWidth()
  {
    return this.gridwidth;
  }
  
  public int getGridHeight()
  {
    return this.gridheight;
  }
  
  public int getIPadX()
  {
    return this.ipadx;
  }
  
  public int getIPadY()
  {
    return this.ipady;
  }
  
  public Insets getInsets()
  {
    return this.insets;
  }
  
  public double getWeightX()
  {
    return this.weightx;
  }
  
  public double getWeightY()
  {
    return this.weighty;
  }
  
  public int getWidth()
  {
    return this.width;
  }
  
  public int getHeight()
  {
    return this.height;
  }
  
  public String toString()
  {
    String str = getClass().getName();
    str = str + "[gridx=" + this.gridx + ",gridy=" + this.gridy;
    switch (this.fill)
    {
    case 3: 
      str = str + ",fill=VERTICAL"; break;
    case 2: 
      str = str + ",fill=HORIZONTAL"; break;
    case 1: 
      str = str + ",fill=BOTH";
    }
    switch (this.anchor)
    {
    case 11: 
      str = str + ",anchor=NORTH"; break;
    case 15: 
      str = str + ",anchor=SOUTH"; break;
    case 13: 
      str = str + ",anchor=EAST"; break;
    case 17: 
      str = str + ",anchor=WEST"; break;
    case 12: 
      str = str + ",anchor=NORTHEAST"; break;
    case 18: 
      str = str + ",anchor=NORTHWEST"; break;
    case 14: 
      str = str + ",anchor=SOUTHEAST"; break;
    case 16: 
      str = str + ",anchor=SOUTHWEST"; break;
    case 19: 
      str = str + ",anchor=PAGE_START"; break;
    case 20: 
      str = str + ",anchor=PAGE_END"; break;
    case 21: 
      str = str + ",anchor=LINE_START"; break;
    case 22: 
      str = str + ",anchor=LINE_END"; break;
    case 23: 
      str = str + ",anchor=FIRST_LINE_START"; break;
    case 24: 
      str = str + ",anchor=FIRST_LINE_END"; break;
    case 25: 
      str = str + ",anchor=LAST_LINE_START"; break;
    case 26: 
      str = str + ",anchor=LAST_LINE_END";
    }
    if (this.gridwidth != 1) {
      str = str + ",gridwidth=" + this.gridwidth;
    }
    if (this.gridheight != 1) {
      str = str + ",gridheight=" + this.gridheight;
    }
    if (this.ipadx != 0) {
      str = str + ",ipadx=" + this.ipadx;
    }
    if (this.ipady != 0) {
      str = str + ",ipady=" + this.ipady;
    }
    if (this.insets.left != 0) {
      str = str + ",left=" + this.insets.left;
    }
    if (this.insets.right != 0) {
      str = str + ",right=" + this.insets.right;
    }
    if (this.insets.top != 0) {
      str = str + ",top=" + this.insets.top;
    }
    if (this.insets.bottom != 0) {
      str = str + ",bottom=" + this.insets.bottom;
    }
    if (this.width != 0) {
      str = str + ",width=" + this.width;
    }
    if (this.height != 0) {
      str = str + ",height=" + this.height;
    }
    str = str + "]";
    return str;
  }
  
  private int parseXYConstraint(String paramString)
  {
    if (paramString == null) {
      return -1;
    }
    if (paramString.equals("relative")) {
      return -1;
    }
    try
    {
      return Integer.decode(paramString).intValue();
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new ErrorException("TableConstraints: Illegal grid coordinate");
    }
  }
  
  private int parseSpanConstraint(String paramString)
  {
    if (paramString == null) {
      return 1;
    }
    if (paramString.equals("relative")) {
      return -1;
    }
    if (paramString.equals("remainder")) {
      return 0;
    }
    try
    {
      return Integer.decode(paramString).intValue();
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new ErrorException("TableConstraints: Illegal span constraint");
    }
  }
  
  private int parseAnchorConstraint(String paramString)
  {
    if (paramString == null) {
      return 10;
    }
    if (paramString.equals("center")) {
      return 10;
    }
    if (paramString.equals("north")) {
      return 11;
    }
    if (paramString.equals("south")) {
      return 15;
    }
    if (paramString.equals("east")) {
      return 13;
    }
    if (paramString.equals("west")) {
      return 17;
    }
    if ((paramString.equals("northeast")) || (paramString.equals("ne"))) {
      return 12;
    }
    if ((paramString.equals("northwest")) || (paramString.equals("nw"))) {
      return 18;
    }
    if ((paramString.equals("southeast")) || (paramString.equals("se"))) {
      return 14;
    }
    if ((paramString.equals("southwest")) || (paramString.equals("sw"))) {
      return 16;
    }
    if (paramString.equals("page_start")) {
      return 19;
    }
    if (paramString.equals("page_end")) {
      return 20;
    }
    if (paramString.equals("line_start")) {
      return 21;
    }
    if (paramString.equals("line_end")) {
      return 22;
    }
    if (paramString.equals("first_line_start")) {
      return 23;
    }
    if (paramString.equals("first_line_end")) {
      return 24;
    }
    if (paramString.equals("last_line_start")) {
      return 25;
    }
    if (paramString.equals("last_line_end")) {
      return 26;
    }
    throw new ErrorException("TableConstraints: Illegal anchor specification");
  }
  
  private int parseFillConstraint(String paramString)
  {
    if ((paramString == null) || (paramString.equals("none"))) {
      return 0;
    }
    if (paramString.equals("horizontal")) {
      return 2;
    }
    if (paramString.equals("vertical")) {
      return 3;
    }
    if (paramString.equals("both")) {
      return 1;
    }
    throw new ErrorException("TableConstraints: Illegal fill specification");
  }
  
  protected static final String[] LEGAL_KEYS = { "anchor", "bottom", "colspan", "fill", "gridwidth", "gridheight", "gridx", "gridy", "height", "ipadx", "ipady", "left", "right", "rowspan", "top", "weightx", "weighty", "width" };
  static final long serialVersionUID = 1L;
}
