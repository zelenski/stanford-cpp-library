package acm.gui;

import javax.swing.JPanel;

public class TablePanel
  extends JPanel
{
  public static final int NONE = 0;
  public static final int HORIZONTAL = 2;
  public static final int VERTICAL = 3;
  public static final int BOTH = 1;
  public static final int CENTER = 10;
  public static final int LEFT = 11;
  public static final int RIGHT = 12;
  public static final int TOP = 13;
  public static final int BOTTOM = 14;
  public static final int FILL = 1;
  static final long serialVersionUID = 1L;
  
  TablePanel() {}
  
  public TablePanel(int paramInt1, int paramInt2)
  {
    this(paramInt1, paramInt2, 0, 0);
  }
  
  public TablePanel(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    setLayout(new TableLayout(paramInt1, paramInt2, paramInt3, paramInt4));
  }
  
  public void setHorizontalAlignment(int paramInt)
  {
    ((TableLayout)getLayout()).setHorizontalAlignment(paramInt);
  }
  
  public int getHorizontalAlignment()
  {
    return ((TableLayout)getLayout()).getHorizontalAlignment();
  }
  
  public void setVerticalAlignment(int paramInt)
  {
    ((TableLayout)getLayout()).setVerticalAlignment(paramInt);
  }
  
  public int getVerticalAlignment()
  {
    return ((TableLayout)getLayout()).getVerticalAlignment();
  }
  
  public void setDefaultFill(int paramInt)
  {
    ((TableLayout)getLayout()).setDefaultFill(paramInt);
  }
  
  public int getDefaultFill()
  {
    return ((TableLayout)getLayout()).getDefaultFill();
  }
  
  public void setHgap(int paramInt)
  {
    ((TableLayout)getLayout()).setHgap(paramInt);
  }
  
  public int getHgap()
  {
    return ((TableLayout)getLayout()).getHgap();
  }
  
  public void setVgap(int paramInt)
  {
    ((TableLayout)getLayout()).setVgap(paramInt);
  }
  
  public int getVgap()
  {
    return ((TableLayout)getLayout()).getVgap();
  }
}
